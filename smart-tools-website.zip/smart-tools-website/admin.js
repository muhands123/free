// لوحة التحكم الإدارية
class AdminPanel {
    constructor() {
        this.currentSection = 'dashboard';
        this.isVisible = false;
    }

    // عرض لوحة الإدارة
    show() {
        if (!auth.isAdmin()) {
            showNotification(getCurrentLanguage() === 'ar' ? 'ليس لديك صلاحية إدارية' : 'You do not have admin privileges', 'error');
            return;
        }

        this.isVisible = true;
        this.render();
        document.getElementById('admin-modal').style.display = 'block';
    }

    // إخفاء لوحة الإدارة
    hide() {
        this.isVisible = false;
        document.getElementById('admin-modal').style.display = 'none';
    }

    // تبديل القسم
    switchSection(section) {
        this.currentSection = section;
        this.render();
    }

    // رسم لوحة الإدارة
    render() {
        const content = document.getElementById('admin-content');
        if (!content) return;

        const currentLang = getCurrentLanguage();
        
        content.innerHTML = `
            <div class="admin-header">
                <h2>${currentLang === 'ar' ? 'لوحة التحكم الإدارية' : 'Admin Control Panel'}</h2>
                <button class="close-admin-btn" onclick="adminPanel.hide()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <div class="admin-layout">
                <div class="admin-sidebar">
                    ${this.renderSidebar()}
                </div>
                <div class="admin-main">
                    ${this.renderMainContent()}
                </div>
            </div>
        `;
    }

    // رسم الشريط الجانبي
    renderSidebar() {
        const currentLang = getCurrentLanguage();
        const sections = [
            { id: 'dashboard', icon: 'fas fa-tachometer-alt', name: currentLang === 'ar' ? 'لوحة المعلومات' : 'Dashboard' },
            { id: 'users', icon: 'fas fa-users', name: currentLang === 'ar' ? 'إدارة المستخدمين' : 'User Management' },
            { id: 'tools', icon: 'fas fa-tools', name: currentLang === 'ar' ? 'إدارة الأدوات' : 'Tools Management' },
            { id: 'posts', icon: 'fas fa-newspaper', name: currentLang === 'ar' ? 'إدارة المنشورات' : 'Posts Management' },
            { id: 'images', icon: 'fas fa-images', name: currentLang === 'ar' ? 'إدارة الصور' : 'Images Management' },
            { id: 'comments', icon: 'fas fa-comments', name: currentLang === 'ar' ? 'إدارة التعليقات' : 'Comments Management' },
            { id: 'settings', icon: 'fas fa-cog', name: currentLang === 'ar' ? 'إعدادات الموقع' : 'Site Settings' },
            { id: 'design', icon: 'fas fa-palette', name: currentLang === 'ar' ? 'تخصيص التصميم' : 'Design Customization' }
        ];

        return sections.map(section => `
            <div class="admin-menu-item ${this.currentSection === section.id ? 'active' : ''}" 
                 onclick="adminPanel.switchSection('${section.id}')">
                <i class="${section.icon}"></i>
                <span>${section.name}</span>
            </div>
        `).join('');
    }

    // رسم المحتوى الرئيسي
    renderMainContent() {
        switch (this.currentSection) {
            case 'dashboard':
                return this.renderDashboard();
            case 'users':
                return this.renderUsersManagement();
            case 'tools':
                return this.renderToolsManagement();
            case 'posts':
                return this.renderPostsManagement();
            case 'images':
                return this.renderImagesManagement();
            case 'comments':
                return this.renderCommentsManagement();
            case 'settings':
                return this.renderSiteSettings();
            case 'design':
                return this.renderDesignCustomization();
            default:
                return this.renderDashboard();
        }
    }

    // رسم لوحة المعلومات
    renderDashboard() {
        const currentLang = getCurrentLanguage();
        const stats = this.getWebsiteStats();

        return `
            <div class="admin-section">
                <h3>${currentLang === 'ar' ? 'إحصائيات الموقع' : 'Website Statistics'}</h3>
                
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-icon">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="stat-info">
                            <div class="stat-number">${stats.totalUsers}</div>
                            <div class="stat-label">${currentLang === 'ar' ? 'إجمالي المستخدمين' : 'Total Users'}</div>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon">
                            <i class="fas fa-star"></i>
                        </div>
                        <div class="stat-info">
                            <div class="stat-number">${stats.totalPoints}</div>
                            <div class="stat-label">${currentLang === 'ar' ? 'إجمالي النقاط' : 'Total Points'}</div>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon">
                            <i class="fas fa-tools"></i>
                        </div>
                        <div class="stat-info">
                            <div class="stat-number">${stats.toolUsageToday}</div>
                            <div class="stat-label">${currentLang === 'ar' ? 'استخدام الأدوات اليوم' : 'Tool Usage Today'}</div>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon">
                            <i class="fas fa-comments"></i>
                        </div>
                        <div class="stat-info">
                            <div class="stat-number">${stats.totalComments}</div>
                            <div class="stat-label">${currentLang === 'ar' ? 'إجمالي التعليقات' : 'Total Comments'}</div>
                        </div>
                    </div>
                </div>
                
                <div class="recent-activity">
                    <h4>${currentLang === 'ar' ? 'النشاط الأخير' : 'Recent Activity'}</h4>
                    <div class="activity-list">
                        ${this.renderRecentActivity()}
                    </div>
                </div>
            </div>
        `;
    }

    // رسم إدارة المستخدمين
    renderUsersManagement() {
        const currentLang = getCurrentLanguage();
        const users = db.getData('users');

        return `
            <div class="admin-section">
                <div class="section-header">
                    <h3>${currentLang === 'ar' ? 'إدارة المستخدمين' : 'User Management'}</h3>
                    <div class="section-actions">
                        <input type="text" id="user-search" placeholder="${currentLang === 'ar' ? 'البحث عن مستخدم...' : 'Search users...'}" 
                               onkeyup="adminPanel.searchUsers(this.value)">
                    </div>
                </div>
                
                <div class="users-table">
                    <table>
                        <thead>
                            <tr>
                                <th>${currentLang === 'ar' ? 'المستخدم' : 'User'}</th>
                                <th>${currentLang === 'ar' ? 'البريد الإلكتروني' : 'Email'}</th>
                                <th>${currentLang === 'ar' ? 'النقاط' : 'Points'}</th>
                                <th>${currentLang === 'ar' ? 'تاريخ التسجيل' : 'Join Date'}</th>
                                <th>${currentLang === 'ar' ? 'الإجراءات' : 'Actions'}</th>
                            </tr>
                        </thead>
                        <tbody id="users-table-body">
                            ${users.map(user => `
                                <tr data-user-id="${user.id}">
                                    <td>
                                        <div class="user-info">
                                            ${user.profile_image ? 
                                                `<img src="${user.profile_image}" alt="${user.username}" class="user-avatar-small">` : 
                                                `<div class="user-avatar-placeholder-small"><i class="fas fa-user"></i></div>`
                                            }
                                            <span>${user.username}</span>
                                            ${user.is_admin ? `<span class="admin-badge">${currentLang === 'ar' ? 'مدير' : 'Admin'}</span>` : ''}
                                        </div>
                                    </td>
                                    <td>${user.email}</td>
                                    <td>
                                        <input type="number" value="${user.points}" 
                                               onchange="adminPanel.updateUserPoints('${user.id}', this.value)"
                                               class="points-input">
                                    </td>
                                    <td>${formatDate(user.created_at)}</td>
                                    <td>
                                        <div class="action-buttons">
                                            <button onclick="adminPanel.toggleAdminStatus('${user.id}')" 
                                                    class="btn ${user.is_admin ? 'btn-warning' : 'btn-success'}" 
                                                    title="${user.is_admin ? (currentLang === 'ar' ? 'إزالة صلاحية الإدارة' : 'Remove Admin') : (currentLang === 'ar' ? 'منح صلاحية الإدارة' : 'Make Admin')}">
                                                <i class="fas ${user.is_admin ? 'fa-user-minus' : 'fa-user-plus'}"></i>
                                            </button>
                                            <button onclick="adminPanel.deleteUser('${user.id}')" 
                                                    class="btn btn-danger" 
                                                    title="${currentLang === 'ar' ? 'حذف المستخدم' : 'Delete User'}">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    }

    // رسم إدارة الأدوات
    renderToolsManagement() {
        const currentLang = getCurrentLanguage();
        const tools = db.getData('tools');

        return `
            <div class="admin-section">
                <div class="section-header">
                    <h3>${currentLang === 'ar' ? 'إدارة الأدوات' : 'Tools Management'}</h3>
                    <button class="btn btn-primary" onclick="adminPanel.showAddToolModal()">
                        <i class="fas fa-plus"></i>
                        ${currentLang === 'ar' ? 'إضافة أداة جديدة' : 'Add New Tool'}
                    </button>
                </div>
                
                <div class="tools-grid">
                    ${tools.map(tool => `
                        <div class="tool-admin-card" data-tool-id="${tool.id}">
                            <div class="tool-header">
                                <h4>${currentLang === 'ar' ? tool.name_ar : tool.name_en}</h4>
                                <div class="tool-actions">
                                    <button onclick="adminPanel.editTool('${tool.id}')" class="btn btn-sm btn-primary">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button onclick="adminPanel.toggleToolStatus('${tool.id}')" 
                                            class="btn btn-sm ${tool.is_active ? 'btn-warning' : 'btn-success'}">
                                        <i class="fas ${tool.is_active ? 'fa-pause' : 'fa-play'}"></i>
                                    </button>
                                    <button onclick="adminPanel.deleteTool('${tool.id}')" class="btn btn-sm btn-danger">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="tool-info">
                                <p>${currentLang === 'ar' ? tool.description_ar : tool.description_en}</p>
                                <div class="tool-stats">
                                    <span class="stat-item">
                                        <i class="fas fa-star"></i>
                                        ${tool.required_points} ${currentLang === 'ar' ? 'نقطة مطلوبة' : 'points required'}
                                    </span>
                                    <span class="stat-item">
                                        <i class="fas fa-gift"></i>
                                        ${tool.daily_points} ${currentLang === 'ar' ? 'نقطة يومية' : 'daily points'}
                                    </span>
                                    <span class="stat-item ${tool.is_active ? 'active' : 'inactive'}">
                                        <i class="fas ${tool.is_active ? 'fa-check-circle' : 'fa-times-circle'}"></i>
                                        ${tool.is_active ? (currentLang === 'ar' ? 'نشط' : 'Active') : (currentLang === 'ar' ? 'معطل' : 'Inactive')}
                                    </span>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }

    // رسم إدارة المنشورات
    renderPostsManagement() {
        const currentLang = getCurrentLanguage();
        const posts = db.getData('posts');

        return `
            <div class="admin-section">
                <div class="section-header">
                    <h3>${currentLang === 'ar' ? 'إدارة المنشورات' : 'Posts Management'}</h3>
                    <button class="btn btn-primary" onclick="adminPanel.showAddPostModal()">
                        <i class="fas fa-plus"></i>
                        ${currentLang === 'ar' ? 'إضافة منشور جديد' : 'Add New Post'}
                    </button>
                </div>
                
                <div class="posts-list">
                    ${posts.map(post => `
                        <div class="post-admin-item" data-post-id="${post.id}">
                            <div class="post-content">
                                <h4>${currentLang === 'ar' ? post.title_ar : post.title_en}</h4>
                                <p>${currentLang === 'ar' ? post.content_ar : post.content_en}</p>
                                <div class="post-meta">
                                    <span class="post-date">
                                        <i class="fas fa-calendar"></i>
                                        ${formatDate(post.display_date)}
                                    </span>
                                    <span class="post-status ${post.is_active ? 'active' : 'inactive'}">
                                        <i class="fas ${post.is_active ? 'fa-eye' : 'fa-eye-slash'}"></i>
                                        ${post.is_active ? (currentLang === 'ar' ? 'مرئي' : 'Visible') : (currentLang === 'ar' ? 'مخفي' : 'Hidden')}
                                    </span>
                                </div>
                            </div>
                            <div class="post-actions">
                                <button onclick="adminPanel.editPost('${post.id}')" class="btn btn-primary">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button onclick="adminPanel.togglePostStatus('${post.id}')" 
                                        class="btn ${post.is_active ? 'btn-warning' : 'btn-success'}">
                                    <i class="fas ${post.is_active ? 'fa-eye-slash' : 'fa-eye'}"></i>
                                </button>
                                <button onclick="adminPanel.deletePost('${post.id}')" class="btn btn-danger">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }

    // رسم إدارة الصور
    renderImagesManagement() {
        const currentLang = getCurrentLanguage();
        const images = db.getData('temp_images');
        const activeImages = images.filter(img => new Date(img.expires_at) > new Date());

        return `
            <div class="admin-section">
                <div class="section-header">
                    <h3>${currentLang === 'ar' ? 'إدارة الصور المعروضة' : 'Displayed Images Management'}</h3>
                    <div class="section-info">
                        <span class="info-badge">
                            ${activeImages.length} ${currentLang === 'ar' ? 'صورة نشطة' : 'active images'}
                        </span>
                    </div>
                </div>
                
                <div class="images-grid">
                    ${activeImages.map(image => {
                        const user = db.findItem('users', { id: image.user_id });
                        const timeRemaining = profileImage.getTimeRemaining(image.expires_at);
                        
                        return `
                            <div class="image-admin-item" data-image-id="${image.id}">
                                <div class="image-preview">
                                    <img src="${image.image_url}" alt="User Image">
                                    <div class="image-overlay">
                                        <button onclick="adminPanel.deleteImage('${image.id}')" 
                                                class="btn btn-danger btn-sm">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="image-info">
                                    <div class="image-user">
                                        <i class="fas fa-user"></i>
                                        ${user ? user.username : (currentLang === 'ar' ? 'مستخدم محذوف' : 'Deleted User')}
                                    </div>
                                    <div class="image-time">
                                        <i class="fas fa-clock"></i>
                                        ${timeRemaining ? 
                                            `${timeRemaining.hours}${currentLang === 'ar' ? 'س' : 'h'} ${timeRemaining.minutes}${currentLang === 'ar' ? 'د' : 'm'}` : 
                                            (currentLang === 'ar' ? 'منتهية الصلاحية' : 'Expired')
                                        }
                                    </div>
                                    <div class="image-date">
                                        <i class="fas fa-calendar"></i>
                                        ${formatDate(image.created_at)}
                                    </div>
                                </div>
                            </div>
                        `;
                    }).join('')}
                </div>
                
                ${activeImages.length === 0 ? `
                    <div class="no-data">
                        <i class="fas fa-images"></i>
                        <h4>${currentLang === 'ar' ? 'لا توجد صور معروضة حالياً' : 'No images currently displayed'}</h4>
                    </div>
                ` : ''}
            </div>
        `;
    }

    // رسم إدارة التعليقات
    renderCommentsManagement() {
        const currentLang = getCurrentLanguage();
        const comments = db.getData('comments');

        return `
            <div class="admin-section">
                <div class="section-header">
                    <h3>${currentLang === 'ar' ? 'إدارة التعليقات' : 'Comments Management'}</h3>
                    <div class="section-actions">
                        <select onchange="adminPanel.filterComments(this.value)">
                            <option value="all">${currentLang === 'ar' ? 'جميع التعليقات' : 'All Comments'}</option>
                            <option value="approved">${currentLang === 'ar' ? 'المعتمدة' : 'Approved'}</option>
                            <option value="pending">${currentLang === 'ar' ? 'في الانتظار' : 'Pending'}</option>
                        </select>
                    </div>
                </div>
                
                <div class="comments-list" id="admin-comments-list">
                    ${comments.map(comment => {
                        const user = db.findItem('users', { id: comment.user_id });
                        return `
                            <div class="comment-admin-item ${comment.is_approved ? 'approved' : 'pending'}" data-comment-id="${comment.id}">
                                <div class="comment-header">
                                    <div class="comment-user">
                                        ${user && user.profile_image ? 
                                            `<img src="${user.profile_image}" alt="${user.username}" class="user-avatar-small">` : 
                                            `<div class="user-avatar-placeholder-small"><i class="fas fa-user"></i></div>`
                                        }
                                        <span class="username">${user ? user.username : (currentLang === 'ar' ? 'مستخدم محذوف' : 'Deleted User')}</span>
                                        <span class="comment-date">${formatDate(comment.created_at)} ${formatTime(comment.created_at)}</span>
                                    </div>
                                    <div class="comment-status">
                                        <span class="status-badge ${comment.is_approved ? 'approved' : 'pending'}">
                                            ${comment.is_approved ? (currentLang === 'ar' ? 'معتمد' : 'Approved') : (currentLang === 'ar' ? 'في الانتظار' : 'Pending')}
                                        </span>
                                    </div>
                                </div>
                                <div class="comment-content">
                                    ${comment.content}
                                </div>
                                <div class="comment-actions">
                                    ${!comment.is_approved ? `
                                        <button onclick="adminPanel.approveComment('${comment.id}')" class="btn btn-success btn-sm">
                                            <i class="fas fa-check"></i>
                                            ${currentLang === 'ar' ? 'اعتماد' : 'Approve'}
                                        </button>
                                    ` : ''}
                                    <button onclick="adminPanel.deleteComment('${comment.id}')" class="btn btn-danger btn-sm">
                                        <i class="fas fa-trash"></i>
                                        ${currentLang === 'ar' ? 'حذف' : 'Delete'}
                                    </button>
                                </div>
                            </div>
                        `;
                    }).join('')}
                </div>
            </div>
        `;
    }

    // رسم إعدادات الموقع
    renderSiteSettings() {
        const currentLang = getCurrentLanguage();
        const settings = db.getData('site_settings');
        
        const settingsMap = {};
        settings.forEach(setting => {
            settingsMap[setting.key] = setting.value;
        });

        return `
            <div class="admin-section">
                <h3>${currentLang === 'ar' ? 'إعدادات الموقع' : 'Site Settings'}</h3>
                
                <form class="settings-form" onsubmit="adminPanel.saveSettings(event)">
                    <div class="settings-group">
                        <h4>${currentLang === 'ar' ? 'إعدادات عامة' : 'General Settings'}</h4>
                        
                        <div class="form-group">
                            <label>${currentLang === 'ar' ? 'عنوان الموقع (عربي)' : 'Site Title (Arabic)'}</label>
                            <input type="text" name="site_title_ar" value="${settingsMap.site_title_ar || 'موقع الأدوات الذكية'}">
                        </div>
                        
                        <div class="form-group">
                            <label>${currentLang === 'ar' ? 'عنوان الموقع (إنجليزي)' : 'Site Title (English)'}</label>
                            <input type="text" name="site_title_en" value="${settingsMap.site_title_en || 'Smart Tools Website'}">
                        </div>
                        
                        <div class="form-group">
                            <label>${currentLang === 'ar' ? 'الحد اليومي للنقاط' : 'Daily Points Limit'}</label>
                            <input type="number" name="daily_points_limit" value="${settingsMap.daily_points_limit || 75}" min="0">
                        </div>
                        
                        <div class="form-group">
                            <label>${currentLang === 'ar' ? 'حجم لوحة المتصدرين' : 'Leaderboard Size'}</label>
                            <input type="number" name="leaderboard_size" value="${settingsMap.leaderboard_size || 10}" min="5" max="50">
                        </div>
                    </div>
                    
                    <div class="settings-group">
                        <h4>${currentLang === 'ar' ? 'إعدادات الأدوات' : 'Tools Settings'}</h4>
                        
                        <div class="form-group">
                            <label>${currentLang === 'ar' ? 'نقاط الأداة الأساسية' : 'Basic Tool Points'}</label>
                            <input type="number" name="basic_tool_points" value="${settingsMap.basic_tool_points || 25}" min="1">
                        </div>
                        
                        <div class="form-group">
                            <label>${currentLang === 'ar' ? 'نقاط فتح الأداة المتقدمة' : 'Advanced Tool Unlock Points'}</label>
                            <input type="number" name="advanced_tool_points" value="${settingsMap.advanced_tool_points || 200}" min="100">
                        </div>
                        
                        <div class="form-group">
                            <label>${currentLang === 'ar' ? 'نقاط عرض الصورة' : 'Image Display Points'}</label>
                            <input type="number" name="image_display_points" value="${settingsMap.image_display_points || 500}" min="200">
                        </div>
                    </div>
                    
                    <div class="settings-group">
                        <h4>${currentLang === 'ar' ? 'إعدادات المحتوى' : 'Content Settings'}</h4>
                        
                        <div class="form-group">
                            <label>${currentLang === 'ar' ? 'عدد المنشورات اليومية' : 'Daily Posts Count'}</label>
                            <input type="number" name="daily_posts_count" value="${settingsMap.daily_posts_count || 3}" min="1" max="10">
                        </div>
                        
                        <div class="form-group">
                            <label>${currentLang === 'ar' ? 'مدة عرض الصور (ساعات)' : 'Image Display Duration (hours)'}</label>
                            <input type="number" name="image_display_duration" value="${settingsMap.image_display_duration || 24}" min="1" max="168">
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i>
                        ${currentLang === 'ar' ? 'حفظ الإعدادات' : 'Save Settings'}
                    </button>
                </form>
            </div>
        `;
    }

    // رسم تخصيص التصميم
    renderDesignCustomization() {
        const currentLang = getCurrentLanguage();

        return `
            <div class="admin-section">
                <h3>${currentLang === 'ar' ? 'تخصيص التصميم' : 'Design Customization'}</h3>
                
                <div class="design-tabs">
                    <div class="tab-buttons">
                        <button class="tab-btn active" onclick="adminPanel.switchDesignTab('colors')">
                            ${currentLang === 'ar' ? 'الألوان' : 'Colors'}
                        </button>
                        <button class="tab-btn" onclick="adminPanel.switchDesignTab('layout')">
                            ${currentLang === 'ar' ? 'التخطيط' : 'Layout'}
                        </button>
                        <button class="tab-btn" onclick="adminPanel.switchDesignTab('fonts')">
                            ${currentLang === 'ar' ? 'الخطوط' : 'Fonts'}
                        </button>
                    </div>
                    
                    <div class="tab-content" id="design-tab-content">
                        ${this.renderColorsTab()}
                    </div>
                </div>
            </div>
        `;
    }

    // رسم تبويب الألوان
    renderColorsTab() {
        const currentLang = getCurrentLanguage();

        return `
            <div class="colors-section">
                <h4>${currentLang === 'ar' ? 'نظام الألوان' : 'Color Scheme'}</h4>
                
                <div class="color-groups">
                    <div class="color-group">
                        <label>${currentLang === 'ar' ? 'اللون الأساسي' : 'Primary Color'}</label>
                        <input type="color" id="primary-color" value="#667eea" onchange="adminPanel.updateColor('primary', this.value)">
                    </div>
                    
                    <div class="color-group">
                        <label>${currentLang === 'ar' ? 'اللون الثانوي' : 'Secondary Color'}</label>
                        <input type="color" id="secondary-color" value="#764ba2" onchange="adminPanel.updateColor('secondary', this.value)">
                    </div>
                    
                    <div class="color-group">
                        <label>${currentLang === 'ar' ? 'لون الخلفية' : 'Background Color'}</label>
                        <input type="color" id="background-color" value="#f8f9fa" onchange="adminPanel.updateColor('background', this.value)">
                    </div>
                    
                    <div class="color-group">
                        <label>${currentLang === 'ar' ? 'لون النص' : 'Text Color'}</label>
                        <input type="color" id="text-color" value="#333333" onchange="adminPanel.updateColor('text', this.value)">
                    </div>
                </div>
                
                <div class="color-presets">
                    <h5>${currentLang === 'ar' ? 'قوالب جاهزة' : 'Color Presets'}</h5>
                    <div class="preset-buttons">
                        <button onclick="adminPanel.applyColorPreset('blue')" class="preset-btn blue">
                            ${currentLang === 'ar' ? 'أزرق' : 'Blue'}
                        </button>
                        <button onclick="adminPanel.applyColorPreset('green')" class="preset-btn green">
                            ${currentLang === 'ar' ? 'أخضر' : 'Green'}
                        </button>
                        <button onclick="adminPanel.applyColorPreset('purple')" class="preset-btn purple">
                            ${currentLang === 'ar' ? 'بنفسجي' : 'Purple'}
                        </button>
                        <button onclick="adminPanel.applyColorPreset('orange')" class="preset-btn orange">
                            ${currentLang === 'ar' ? 'برتقالي' : 'Orange'}
                        </button>
                    </div>
                </div>
            </div>
        `;
    }

    // الحصول على إحصائيات الموقع
    getWebsiteStats() {
        const users = db.getData('users');
        const comments = db.getData('comments');
        const pointsHistory = db.getData('points_history');
        
        const today = new Date().toISOString().split('T')[0];
        const todayPoints = pointsHistory.filter(p => p.date === today);
        
        return {
            totalUsers: users.length,
            totalPoints: users.reduce((sum, user) => sum + user.points, 0),
            toolUsageToday: todayPoints.length,
            totalComments: comments.length
        };
    }

    // رسم النشاط الأخير
    renderRecentActivity() {
        const currentLang = getCurrentLanguage();
        const recentUsers = db.getData('users').slice(-5).reverse();
        const recentComments = db.getData('comments').slice(-3).reverse();
        
        let activities = [];
        
        recentUsers.forEach(user => {
            activities.push({
                type: 'user_joined',
                icon: 'fas fa-user-plus',
                text: currentLang === 'ar' ? 
                    `انضم المستخدم ${user.username}` : 
                    `User ${user.username} joined`,
                time: user.created_at
            });
        });
        
        recentComments.forEach(comment => {
            const user = db.findItem('users', { id: comment.user_id });
            activities.push({
                type: 'comment_added',
                icon: 'fas fa-comment',
                text: currentLang === 'ar' ? 
                    `أضاف ${user ? user.username : 'مستخدم'} تعليقاً` : 
                    `${user ? user.username : 'User'} added a comment`,
                time: comment.created_at
            });
        });
        
        activities.sort((a, b) => new Date(b.time) - new Date(a.time));
        activities = activities.slice(0, 10);
        
        return activities.map(activity => `
            <div class="activity-item">
                <div class="activity-icon">
                    <i class="${activity.icon}"></i>
                </div>
                <div class="activity-content">
                    <span class="activity-text">${activity.text}</span>
                    <span class="activity-time">${formatTime(activity.time)}</span>
                </div>
            </div>
        `).join('');
    }

    // تحديث نقاط المستخدم
    updateUserPoints(userId, newPoints) {
        const points = parseInt(newPoints);
        if (isNaN(points) || points < 0) return;
        
        const success = db.updateItem('users', userId, { points: points });
        if (success) {
            showNotification(
                getCurrentLanguage() === 'ar' ? 'تم تحديث النقاط' : 'Points updated',
                'success'
            );
            updateUserInterface();
        }
    }

    // تبديل حالة الإدارة للمستخدم
    toggleAdminStatus(userId) {
        const user = db.findItem('users', { id: userId });
        if (!user) return;
        
        const currentLang = getCurrentLanguage();
        const confirmMessage = user.is_admin ? 
            (currentLang === 'ar' ? 'هل تريد إزالة صلاحية الإدارة؟' : 'Remove admin privileges?') :
            (currentLang === 'ar' ? 'هل تريد منح صلاحية الإدارة؟' : 'Grant admin privileges?');
        
        if (!confirm(confirmMessage)) return;
        
        const success = db.updateItem('users', userId, { is_admin: !user.is_admin });
        if (success) {
            showNotification(
                currentLang === 'ar' ? 'تم تحديث الصلاحيات' : 'Privileges updated',
                'success'
            );
            this.render();
        }
    }

    // حذف مستخدم
    deleteUser(userId) {
        const currentUser = auth.getCurrentUser();
        if (currentUser && currentUser.id === userId) {
            showNotification(
                getCurrentLanguage() === 'ar' ? 'لا يمكن حذف حسابك الخاص' : 'Cannot delete your own account',
                'error'
            );
            return;
        }
        
        const currentLang = getCurrentLanguage();
        if (!confirm(currentLang === 'ar' ? 'هل أنت متأكد من حذف هذا المستخدم؟' : 'Are you sure you want to delete this user?')) {
            return;
        }
        
        const success = db.deleteItem('users', userId);
        if (success) {
            // حذف بيانات المستخدم المرتبطة
            db.deleteItems('user_tasks', { user_id: userId });
            db.deleteItems('points_history', { user_id: userId });
            db.deleteItems('comments', { user_id: userId });
            db.deleteItems('temp_images', { user_id: userId });
            
            showNotification(
                currentLang === 'ar' ? 'تم حذف المستخدم' : 'User deleted',
                'success'
            );
            this.render();
        }
    }

    // حذف صورة
    deleteImage(imageId) {
        const currentLang = getCurrentLanguage();
        if (!confirm(currentLang === 'ar' ? 'هل تريد حذف هذه الصورة؟' : 'Delete this image?')) {
            return;
        }
        
        const success = db.deleteItem('temp_images', imageId);
        if (success) {
            showNotification(
                currentLang === 'ar' ? 'تم حذف الصورة' : 'Image deleted',
                'success'
            );
            this.render();
        }
    }

    // اعتماد تعليق
    approveComment(commentId) {
        const success = commentsSystem.approveComment(commentId);
        if (success) {
            showNotification(
                getCurrentLanguage() === 'ar' ? 'تم اعتماد التعليق' : 'Comment approved',
                'success'
            );
            this.render();
            updateCommentsDisplay();
        }
    }

    // حذف تعليق
    deleteComment(commentId) {
        const currentLang = getCurrentLanguage();
        if (!confirm(currentLang === 'ar' ? 'هل تريد حذف هذا التعليق؟' : 'Delete this comment?')) {
            return;
        }
        
        const success = commentsSystem.deleteComment(commentId, null);
        if (success) {
            showNotification(
                currentLang === 'ar' ? 'تم حذف التعليق' : 'Comment deleted',
                'success'
            );
            this.render();
            updateCommentsDisplay();
        }
    }

    // حفظ الإعدادات
    saveSettings(event) {
        event.preventDefault();
        const formData = new FormData(event.target);
        
        for (let [key, value] of formData.entries()) {
            db.updateSetting(key, value);
        }
        
        showNotification(
            getCurrentLanguage() === 'ar' ? 'تم حفظ الإعدادات' : 'Settings saved',
            'success'
        );
        
        // إعادة تحميل الموقع لتطبيق الإعدادات
        setTimeout(() => location.reload(), 1000);
    }

    // تحديث لون
    updateColor(colorType, colorValue) {
        document.documentElement.style.setProperty(`--${colorType}-color`, colorValue);
        
        // حفظ اللون في الإعدادات
        db.updateSetting(`${colorType}_color`, colorValue);
    }

    // تطبيق قالب ألوان
    applyColorPreset(preset) {
        const presets = {
            blue: {
                primary: '#667eea',
                secondary: '#764ba2',
                background: '#f8f9fa',
                text: '#333333'
            },
            green: {
                primary: '#4caf50',
                secondary: '#45a049',
                background: '#f1f8e9',
                text: '#2e7d32'
            },
            purple: {
                primary: '#9c27b0',
                secondary: '#7b1fa2',
                background: '#f3e5f5',
                text: '#4a148c'
            },
            orange: {
                primary: '#ff9800',
                secondary: '#f57c00',
                background: '#fff3e0',
                text: '#e65100'
            }
        };
        
        const colors = presets[preset];
        if (colors) {
            Object.keys(colors).forEach(colorType => {
                this.updateColor(colorType, colors[colorType]);
                const input = document.getElementById(`${colorType}-color`);
                if (input) input.value = colors[colorType];
            });
        }
    }
}

// إنشاء مثيل من لوحة الإدارة
const adminPanel = new AdminPanel();

// دالة عرض لوحة الإدارة
function showAdminPanel() {
    adminPanel.show();
}

// تصدير للاستخدام العام
window.adminPanel = adminPanel;
window.showAdminPanel = showAdminPanel;

