// أنظمة الربح والدعم
class MonetizationSystem {
    constructor() {
        this.adBlockDetected = false;
        this.supportMethods = [];
        this.externalLinks = [];
        this.analyticsEnabled = true;
        this.init();
    }

    // تهيئة النظام
    init() {
        this.detectAdBlock();
        this.setupAnalytics();
        this.loadSupportMethods();
        this.loadExternalLinks();
        this.setupDonationSystem();
    }

    // كشف مانع الإعلانات
    detectAdBlock() {
        // إنشاء عنصر وهمي لاختبار مانع الإعلانات
        const testAd = document.createElement('div');
        testAd.innerHTML = '&nbsp;';
        testAd.className = 'adsbox';
        testAd.style.position = 'absolute';
        testAd.style.left = '-10000px';
        document.body.appendChild(testAd);

        setTimeout(() => {
            if (testAd.offsetHeight === 0) {
                this.adBlockDetected = true;
                this.showAdBlockMessage();
            }
            document.body.removeChild(testAd);
        }, 100);
    }

    // عرض رسالة مانع الإعلانات
    showAdBlockMessage() {
        const currentLang = getCurrentLanguage();
        const message = currentLang === 'ar' ? 
            'يبدو أنك تستخدم مانع الإعلانات. الإعلانات تساعدنا في تطوير الموقع وإضافة المزيد من الأدوات المجانية.' :
            'It looks like you\'re using an ad blocker. Ads help us develop the site and add more free tools.';

        const supportMessage = currentLang === 'ar' ? 
            'يمكنك دعمنا بطرق أخرى!' : 
            'You can support us in other ways!';

        const notification = document.createElement('div');
        notification.className = 'adblock-notification';
        notification.innerHTML = `
            <div class="adblock-content">
                <div class="adblock-icon">
                    <i class="fas fa-ad"></i>
                </div>
                <div class="adblock-message">
                    <h4>${currentLang === 'ar' ? 'مانع الإعلانات مُفعل' : 'Ad Blocker Detected'}</h4>
                    <p>${message}</p>
                    <p><strong>${supportMessage}</strong></p>
                </div>
                <div class="adblock-actions">
                    <button onclick="showSupportModal()" class="btn btn-primary">
                        <i class="fas fa-heart"></i>
                        ${currentLang === 'ar' ? 'ادعمنا' : 'Support Us'}
                    </button>
                    <button onclick="this.parentElement.parentElement.parentElement.remove()" class="btn btn-secondary">
                        <i class="fas fa-times"></i>
                        ${currentLang === 'ar' ? 'إغلاق' : 'Close'}
                    </button>
                </div>
            </div>
        `;

        document.body.appendChild(notification);

        // إزالة الإشعار تلقائياً بعد 15 ثانية
        setTimeout(() => {
            if (notification.parentElement) {
                notification.remove();
            }
        }, 15000);
    }

    // إعداد التحليلات
    setupAnalytics() {
        if (!this.analyticsEnabled) return;

        // Google Analytics (مثال - يجب استبدال GA_MEASUREMENT_ID بالمعرف الحقيقي)
        const script = document.createElement('script');
        script.async = true;
        script.src = 'https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID';
        document.head.appendChild(script);

        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', 'GA_MEASUREMENT_ID');

        // تتبع الأحداث المخصصة
        this.trackEvent('page_view', {
            page_title: document.title,
            page_location: window.location.href
        });
    }

    // تتبع الأحداث
    trackEvent(eventName, parameters = {}) {
        if (typeof gtag !== 'undefined') {
            gtag('event', eventName, parameters);
        }
        
        // يمكن إضافة أنظمة تحليلات أخرى هنا
        console.log('Event tracked:', eventName, parameters);
    }

    // تحميل طرق الدعم
    loadSupportMethods() {
        this.supportMethods = [
            {
                id: 'paypal',
                name_ar: 'PayPal',
                name_en: 'PayPal',
                icon: 'fab fa-paypal',
                color: '#0070ba',
                url: 'https://paypal.me/yourusername', // يجب تغييرها
                description_ar: 'ادعمنا عبر PayPal',
                description_en: 'Support us via PayPal'
            },
            {
                id: 'patreon',
                name_ar: 'Patreon',
                name_en: 'Patreon',
                icon: 'fab fa-patreon',
                color: '#f96854',
                url: 'https://patreon.com/yourusername', // يجب تغييرها
                description_ar: 'ادعمنا شهرياً على Patreon',
                description_en: 'Support us monthly on Patreon'
            },
            {
                id: 'kofi',
                name_ar: 'Ko-fi',
                name_en: 'Ko-fi',
                icon: 'fas fa-coffee',
                color: '#ff5f5f',
                url: 'https://ko-fi.com/yourusername', // يجب تغييرها
                description_ar: 'اشتري لنا قهوة على Ko-fi',
                description_en: 'Buy us a coffee on Ko-fi'
            },
            {
                id: 'github',
                name_ar: 'GitHub Sponsors',
                name_en: 'GitHub Sponsors',
                icon: 'fab fa-github',
                color: '#333',
                url: 'https://github.com/sponsors/yourusername', // يجب تغييرها
                description_ar: 'ادعمنا على GitHub Sponsors',
                description_en: 'Support us on GitHub Sponsors'
            }
        ];
    }

    // تحميل الروابط الخارجية
    loadExternalLinks() {
        this.externalLinks = [
            {
                id: 'website',
                name_ar: 'موقعنا الرسمي',
                name_en: 'Our Official Website',
                icon: 'fas fa-globe',
                url: 'https://yourwebsite.com', // يجب تغييرها
                description_ar: 'زيارة موقعنا الرسمي',
                description_en: 'Visit our official website'
            },
            {
                id: 'blog',
                name_ar: 'مدونتنا',
                name_en: 'Our Blog',
                icon: 'fas fa-blog',
                url: 'https://yourblog.com', // يجب تغييرها
                description_ar: 'اقرأ آخر المقالات والتحديثات',
                description_en: 'Read latest articles and updates'
            },
            {
                id: 'youtube',
                name_ar: 'قناة YouTube',
                name_en: 'YouTube Channel',
                icon: 'fab fa-youtube',
                url: 'https://youtube.com/yourchannel', // يجب تغييرها
                description_ar: 'شاهد الفيديوهات التعليمية',
                description_en: 'Watch tutorial videos'
            },
            {
                id: 'twitter',
                name_ar: 'تويتر',
                name_en: 'Twitter',
                icon: 'fab fa-twitter',
                url: 'https://twitter.com/yourusername', // يجب تغييرها
                description_ar: 'تابعنا على تويتر',
                description_en: 'Follow us on Twitter'
            }
        ];
    }

    // إعداد نظام التبرع
    setupDonationSystem() {
        // إضافة زر الدعم في الفوتر
        this.addSupportButton();
        
        // إضافة نافذة الدعم
        this.createSupportModal();
        
        // إضافة قسم الروابط الخارجية
        this.addExternalLinksSection();
    }

    // إضافة زر الدعم
    addSupportButton() {
        const currentLang = getCurrentLanguage();
        const footer = document.querySelector('.footer');
        
        if (footer) {
            const supportSection = document.createElement('div');
            supportSection.className = 'support-section';
            supportSection.innerHTML = `
                <div class="support-content">
                    <h4 id="support-title">${currentLang === 'ar' ? 'ادعمنا' : 'Support Us'}</h4>
                    <p>${currentLang === 'ar' ? 'ساعدنا في تطوير الموقع وإضافة المزيد من الأدوات' : 'Help us develop the site and add more tools'}</p>
                    <button onclick="showSupportModal()" class="support-btn">
                        <i class="fas fa-heart"></i>
                        <span id="support-btn-text">${currentLang === 'ar' ? 'ادعمني' : 'Support Me'}</span>
                    </button>
                </div>
            `;
            
            footer.appendChild(supportSection);
        }
    }

    // إنشاء نافذة الدعم
    createSupportModal() {
        const currentLang = getCurrentLanguage();
        const modal = document.createElement('div');
        modal.id = 'support-modal';
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content support-modal-content">
                <div class="modal-header">
                    <h3 id="support-modal-title">${currentLang === 'ar' ? 'ادعمنا' : 'Support Us'}</h3>
                    <button class="close-btn" onclick="closeModal('support-modal')">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="support-intro">
                        <p id="support-desc">${currentLang === 'ar' ? 'ساعدنا في تطوير الموقع وإضافة المزيد من الأدوات' : 'Help us develop the site and add more tools'}</p>
                    </div>
                    
                    <div class="support-methods">
                        <h4>${currentLang === 'ar' ? 'طرق الدعم' : 'Support Methods'}</h4>
                        <div class="support-grid">
                            ${this.supportMethods.map(method => `
                                <a href="${method.url}" target="_blank" rel="noopener noreferrer" 
                                   class="support-method" style="border-color: ${method.color}">
                                    <div class="support-icon" style="color: ${method.color}">
                                        <i class="${method.icon}"></i>
                                    </div>
                                    <div class="support-info">
                                        <h5>${currentLang === 'ar' ? method.name_ar : method.name_en}</h5>
                                        <p>${currentLang === 'ar' ? method.description_ar : method.description_en}</p>
                                    </div>
                                </a>
                            `).join('')}
                        </div>
                    </div>
                    
                    <div class="support-alternatives">
                        <h4>${currentLang === 'ar' ? 'طرق أخرى للدعم' : 'Other Ways to Support'}</h4>
                        <div class="alternatives-list">
                            <div class="alternative-item">
                                <i class="fas fa-share-alt"></i>
                                <span>${currentLang === 'ar' ? 'شارك الموقع مع أصدقائك' : 'Share the site with your friends'}</span>
                            </div>
                            <div class="alternative-item">
                                <i class="fas fa-star"></i>
                                <span>${currentLang === 'ar' ? 'قيم الموقع واتركلنا تعليقاً إيجابياً' : 'Rate the site and leave us a positive comment'}</span>
                            </div>
                            <div class="alternative-item">
                                <i class="fas fa-lightbulb"></i>
                                <span>${currentLang === 'ar' ? 'اقترح أدوات جديدة أو تحسينات' : 'Suggest new tools or improvements'}</span>
                            </div>
                            <div class="alternative-item">
                                <i class="fas fa-bug"></i>
                                <span>${currentLang === 'ar' ? 'أبلغ عن الأخطاء والمشاكل' : 'Report bugs and issues'}</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
    }

    // إضافة قسم الروابط الخارجية
    addExternalLinksSection() {
        const currentLang = getCurrentLanguage();
        const footer = document.querySelector('.footer');
        
        if (footer) {
            const linksSection = document.createElement('div');
            linksSection.className = 'external-links-section';
            linksSection.innerHTML = `
                <div class="external-links-content">
                    <h4 id="external-links-title">${currentLang === 'ar' ? 'روابط خارجية' : 'External Links'}</h4>
                    <div class="external-links-grid">
                        ${this.externalLinks.map(link => `
                            <a href="${link.url}" target="_blank" rel="noopener noreferrer" 
                               class="external-link" title="${currentLang === 'ar' ? link.description_ar : link.description_en}">
                                <i class="${link.icon}"></i>
                                <span>${currentLang === 'ar' ? link.name_ar : link.name_en}</span>
                            </a>
                        `).join('')}
                    </div>
                </div>
            `;
            
            footer.appendChild(linksSection);
        }
    }

    // إضافة إعلانات
    addAdvertisements() {
        if (this.adBlockDetected) return;

        // إعلان في الهيدر
        this.addHeaderAd();
        
        // إعلان في الشريط الجانبي
        this.addSidebarAd();
        
        // إعلان في الفوتر
        this.addFooterAd();
        
        // إعلانات بين المحتوى
        this.addContentAds();
    }

    // إضافة إعلان الهيدر
    addHeaderAd() {
        const header = document.querySelector('.header');
        if (!header) return;

        const adContainer = document.createElement('div');
        adContainer.className = 'ad-container header-ad';
        adContainer.innerHTML = `
            <div class="ad-label">${getCurrentLanguage() === 'ar' ? 'إعلان' : 'Advertisement'}</div>
            <div class="ad-content">
                <!-- هنا يتم وضع كود الإعلان من Google AdSense أو شبكة إعلانية أخرى -->
                <div class="placeholder-ad" style="width: 728px; height: 90px; background: #f0f0f0; display: flex; align-items: center; justify-content: center; border: 1px dashed #ccc;">
                    <span style="color: #666;">728x90 Banner Ad</span>
                </div>
            </div>
        `;

        header.appendChild(adContainer);
    }

    // إضافة إعلان الشريط الجانبي
    addSidebarAd() {
        const sidebar = document.querySelector('.sidebar') || document.querySelector('.main-content');
        if (!sidebar) return;

        const adContainer = document.createElement('div');
        adContainer.className = 'ad-container sidebar-ad';
        adContainer.innerHTML = `
            <div class="ad-label">${getCurrentLanguage() === 'ar' ? 'إعلان' : 'Advertisement'}</div>
            <div class="ad-content">
                <!-- هنا يتم وضع كود الإعلان -->
                <div class="placeholder-ad" style="width: 300px; height: 250px; background: #f0f0f0; display: flex; align-items: center; justify-content: center; border: 1px dashed #ccc; margin: 20px auto;">
                    <span style="color: #666;">300x250 Rectangle Ad</span>
                </div>
            </div>
        `;

        sidebar.appendChild(adContainer);
    }

    // إضافة إعلان الفوتر
    addFooterAd() {
        const footer = document.querySelector('.footer');
        if (!footer) return;

        const adContainer = document.createElement('div');
        adContainer.className = 'ad-container footer-ad';
        adContainer.innerHTML = `
            <div class="ad-label">${getCurrentLanguage() === 'ar' ? 'إعلان' : 'Advertisement'}</div>
            <div class="ad-content">
                <!-- هنا يتم وضع كود الإعلان -->
                <div class="placeholder-ad" style="width: 728px; height: 90px; background: #f0f0f0; display: flex; align-items: center; justify-content: center; border: 1px dashed #ccc; margin: 20px auto;">
                    <span style="color: #666;">728x90 Footer Banner</span>
                </div>
            </div>
        `;

        footer.insertBefore(adContainer, footer.firstChild);
    }

    // إضافة إعلانات بين المحتوى
    addContentAds() {
        const contentSections = document.querySelectorAll('.section, .tool-card, .post-card');
        
        contentSections.forEach((section, index) => {
            // إضافة إعلان كل 3 عناصر
            if ((index + 1) % 3 === 0) {
                const adContainer = document.createElement('div');
                adContainer.className = 'ad-container content-ad';
                adContainer.innerHTML = `
                    <div class="ad-label">${getCurrentLanguage() === 'ar' ? 'إعلان' : 'Advertisement'}</div>
                    <div class="ad-content">
                        <!-- هنا يتم وضع كود الإعلان -->
                        <div class="placeholder-ad" style="width: 100%; max-width: 468px; height: 60px; background: #f0f0f0; display: flex; align-items: center; justify-content: center; border: 1px dashed #ccc; margin: 20px auto;">
                            <span style="color: #666;">468x60 Banner Ad</span>
                        </div>
                    </div>
                `;
                
                section.parentNode.insertBefore(adContainer, section.nextSibling);
            }
        });
    }

    // تتبع النقرات على الروابط الخارجية
    trackExternalClick(linkId, url) {
        this.trackEvent('external_link_click', {
            link_id: linkId,
            link_url: url
        });
    }

    // تتبع التبرعات
    trackDonation(method, amount = null) {
        this.trackEvent('donation_click', {
            donation_method: method,
            amount: amount
        });
    }

    // تتبع استخدام الأدوات
    trackToolUsage(toolName) {
        this.trackEvent('tool_usage', {
            tool_name: toolName,
            user_id: auth.getCurrentUser()?.id || 'anonymous'
        });
    }

    // تتبع تسجيل المستخدمين الجدد
    trackUserRegistration(userId) {
        this.trackEvent('user_registration', {
            user_id: userId
        });
    }

    // تحديث طرق الدعم
    updateSupportMethods(methods) {
        this.supportMethods = methods;
        this.refreshSupportModal();
    }

    // تحديث الروابط الخارجية
    updateExternalLinks(links) {
        this.externalLinks = links;
        this.refreshExternalLinksSection();
    }

    // تحديث نافذة الدعم
    refreshSupportModal() {
        const modal = document.getElementById('support-modal');
        if (modal) {
            modal.remove();
            this.createSupportModal();
        }
    }

    // تحديث قسم الروابط الخارجية
    refreshExternalLinksSection() {
        const section = document.querySelector('.external-links-section');
        if (section) {
            section.remove();
            this.addExternalLinksSection();
        }
    }

    // الحصول على إحصائيات الربح
    getMonetizationStats() {
        return {
            adBlockDetected: this.adBlockDetected,
            supportMethodsCount: this.supportMethods.length,
            externalLinksCount: this.externalLinks.length,
            analyticsEnabled: this.analyticsEnabled
        };
    }
}

// إنشاء مثيل من نظام الربح
const monetizationSystem = new MonetizationSystem();

// دالة عرض نافذة الدعم
function showSupportModal() {
    document.getElementById('support-modal').style.display = 'block';
    
    // تتبع فتح نافذة الدعم
    monetizationSystem.trackEvent('support_modal_opened');
}

// دالة تتبع النقر على رابط الدعم
function trackSupportClick(method, url) {
    monetizationSystem.trackDonation(method);
    window.open(url, '_blank', 'noopener,noreferrer');
}

// دالة تتبع النقر على الروابط الخارجية
function trackExternalLinkClick(linkId, url) {
    monetizationSystem.trackExternalClick(linkId, url);
    window.open(url, '_blank', 'noopener,noreferrer');
}

// إضافة الإعلانات عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    // تأخير قصير لضمان تحميل جميع العناصر
    setTimeout(() => {
        monetizationSystem.addAdvertisements();
    }, 1000);
});

// تصدير للاستخدام العام
window.monetizationSystem = monetizationSystem;
window.showSupportModal = showSupportModal;
window.trackSupportClick = trackSupportClick;
window.trackExternalLinkClick = trackExternalLinkClick;

