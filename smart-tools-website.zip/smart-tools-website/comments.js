// نظام التعليقات
class CommentsSystem {
    constructor() {
        this.comments = [];
        this.loadComments();
    }

    // تحميل التعليقات
    loadComments() {
        this.comments = db.getData('comments');
    }

    // إضافة تعليق جديد
    addComment(content, userId) {
        if (!content || !content.trim()) {
            throw new Error(getCurrentLanguage() === 'ar' ? 'يرجى كتابة التعليق' : 'Please write a comment');
        }

        if (content.length > 500) {
            throw new Error(getCurrentLanguage() === 'ar' ? 'التعليق طويل جداً (الحد الأقصى 500 حرف)' : 'Comment too long (max 500 characters)');
        }

        const comment = {
            user_id: userId,
            content: content.trim(),
            is_approved: true, // الموافقة التلقائية للآن
            created_at: new Date().toISOString()
        };

        const savedComment = db.addItem('comments', comment);
        this.comments.push(savedComment);
        
        return savedComment;
    }

    // حذف تعليق
    deleteComment(commentId, userId) {
        const comment = this.comments.find(c => c.id === commentId);
        if (!comment) {
            throw new Error(getCurrentLanguage() === 'ar' ? 'التعليق غير موجود' : 'Comment not found');
        }

        const currentUser = auth.getCurrentUser();
        
        // التحقق من الصلاحيات (صاحب التعليق أو المدير)
        if (comment.user_id !== userId && (!currentUser || !currentUser.is_admin)) {
            throw new Error(getCurrentLanguage() === 'ar' ? 'ليس لديك صلاحية لحذف هذا التعليق' : 'You do not have permission to delete this comment');
        }

        const success = db.deleteItem('comments', commentId);
        if (success) {
            this.comments = this.comments.filter(c => c.id !== commentId);
        }
        
        return success;
    }

    // الحصول على التعليقات المعتمدة
    getApprovedComments() {
        return this.comments
            .filter(comment => comment.is_approved)
            .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
    }

    // الحصول على تعليقات المستخدم
    getUserComments(userId) {
        return this.comments
            .filter(comment => comment.user_id === userId)
            .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
    }

    // الحصول على إحصائيات التعليقات
    getCommentsStats() {
        const total = this.comments.length;
        const approved = this.comments.filter(c => c.is_approved).length;
        const pending = total - approved;
        const today = new Date().toISOString().split('T')[0];
        const todayComments = this.comments.filter(c => c.created_at.startsWith(today)).length;

        return { total, approved, pending, today: todayComments };
    }

    // اعتماد تعليق (للمدير)
    approveComment(commentId) {
        const comment = this.comments.find(c => c.id === commentId);
        if (!comment) return false;

        const updatedComment = db.updateItem('comments', commentId, { is_approved: true });
        if (updatedComment) {
            const index = this.comments.findIndex(c => c.id === commentId);
            if (index !== -1) {
                this.comments[index] = updatedComment;
            }
        }
        
        return !!updatedComment;
    }

    // رفض تعليق (للمدير)
    rejectComment(commentId) {
        return this.deleteComment(commentId, null);
    }

    // البحث في التعليقات
    searchComments(query) {
        if (!query || !query.trim()) return [];
        
        const searchTerm = query.toLowerCase().trim();
        return this.comments.filter(comment => 
            comment.content.toLowerCase().includes(searchTerm) && comment.is_approved
        );
    }

    // تصفية التعليقات حسب التاريخ
    getCommentsByDateRange(startDate, endDate) {
        const start = new Date(startDate);
        const end = new Date(endDate);
        
        return this.comments.filter(comment => {
            const commentDate = new Date(comment.created_at);
            return commentDate >= start && commentDate <= end && comment.is_approved;
        });
    }

    // عرض نظام التعليقات
    renderComments() {
        const comments = this.getApprovedComments();
        const currentLang = getCurrentLanguage();
        const currentUser = auth.getCurrentUser();
        
        if (comments.length === 0) {
            return `
                <div class="no-comments">
                    <i class="fas fa-comments"></i>
                    <h4>${currentLang === 'ar' ? 'لا توجد تعليقات بعد' : 'No comments yet'}</h4>
                    <p>${currentLang === 'ar' ? 'كن أول من يعلق!' : 'Be the first to comment!'}</p>
                </div>
            `;
        }

        return comments.map(comment => {
            const user = db.findItem('users', { id: comment.user_id });
            const userName = user ? user.username : (currentLang === 'ar' ? 'مستخدم محذوف' : 'Deleted User');
            const commentDate = formatDate(comment.created_at);
            const commentTime = formatTime(comment.created_at);
            const canDelete = currentUser && (currentUser.id === comment.user_id || currentUser.is_admin);

            return `
                <div class="comment-item" data-comment-id="${comment.id}">
                    <div class="comment-header">
                        <div class="comment-author">
                            <div class="author-avatar">
                                ${user && user.profile_image ? 
                                    `<img src="${user.profile_image}" alt="${userName}">` : 
                                    `<i class="fas fa-user"></i>`
                                }
                            </div>
                            <div class="author-info">
                                <span class="author-name">${userName}</span>
                                <span class="comment-date">${commentDate} ${commentTime}</span>
                            </div>
                        </div>
                        ${canDelete ? `
                            <div class="comment-actions">
                                <button class="delete-comment-btn" onclick="deleteComment('${comment.id}')" title="${currentLang === 'ar' ? 'حذف التعليق' : 'Delete comment'}">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        ` : ''}
                    </div>
                    <div class="comment-content">${this.formatCommentContent(comment.content)}</div>
                </div>
            `;
        }).join('');
    }

    // تنسيق محتوى التعليق
    formatCommentContent(content) {
        // تحويل الروابط إلى روابط قابلة للنقر
        const urlRegex = /(https?:\/\/[^\s]+)/g;
        content = content.replace(urlRegex, '<a href="$1" target="_blank" rel="noopener noreferrer">$1</a>');
        
        // تحويل أسطر جديدة إلى <br>
        content = content.replace(/\n/g, '<br>');
        
        return content;
    }
}

// إنشاء مثيل من نظام التعليقات
const commentsSystem = new CommentsSystem();

// دالة إضافة تعليق
function addComment() {
    const currentUser = auth.getCurrentUser();
    if (!currentUser) {
        showNotification(getCurrentLanguage() === 'ar' ? 'يجب تسجيل الدخول أولاً' : 'Please login first', 'error');
        return;
    }

    const commentText = document.getElementById('comment-text');
    const content = commentText.value.trim();
    
    if (!content) {
        showNotification(getCurrentLanguage() === 'ar' ? 'يرجى كتابة التعليق' : 'Please write a comment', 'warning');
        return;
    }

    try {
        commentsSystem.addComment(content, currentUser.id);
        commentText.value = '';
        updateCommentsDisplay();
        
        showNotification(
            getCurrentLanguage() === 'ar' ? 'تم إضافة التعليق بنجاح' : 'Comment added successfully',
            'success'
        );
    } catch (error) {
        showNotification(error.message, 'error');
    }
}

// دالة حذف تعليق
function deleteComment(commentId) {
    const currentUser = auth.getCurrentUser();
    if (!currentUser) {
        showNotification(getCurrentLanguage() === 'ar' ? 'يجب تسجيل الدخول أولاً' : 'Please login first', 'error');
        return;
    }

    const currentLang = getCurrentLanguage();
    const confirmMessage = currentLang === 'ar' ? 'هل أنت متأكد من حذف هذا التعليق؟' : 'Are you sure you want to delete this comment?';
    
    if (!confirm(confirmMessage)) return;

    try {
        commentsSystem.deleteComment(commentId, currentUser.id);
        updateCommentsDisplay();
        
        showNotification(
            currentLang === 'ar' ? 'تم حذف التعليق' : 'Comment deleted',
            'success'
        );
    } catch (error) {
        showNotification(error.message, 'error');
    }
}

// دالة تحديث عرض التعليقات
function updateCommentsDisplay() {
    const commentsContainer = document.getElementById('comments-list');
    if (!commentsContainer) return;
    
    commentsContainer.innerHTML = commentsSystem.renderComments();
}

// دالة البحث في التعليقات
function searchComments(query) {
    const results = commentsSystem.searchComments(query);
    const commentsContainer = document.getElementById('comments-list');
    const currentLang = getCurrentLanguage();
    
    if (!commentsContainer) return;
    
    if (results.length === 0) {
        commentsContainer.innerHTML = `
            <div class="no-comments">
                <i class="fas fa-search"></i>
                <h4>${currentLang === 'ar' ? 'لا توجد نتائج' : 'No results found'}</h4>
                <p>${currentLang === 'ar' ? 'جرب كلمات بحث أخرى' : 'Try different search terms'}</p>
            </div>
        `;
        return;
    }
    
    // عرض نتائج البحث بنفس تنسيق التعليقات العادية
    const currentUser = auth.getCurrentUser();
    commentsContainer.innerHTML = results.map(comment => {
        const user = db.findItem('users', { id: comment.user_id });
        const userName = user ? user.username : (currentLang === 'ar' ? 'مستخدم محذوف' : 'Deleted User');
        const commentDate = formatDate(comment.created_at);
        const commentTime = formatTime(comment.created_at);
        const canDelete = currentUser && (currentUser.id === comment.user_id || currentUser.is_admin);

        return `
            <div class="comment-item search-result" data-comment-id="${comment.id}">
                <div class="comment-header">
                    <div class="comment-author">
                        <div class="author-avatar">
                            ${user && user.profile_image ? 
                                `<img src="${user.profile_image}" alt="${userName}">` : 
                                `<i class="fas fa-user"></i>`
                            }
                        </div>
                        <div class="author-info">
                            <span class="author-name">${userName}</span>
                            <span class="comment-date">${commentDate} ${commentTime}</span>
                        </div>
                    </div>
                    ${canDelete ? `
                        <div class="comment-actions">
                            <button class="delete-comment-btn" onclick="deleteComment('${comment.id}')" title="${currentLang === 'ar' ? 'حذف التعليق' : 'Delete comment'}">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    ` : ''}
                </div>
                <div class="comment-content">${commentsSystem.formatCommentContent(comment.content)}</div>
            </div>
        `;
    }).join('');
}

// إعداد مستمعي الأحداث
document.addEventListener('DOMContentLoaded', () => {
    // تحديث التعليقات عند تحميل الصفحة
    updateCommentsDisplay();
    
    // إضافة مستمع لمفتاح Enter في حقل التعليق
    const commentTextarea = document.getElementById('comment-text');
    if (commentTextarea) {
        commentTextarea.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && e.ctrlKey) {
                addComment();
            }
        });
        
        // إضافة عداد الأحرف
        commentTextarea.addEventListener('input', (e) => {
            const maxLength = 500;
            const currentLength = e.target.value.length;
            const remaining = maxLength - currentLength;
            
            let counter = document.getElementById('comment-counter');
            if (!counter) {
                counter = document.createElement('div');
                counter.id = 'comment-counter';
                counter.className = 'comment-counter';
                e.target.parentNode.appendChild(counter);
            }
            
            counter.textContent = `${remaining} ${getCurrentLanguage() === 'ar' ? 'حرف متبقي' : 'characters remaining'}`;
            counter.style.color = remaining < 50 ? '#f44336' : '#666';
        });
    }
    
    // تحديث التعليقات كل 30 ثانية
    setInterval(() => {
        commentsSystem.loadComments();
        updateCommentsDisplay();
    }, 30000);
});

