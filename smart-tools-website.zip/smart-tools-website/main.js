// الملف الرئيسي للموقع
class SmartToolsWebsite {
    constructor() {
        this.currentTool = null;
        this.isInitialized = false;
        this.init();
    }

    // تهيئة الموقع
    async init() {
        try {
            // تحميل البيانات الأساسية
            await this.loadInitialData();
            
            // إعداد واجهة المستخدم
            this.setupUI();
            
            // إعداد مستمعي الأحداث
            this.setupEventListeners();
            
            // تحديث المحتوى
            this.updateContent();
            
            this.isInitialized = true;
            console.log('Smart Tools Website initialized successfully');
            
        } catch (error) {
            console.error('Failed to initialize website:', error);
            this.showError('Failed to load website. Please refresh the page.');
        }
    }

    // تحميل البيانات الأولية
    async loadInitialData() {
        // تنظيف البيانات المنتهية الصلاحية
        db.cleanExpiredData();
        
        // تحديث المنشورات اليومية
        this.updateDailyPosts();
        
        // تحميل الإعدادات
        this.loadSettings();
    }

    // إعداد واجهة المستخدم
    setupUI() {
        // تحديث اللغة
        languageSystem.updatePageLanguage();
        
        // تحديث واجهة المستخدم
        updateUserInterface();
        
        // تحديث المنشورات
        this.updatePostsDisplay();
        
        // إضافة تأثيرات التحميل
        this.addLoadingEffects();
    }

    // إعداد مستمعي الأحداث
    setupEventListeners() {
        // مستمع تغيير حجم النافذة
        window.addEventListener('resize', this.handleResize.bind(this));
        
        // مستمع التمرير
        window.addEventListener('scroll', this.handleScroll.bind(this));
        
        // مستمع اختصارات لوحة المفاتيح
        document.addEventListener('keydown', this.handleKeyboard.bind(this));
        
        // مستمع تغيير الاتصال
        window.addEventListener('online', this.handleOnline.bind(this));
        window.addEventListener('offline', this.handleOffline.bind(this));
    }

    // تحديث المحتوى
    updateContent() {
        // تحديث لوحة المتصدرين
        updateLeaderboard();
        
        // تحديث التعليقات
        updateCommentsDisplay();
        
        // تحديث الأدوات
        updateToolsDisplay();
    }

    // تحديث المنشورات اليومية
    updateDailyPosts() {
        const today = new Date().toISOString().split('T')[0];
        const posts = db.getData('posts');
        
        // التحقق من وجود منشورات لليوم
        const todayPosts = posts.filter(post => post.display_date === today && post.is_active);
        
        if (todayPosts.length < 3) {
            // إنشاء منشورات جديدة لليوم
            this.generateDailyPosts();
        }
    }

    // إنشاء منشورات يومية جديدة
    generateDailyPosts() {
        const today = new Date().toISOString().split('T')[0];
        const currentLang = getCurrentLanguage();
        
        const newPosts = [
            {
                title_ar: 'نصائح يومية لزيادة الإنتاجية',
                title_en: 'Daily Tips to Boost Productivity',
                content_ar: 'اكتشف أفضل الطرق لتحسين إنتاجيتك اليومية باستخدام أدواتنا الذكية',
                content_en: 'Discover the best ways to improve your daily productivity using our smart tools',
                image_url: '',
                is_active: true,
                display_date: today
            },
            {
                title_ar: 'تحديثات جديدة في الموقع',
                title_en: 'New Website Updates',
                content_ar: 'تعرف على آخر التحديثات والميزات الجديدة المضافة للموقع',
                content_en: 'Learn about the latest updates and new features added to the website',
                image_url: '',
                is_active: true,
                display_date: today
            },
            {
                title_ar: 'مسابقة النقاط الأسبوعية',
                title_en: 'Weekly Points Competition',
                content_ar: 'شارك في مسابقة النقاط واربح جوائز قيمة',
                content_en: 'Participate in the points competition and win valuable prizes',
                image_url: '',
                is_active: true,
                display_date: today
            }
        ];

        newPosts.forEach(post => {
            db.addItem('posts', post);
        });
    }

    // تحديث عرض المنشورات
    updatePostsDisplay() {
        const postsContainer = document.getElementById('posts-grid');
        if (!postsContainer) return;

        const today = new Date().toISOString().split('T')[0];
        const posts = db.getData('posts');
        const todayPosts = posts.filter(post => post.display_date === today && post.is_active);
        const currentLang = getCurrentLanguage();

        if (todayPosts.length === 0) {
            postsContainer.innerHTML = `
                <div class="no-posts">
                    <i class="fas fa-newspaper"></i>
                    <h4>${currentLang === 'ar' ? 'لا توجد منشورات اليوم' : 'No posts today'}</h4>
                </div>
            `;
            return;
        }

        postsContainer.innerHTML = todayPosts.map(post => `
            <div class="post-card">
                <div class="post-image">
                    ${post.image_url ? 
                        `<img src="${post.image_url}" alt="${currentLang === 'ar' ? post.title_ar : post.title_en}">` : 
                        `<i class="fas fa-newspaper"></i>`
                    }
                </div>
                <div class="post-content">
                    <h3 class="post-title">${currentLang === 'ar' ? post.title_ar : post.title_en}</h3>
                    <p class="post-text">${currentLang === 'ar' ? post.content_ar : post.content_en}</p>
                </div>
            </div>
        `).join('');
    }

    // تحميل الإعدادات
    loadSettings() {
        const settings = db.getData('site_settings');
        
        settings.forEach(setting => {
            switch (setting.key) {
                case 'site_title_ar':
                case 'site_title_en':
                    // تحديث عنوان الموقع
                    break;
                case 'daily_points_limit':
                    this.dailyPointsLimit = parseInt(setting.value);
                    break;
                case 'leaderboard_size':
                    this.leaderboardSize = parseInt(setting.value);
                    break;
            }
        });
    }

    // فتح أداة
    openTool(toolId) {
        const tool = db.findItem('tools', { id: toolId });
        if (!tool) {
            showNotification(getCurrentLanguage() === 'ar' ? 'الأداة غير موجودة' : 'Tool not found', 'error');
            return;
        }

        const currentUser = auth.getCurrentUser();
        
        // التحقق من تسجيل الدخول
        if (!currentUser) {
            showLoginModal();
            return;
        }

        // التحقق من النقاط المطلوبة
        if (tool.required_points > 0 && currentUser.points < tool.required_points) {
            showNotification(
                getCurrentLanguage() === 'ar' ? 
                `تحتاج إلى ${tool.required_points} نقطة لاستخدام هذه الأداة` : 
                `You need ${tool.required_points} points to use this tool`,
                'warning'
            );
            return;
        }

        // عرض الأداة
        this.showToolModal(tool);
    }

    // عرض نافذة الأداة
    showToolModal(tool) {
        const modal = document.getElementById('tool-modal');
        const content = document.getElementById('tool-content');
        
        if (!modal || !content) return;

        let toolContent = '';
        
        switch (tool.name) {
            case 'smart_titles':
                toolContent = smartTitles.showTool();
                break;
            case 'tasks':
                toolContent = taskManager.showTool();
                break;
            case 'smart_emoji':
                toolContent = smartEmoji.showTool();
                break;
            case 'advanced_titles':
                toolContent = advancedTitles.showTool();
                break;
            case 'profile_image':
                toolContent = profileImage.showTool();
                break;
            default:
                toolContent = `<p>${getCurrentLanguage() === 'ar' ? 'الأداة قيد التطوير' : 'Tool under development'}</p>`;
        }

        content.innerHTML = toolContent;
        modal.style.display = 'block';
        this.currentTool = tool;
        
        // تحديث محتوى الأداة إذا لزم الأمر
        if (tool.name === 'profile_image') {
            setTimeout(() => loadFeaturedImages(), 100);
        }
    }

    // إغلاق نافذة الأداة
    closeToolModal() {
        const modal = document.getElementById('tool-modal');
        if (modal) {
            modal.style.display = 'none';
        }
        this.currentTool = null;
    }

    // إضافة تأثيرات التحميل
    addLoadingEffects() {
        // إضافة تأثير fade-in للعناصر
        const elements = document.querySelectorAll('.tool-card, .post-card, .leaderboard-item');
        elements.forEach((element, index) => {
            element.style.opacity = '0';
            element.style.transform = 'translateY(20px)';
            
            setTimeout(() => {
                element.style.transition = 'all 0.5s ease';
                element.style.opacity = '1';
                element.style.transform = 'translateY(0)';
            }, index * 100);
        });
    }

    // معالج تغيير حجم النافذة
    handleResize() {
        // تحديث تخطيط الموقع حسب حجم الشاشة
        this.updateLayout();
    }

    // معالج التمرير
    handleScroll() {
        const navbar = document.querySelector('.navbar');
        if (navbar) {
            if (window.scrollY > 100) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        }
    }

    // معالج اختصارات لوحة المفاتيح
    handleKeyboard(event) {
        // ESC لإغلاق النوافذ المنبثقة
        if (event.key === 'Escape') {
            this.closeAllModals();
        }
        
        // Ctrl+L لتبديل اللغة
        if (event.ctrlKey && event.key === 'l') {
            event.preventDefault();
            toggleLanguage();
        }
    }

    // معالج الاتصال بالإنترنت
    handleOnline() {
        showNotification(
            getCurrentLanguage() === 'ar' ? 'تم استعادة الاتصال بالإنترنت' : 'Internet connection restored',
            'success'
        );
    }

    // معالج انقطاع الاتصال
    handleOffline() {
        showNotification(
            getCurrentLanguage() === 'ar' ? 'انقطع الاتصال بالإنترنت' : 'Internet connection lost',
            'warning'
        );
    }

    // تحديث التخطيط
    updateLayout() {
        const isMobile = window.innerWidth <= 768;
        document.body.classList.toggle('mobile', isMobile);
    }

    // إغلاق جميع النوافذ المنبثقة
    closeAllModals() {
        const modals = document.querySelectorAll('.modal');
        modals.forEach(modal => {
            modal.style.display = 'none';
        });
        this.currentTool = null;
    }

    // عرض خطأ
    showError(message) {
        showNotification(message, 'error');
    }

    // عرض معلومات
    showInfo(message) {
        showNotification(message, 'info');
    }
}

// دالة عرض الإشعارات
function showNotification(message, type = 'info') {
    // إزالة الإشعارات السابقة
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(notification => notification.remove());
    
    // إنشاء إشعار جديد
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <i class="fas ${getNotificationIcon(type)}"></i>
            <span>${message}</span>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    // إزالة الإشعار بعد 5 ثوان
    setTimeout(() => {
        notification.style.opacity = '0';
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => notification.remove(), 300);
    }, 5000);
}

// الحصول على أيقونة الإشعار
function getNotificationIcon(type) {
    const icons = {
        success: 'fa-check-circle',
        error: 'fa-exclamation-circle',
        warning: 'fa-exclamation-triangle',
        info: 'fa-info-circle'
    };
    return icons[type] || icons.info;
}

// دالة عرض نافذة الدعم
function showSupportModal() {
    document.getElementById('support-modal').style.display = 'block';
}

// دالة فتح أداة
function openTool(toolId) {
    website.openTool(toolId);
}

// دالة إغلاق نافذة الأداة
function closeToolModal() {
    website.closeToolModal();
}

// دالة عرض لوحة الإدارة
function showAdminPanel() {
    if (!auth.isAdmin()) {
        showNotification(getCurrentLanguage() === 'ar' ? 'ليس لديك صلاحية إدارية' : 'You do not have admin privileges', 'error');
        return;
    }
    
    // سيتم تطوير لوحة الإدارة في المرحلة التالية
    showNotification(getCurrentLanguage() === 'ar' ? 'لوحة الإدارة قيد التطوير' : 'Admin panel under development', 'info');
}

// إنشاء مثيل من الموقع
const website = new SmartToolsWebsite();

// تصدير الدوال للاستخدام العام
window.showNotification = showNotification;
window.openTool = openTool;
window.closeToolModal = closeToolModal;
window.showSupportModal = showSupportModal;
window.showAdminPanel = showAdminPanel;

