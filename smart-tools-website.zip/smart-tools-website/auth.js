// نظام المصادقة والمستخدمين
class AuthSystem {
    constructor() {
        this.currentUser = null;
        this.loadCurrentUser();
    }

    // تحميل المستخدم الحالي
    loadCurrentUser() {
        this.currentUser = db.getCurrentUser();
    }

    // تسجيل دخول/إنشاء حساب جديد
    async login(username, email) {
        if (!username || !email) {
            throw new Error(getCurrentLanguage() === 'ar' ? 'يرجى ملء جميع الحقول' : 'Please fill all fields');
        }

        // التحقق من صحة البريد الإلكتروني
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            throw new Error(getCurrentLanguage() === 'ar' ? 'البريد الإلكتروني غير صحيح' : 'Invalid email address');
        }

        // البحث عن المستخدم الموجود
        let user = db.findItem('users', { email: email });
        
        if (user) {
            // تحديث اسم المستخدم إذا تغير
            if (user.username !== username) {
                user = db.updateItem('users', user.id, { username: username });
            }
        } else {
            // إنشاء مستخدم جديد
            user = db.addItem('users', {
                username: username,
                email: email,
                points: 0,
                daily_tool_usage: {},
                profile_image: null,
                profile_image_expires: null,
                is_admin: email === 'admin@smarttools.com', // المدير الافتراضي
                language: getCurrentLanguage()
            });
        }

        // تسجيل دخول المستخدم
        db.setCurrentUser(user);
        this.currentUser = user;
        
        return user;
    }

    // تسجيل الخروج
    logout() {
        db.logout();
        this.currentUser = null;
        
        // إعادة تحميل الصفحة لتحديث الواجهة
        location.reload();
    }

    // التحقق من كون المستخدم مديراً
    isAdmin() {
        return this.currentUser && this.currentUser.is_admin;
    }

    // الحصول على المستخدم الحالي
    getCurrentUser() {
        return this.currentUser;
    }

    // تحديث نقاط المستخدم
    updateUserPoints(points) {
        if (!this.currentUser) return false;
        
        const updatedUser = db.updateItem('users', this.currentUser.id, { points: points });
        if (updatedUser) {
            this.currentUser = updatedUser;
            db.setCurrentUser(updatedUser);
            return true;
        }
        return false;
    }

    // التحقق من استخدام الأداة اليوم
    hasUsedToolToday(toolName) {
        if (!this.currentUser) return false;
        return db.hasUsedToolToday(this.currentUser.id, toolName);
    }

    // تسجيل استخدام الأداة
    markToolUsed(toolName) {
        if (!this.currentUser) return false;
        return db.markToolUsed(this.currentUser.id, toolName);
    }

    // إضافة نقاط
    addPoints(toolName, points) {
        if (!this.currentUser) return false;
        
        const success = db.addPoints(this.currentUser.id, toolName, points);
        if (success) {
            // تحديث المستخدم الحالي
            const updatedUser = db.findItem('users', { id: this.currentUser.id });
            this.currentUser = updatedUser;
            db.setCurrentUser(updatedUser);
        }
        return success;
    }

    // الحصول على إحصائيات المستخدم
    getUserStats() {
        if (!this.currentUser) return null;

        const pointsHistory = db.findItems('points_history', { user_id: this.currentUser.id });
        const userTasks = db.findItems('user_tasks', { user_id: this.currentUser.id });
        const completedTasks = userTasks.filter(task => task.is_completed);

        return {
            totalPoints: this.currentUser.points,
            pointsToday: this.getPointsToday(),
            totalTasks: userTasks.length,
            completedTasks: completedTasks.length,
            joinDate: new Date(this.currentUser.created_at).toLocaleDateString(),
            toolsUsedToday: this.getToolsUsedToday()
        };
    }

    // الحصول على النقاط المكتسبة اليوم
    getPointsToday() {
        if (!this.currentUser) return 0;

        const today = new Date().toISOString().split('T')[0];
        const pointsHistory = db.findItems('points_history', { 
            user_id: this.currentUser.id,
            date: today
        });

        return pointsHistory.reduce((total, entry) => total + entry.points_earned, 0);
    }

    // الحصول على الأدوات المستخدمة اليوم
    getToolsUsedToday() {
        if (!this.currentUser || !this.currentUser.daily_tool_usage) return [];

        const today = new Date().toISOString().split('T')[0];
        const usedTools = [];

        Object.keys(this.currentUser.daily_tool_usage).forEach(toolName => {
            const usage = this.currentUser.daily_tool_usage[toolName];
            if (usage.used && usage.date === today) {
                usedTools.push(toolName);
            }
        });

        return usedTools;
    }
}

// إنشاء مثيل من نظام المصادقة
const auth = new AuthSystem();

// دالة عرض نافذة تسجيل الدخول
function showLoginModal() {
    document.getElementById('login-modal').style.display = 'block';
}

// دالة إغلاق النوافذ المنبثقة
function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

// دالة معالجة تسجيل الدخول
async function handleLogin(event) {
    event.preventDefault();
    
    const username = document.getElementById('username').value.trim();
    const email = document.getElementById('email').value.trim();
    
    try {
        const user = await auth.login(username, email);
        
        closeModal('login-modal');
        updateUserInterface();
        
        showNotification(
            getCurrentLanguage() === 'ar' ? 
            `مرحباً ${user.username}! تم تسجيل الدخول بنجاح` : 
            `Welcome ${user.username}! Login successful`,
            'success'
        );
        
    } catch (error) {
        showNotification(error.message, 'error');
    }
}

// دالة تسجيل الخروج
function handleLogout() {
    const currentLang = getCurrentLanguage();
    const confirmMessage = currentLang === 'ar' ? 
        'هل أنت متأكد من تسجيل الخروج؟' : 
        'Are you sure you want to logout?';
    
    if (confirm(confirmMessage)) {
        auth.logout();
    }
}

// دالة تحديث واجهة المستخدم
function updateUserInterface() {
    const currentUser = auth.getCurrentUser();
    const userInfo = document.getElementById('user-info');
    const currentLang = getCurrentLanguage();
    
    if (currentUser) {
        userInfo.innerHTML = `
            <div class="user-profile">
                ${currentUser.profile_image ? 
                    `<img src="${currentUser.profile_image}" alt="Profile" class="user-avatar">` : 
                    `<div class="user-avatar-placeholder"><i class="fas fa-user"></i></div>`
                }
                <div class="user-details">
                    <span class="username">${currentUser.username}</span>
                    <span class="user-points" id="user-points">${currentUser.points} ${currentLang === 'ar' ? 'نقطة' : 'points'}</span>
                </div>
                <div class="user-actions">
                    ${currentUser.is_admin ? 
                        `<button class="admin-btn" onclick="showAdminPanel()">
                            <i class="fas fa-cog"></i>
                            ${currentLang === 'ar' ? 'الإدارة' : 'Admin'}
                        </button>` : ''
                    }
                    <button class="logout-btn" onclick="handleLogout()">
                        <i class="fas fa-sign-out-alt"></i>
                        ${currentLang === 'ar' ? 'خروج' : 'Logout'}
                    </button>
                </div>
            </div>
        `;
    } else {
        userInfo.innerHTML = `
            <span id="user-points">0 ${currentLang === 'ar' ? 'نقطة' : 'points'}</span>
            <button class="login-btn" onclick="showLoginModal()">
                ${currentLang === 'ar' ? 'تسجيل الدخول' : 'Login'}
            </button>
        `;
    }
    
    // تحديث لوحة المتصدرين
    updateLeaderboard();
    
    // تحديث عرض الأدوات
    updateToolsDisplay();
}

// دالة تحديث عرض النقاط
function updateUserPointsDisplay() {
    const currentUser = auth.getCurrentUser();
    const pointsElements = document.querySelectorAll('#user-points, .user-points');
    const currentLang = getCurrentLanguage();
    
    pointsElements.forEach(element => {
        if (currentUser) {
            element.textContent = `${currentUser.points} ${currentLang === 'ar' ? 'نقطة' : 'points'}`;
        } else {
            element.textContent = `0 ${currentLang === 'ar' ? 'نقطة' : 'points'}`;
        }
    });
}

// دالة تحديث لوحة المتصدرين
function updateLeaderboard() {
    const leaderboard = db.getLeaderboard(10);
    const leaderboardContainer = document.getElementById('leaderboard');
    const currentLang = getCurrentLanguage();
    
    if (!leaderboardContainer) return;
    
    if (leaderboard.length === 0) {
        leaderboardContainer.innerHTML = `
            <div class="empty-leaderboard">
                <i class="fas fa-trophy"></i>
                <p>${currentLang === 'ar' ? 'لا يوجد متصدرون بعد' : 'No leaders yet'}</p>
            </div>
        `;
        return;
    }
    
    leaderboardContainer.innerHTML = leaderboard.map(user => `
        <div class="leaderboard-item">
            <div class="leaderboard-rank">${user.rank}</div>
            <div class="leaderboard-name">${user.username}</div>
            <div class="leaderboard-points">${user.points} ${currentLang === 'ar' ? 'نقطة' : 'points'}</div>
        </div>
    `).join('');
}

// دالة تحديث عرض الأدوات
function updateToolsDisplay() {
    const currentUser = auth.getCurrentUser();
    const toolsContainer = document.getElementById('tools-grid');
    const currentLang = getCurrentLanguage();
    
    if (!toolsContainer) return;
    
    const tools = db.getData('tools');
    
    toolsContainer.innerHTML = tools.map(tool => {
        const isLocked = tool.required_points > 0 && (!currentUser || currentUser.points < tool.required_points);
        const hasUsedToday = currentUser && tool.daily_points > 0 && db.hasUsedToolToday(currentUser.id, tool.name);
        
        return `
            <div class="tool-card ${isLocked ? 'locked' : ''} ${hasUsedToday ? 'used-today' : ''}" 
                 onclick="${isLocked ? '' : `openTool('${tool.id}')`}">
                <i class="tool-icon ${getToolIcon(tool.name)}"></i>
                <h4>${currentLang === 'ar' ? tool.name_ar : tool.name_en}</h4>
                <p>${currentLang === 'ar' ? tool.description_ar : tool.description_en}</p>
                
                ${tool.required_points > 0 ? 
                    `<div class="tool-required-points">
                        ${currentLang === 'ar' ? 'يتطلب' : 'Requires'} ${tool.required_points} ${currentLang === 'ar' ? 'نقطة' : 'points'}
                    </div>` : 
                    tool.daily_points > 0 ? 
                        `<div class="tool-points">
                            ${hasUsedToday ? 
                                (currentLang === 'ar' ? 'تم الاستخدام اليوم' : 'Used today') : 
                                `+${tool.daily_points} ${currentLang === 'ar' ? 'نقطة' : 'points'}`
                            }
                        </div>` : ''
                }
                
                ${isLocked ? `<div class="lock-overlay"><i class="fas fa-lock"></i></div>` : ''}
            </div>
        `;
    }).join('');
}

// دالة الحصول على أيقونة الأداة
function getToolIcon(toolName) {
    const icons = {
        'smart_titles': 'fas fa-heading',
        'tasks': 'fas fa-tasks',
        'smart_emoji': 'fas fa-smile',
        'advanced_titles': 'fas fa-crown',
        'profile_image': 'fas fa-image'
    };
    
    return icons[toolName] || 'fas fa-tools';
}

// إعداد مستمعي الأحداث
document.addEventListener('DOMContentLoaded', () => {
    // إعداد نموذج تسجيل الدخول
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
    
    // إغلاق النوافذ المنبثقة عند النقر خارجها
    window.addEventListener('click', (event) => {
        if (event.target.classList.contains('modal')) {
            event.target.style.display = 'none';
        }
    });
    
    // تحديث الواجهة عند تحميل الصفحة
    updateUserInterface();
    
    // تحديث الواجهة كل دقيقة لتنظيف البيانات المنتهية الصلاحية
    setInterval(() => {
        db.cleanExpiredData();
        updateUserInterface();
    }, 60000);
});

