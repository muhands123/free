# مخطط قاعدة البيانات - موقع الأدوات الذكية

## جدول المستخدمين (users)
```sql
{
  id: string (UUID),
  username: string,
  email: string,
  password_hash: string,
  points: number (default: 0),
  daily_tool_usage: {
    smart_titles: { used: boolean, date: string },
    tasks: { used: boolean, date: string },
    smart_emoji: { used: boolean, date: string }
  },
  profile_image: string (URL/path),
  profile_image_expires: date,
  created_at: date,
  updated_at: date,
  is_admin: boolean (default: false),
  language: string (default: 'ar')
}
```

## جدول النقاط (points_history)
```sql
{
  id: string (UUID),
  user_id: string (foreign key),
  tool_name: string,
  points_earned: number,
  date: date,
  created_at: date
}
```

## جدول الأدوات (tools)
```sql
{
  id: string (UUID),
  name: string,
  name_ar: string,
  name_en: string,
  description_ar: string,
  description_en: string,
  type: string (free/premium),
  required_points: number,
  daily_points: number,
  is_active: boolean,
  position: number,
  created_at: date,
  updated_at: date
}
```

## جدول المنشورات (posts)
```sql
{
  id: string (UUID),
  title_ar: string,
  title_en: string,
  content_ar: string,
  content_en: string,
  image_url: string,
  is_active: boolean,
  display_date: date,
  created_at: date,
  updated_at: date
}
```

## جدول التعليقات (comments)
```sql
{
  id: string (UUID),
  user_id: string (foreign key),
  content: string,
  is_approved: boolean (default: false),
  created_at: date,
  updated_at: date
}
```

## جدول الصور المؤقتة (temp_images)
```sql
{
  id: string (UUID),
  user_id: string (foreign key),
  image_url: string,
  expires_at: date,
  is_approved: boolean (default: true),
  created_at: date
}
```

## جدول إعدادات الموقع (site_settings)
```sql
{
  id: string (UUID),
  key: string,
  value: string,
  description: string,
  updated_at: date
}
```

## جدول المهام (user_tasks)
```sql
{
  id: string (UUID),
  user_id: string (foreign key),
  task_text: string,
  is_completed: boolean (default: false),
  created_at: date,
  completed_at: date
}
```

## جدول لوحة المتصدرين (leaderboard)
```sql
{
  user_id: string (foreign key),
  username: string,
  total_points: number,
  rank: number,
  updated_at: date
}
```

## نظام النقاط

### قواعد منح النقاط:
1. كل أداة مجانية تمنح 25 نقطة يومياً
2. المستخدم يمكنه استخدام كل أداة مرة واحدة يومياً فقط
3. النقاط تُحفظ في جدول points_history لتتبع التاريخ
4. إجمالي النقاط يُحدث في جدول users

### مستويات الأدوات:
- الأدوات المجانية: 0 نقطة مطلوبة
- أداة العناوين المتقدمة: 200 نقطة مطلوبة
- أداة عرض الصورة: 500 نقطة مطلوبة

### تحديث لوحة المتصدرين:
- تُحدث يومياً أو عند كل تغيير في النقاط
- تعرض أول 10 مستخدمين

