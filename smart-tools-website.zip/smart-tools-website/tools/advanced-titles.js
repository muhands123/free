// أداة العناوين المتقدمة
class AdvancedTitles {
    constructor() {
        this.advancedTemplates = {
            ar: [
                "استراتيجيات {topic} المتقدمة: دليل الخبراء لعام {year}",
                "تحليل عميق: كيف تؤثر {topic} على {industry} في المستقبل",
                "دراسة حالة: نجاح {company} في {topic} وما يمكن تعلمه",
                "الدليل النهائي لـ {topic}: من المبتدئ إلى الخبير في {timeframe}",
                "اتجاهات {topic} الناشئة: ما يجب أن تعرفه قبل {year}",
                "مقارنة شاملة: أفضل {number} استراتيجيات {topic} للشركات",
                "تحدي {topic}: كيف حققت {result} في {timeframe} فقط",
                "أسرار {topic} التي يستخدمها المحترفون ولا يشاركونها",
                "ثورة {topic}: كيف تغير الصناعة وتؤثر على {audience}",
                "دليل المتقدمين في {topic}: تقنيات وأدوات لا يعرفها الجميع",
                "تحليل البيانات: كيف يؤثر {topic} على {metric} بنسبة {percentage}%",
                "مستقبل {topic}: توقعات الخبراء والاتجاهات الجديدة",
                "استراتيجية {topic} المتكاملة: خطة عملية لتحقيق {goal}",
                "أخطاء {topic} المكلفة وكيفية تجنبها: دروس من الفشل",
                "ابتكارات {topic} الجديدة: كيف تغير قواعد اللعبة"
            ],
            en: [
                "Advanced {topic} Strategies: Expert Guide for {year}",
                "Deep Analysis: How {topic} Impacts {industry} Future",
                "Case Study: {company}'s Success in {topic} and Key Lessons",
                "Ultimate {topic} Guide: Beginner to Expert in {timeframe}",
                "Emerging {topic} Trends: What You Need to Know Before {year}",
                "Comprehensive Comparison: Top {number} {topic} Strategies for Business",
                "{topic} Challenge: How I Achieved {result} in Just {timeframe}",
                "Professional {topic} Secrets They Don't Want You to Know",
                "{topic} Revolution: Industry Changes and Impact on {audience}",
                "Advanced {topic} Guide: Techniques and Tools for Professionals",
                "Data Analysis: How {topic} Affects {metric} by {percentage}%",
                "Future of {topic}: Expert Predictions and New Trends",
                "Integrated {topic} Strategy: Practical Plan to Achieve {goal}",
                "Costly {topic} Mistakes and How to Avoid Them: Lessons from Failure",
                "New {topic} Innovations: How They're Changing the Game"
            ]
        };

        this.industries = {
            ar: [
                "التكنولوجيا", "الصحة", "التعليم", "التجارة الإلكترونية", "الخدمات المالية",
                "العقارات", "السياحة", "الإعلام", "الطاقة", "النقل", "الزراعة", "الصناعة",
                "الترفيه", "الأمن السيبراني", "الذكاء الاصطناعي", "البيئة", "الرياضة"
            ],
            en: [
                "Technology", "Healthcare", "Education", "E-commerce", "Financial Services",
                "Real Estate", "Tourism", "Media", "Energy", "Transportation", "Agriculture", "Manufacturing",
                "Entertainment", "Cybersecurity", "Artificial Intelligence", "Environment", "Sports"
            ]
        };

        this.companies = {
            ar: [
                "أمازون", "جوجل", "أبل", "مايكروسوفت", "تسلا", "نتفليكس", "أوبر", "إيرباص",
                "سامسونج", "فيسبوك", "تويتر", "لينكد إن", "سبوتيفاي", "زووم", "شوبيفاي"
            ],
            en: [
                "Amazon", "Google", "Apple", "Microsoft", "Tesla", "Netflix", "Uber", "Airbnb",
                "Samsung", "Facebook", "Twitter", "LinkedIn", "Spotify", "Zoom", "Shopify"
            ]
        };

        this.audiences = {
            ar: [
                "رواد الأعمال", "المطورين", "المسوقين", "المديرين", "الطلاب", "المستثمرين",
                "المبدعين", "المحللين", "الاستشاريين", "القادة", "المبتكرين", "الخبراء"
            ],
            en: [
                "Entrepreneurs", "Developers", "Marketers", "Managers", "Students", "Investors",
                "Creators", "Analysts", "Consultants", "Leaders", "Innovators", "Experts"
            ]
        };

        this.results = {
            ar: [
                "زيادة الأرباح بنسبة 300%", "نمو المبيعات بـ 500%", "توفير 50% من التكاليف",
                "زيادة الإنتاجية بـ 200%", "تحسين الكفاءة بـ 150%", "نمو العملاء بـ 400%",
                "زيادة التفاعل بـ 250%", "تحسين الجودة بـ 180%", "تقليل الوقت بـ 60%"
            ],
            en: [
                "300% Profit Increase", "500% Sales Growth", "50% Cost Reduction",
                "200% Productivity Boost", "150% Efficiency Improvement", "400% Customer Growth",
                "250% Engagement Increase", "180% Quality Enhancement", "60% Time Reduction"
            ]
        };

        this.goals = {
            ar: [
                "النجاح المستدام", "النمو السريع", "التميز التنافسي", "الابتكار المستمر",
                "القيادة في السوق", "الربحية العالية", "رضا العملاء", "التوسع العالمي"
            ],
            en: [
                "Sustainable Success", "Rapid Growth", "Competitive Excellence", "Continuous Innovation",
                "Market Leadership", "High Profitability", "Customer Satisfaction", "Global Expansion"
            ]
        };

        this.metrics = {
            ar: [
                "معدل التحويل", "عائد الاستثمار", "رضا العملاء", "الإنتاجية", "الجودة",
                "السرعة", "الكفاءة", "النمو", "الأرباح", "المبيعات", "التفاعل"
            ],
            en: [
                "Conversion Rate", "ROI", "Customer Satisfaction", "Productivity", "Quality",
                "Speed", "Efficiency", "Growth", "Profits", "Sales", "Engagement"
            ]
        };

        this.timeframes = {
            ar: ["30 يوماً", "3 أشهر", "6 أشهر", "سنة واحدة", "90 يوماً", "شهرين"],
            en: ["30 Days", "3 Months", "6 Months", "One Year", "90 Days", "Two Months"]
        };

        this.percentages = ["25", "50", "75", "100", "150", "200", "300", "500"];
        this.numbers = ["3", "5", "7", "10", "12", "15", "20"];
        this.currentYear = new Date().getFullYear();
    }

    generateAdvancedTitle(language = 'ar', customTopic = '', customIndustry = '') {
        const templates = this.advancedTemplates[language];
        const industries = this.industries[language];
        const companies = this.companies[language];
        const audiences = this.audiences[language];
        const results = this.results[language];
        const goals = this.goals[language];
        const metrics = this.metrics[language];
        const timeframes = this.timeframes[language];

        // اختيار قالب عشوائي
        const template = templates[Math.floor(Math.random() * templates.length)];
        
        // اختيار المتغيرات
        const topic = customTopic || this.getRandomTopic(language);
        const industry = customIndustry || industries[Math.floor(Math.random() * industries.length)];
        const company = companies[Math.floor(Math.random() * companies.length)];
        const audience = audiences[Math.floor(Math.random() * audiences.length)];
        const result = results[Math.floor(Math.random() * results.length)];
        const goal = goals[Math.floor(Math.random() * goals.length)];
        const metric = metrics[Math.floor(Math.random() * metrics.length)];
        const timeframe = timeframes[Math.floor(Math.random() * timeframes.length)];
        const percentage = this.percentages[Math.floor(Math.random() * this.percentages.length)];
        const number = this.numbers[Math.floor(Math.random() * this.numbers.length)];

        // استبدال المتغيرات في القالب
        let title = template
            .replace('{topic}', topic)
            .replace('{industry}', industry)
            .replace('{company}', company)
            .replace('{audience}', audience)
            .replace('{result}', result)
            .replace('{goal}', goal)
            .replace('{metric}', metric)
            .replace('{timeframe}', timeframe)
            .replace('{percentage}', percentage)
            .replace('{number}', number)
            .replace('{year}', this.currentYear);

        return title;
    }

    getRandomTopic(language) {
        const topics = {
            ar: [
                "التسويق الرقمي", "إدارة المشاريع", "تطوير المنتجات", "خدمة العملاء", "الابتكار",
                "القيادة", "المبيعات", "التحليل", "الاستراتيجية", "التطوير", "الجودة", "الأمان"
            ],
            en: [
                "Digital Marketing", "Project Management", "Product Development", "Customer Service", "Innovation",
                "Leadership", "Sales", "Analytics", "Strategy", "Development", "Quality", "Security"
            ]
        };
        
        const topicList = topics[language];
        return topicList[Math.floor(Math.random() * topicList.length)];
    }

    generateMultipleAdvancedTitles(count = 5, language = 'ar', customTopic = '', customIndustry = '') {
        const titles = [];
        for (let i = 0; i < count; i++) {
            titles.push(this.generateAdvancedTitle(language, customTopic, customIndustry));
        }
        return titles;
    }

    analyzeTitle(title, language = 'ar') {
        const analysis = {
            length: title.length,
            wordCount: title.split(' ').length,
            hasNumbers: /\d/.test(title),
            hasYear: /\d{4}/.test(title),
            hasPercentage: /%/.test(title),
            emotionalWords: 0,
            powerWords: 0,
            score: 0
        };

        const emotionalWords = {
            ar: ['نجاح', 'سر', 'مذهل', 'رائع', 'فريد', 'حصري', 'مجاني', 'سريع', 'سهل', 'مضمون'],
            en: ['success', 'secret', 'amazing', 'awesome', 'unique', 'exclusive', 'free', 'fast', 'easy', 'guaranteed']
        };

        const powerWords = {
            ar: ['استراتيجية', 'دليل', 'خبير', 'متقدم', 'شامل', 'نهائي', 'احترافي', 'مبتكر'],
            en: ['strategy', 'guide', 'expert', 'advanced', 'comprehensive', 'ultimate', 'professional', 'innovative']
        };

        // حساب الكلمات العاطفية
        emotionalWords[language].forEach(word => {
            if (title.toLowerCase().includes(word.toLowerCase())) {
                analysis.emotionalWords++;
            }
        });

        // حساب كلمات القوة
        powerWords[language].forEach(word => {
            if (title.toLowerCase().includes(word.toLowerCase())) {
                analysis.powerWords++;
            }
        });

        // حساب النقاط
        analysis.score = 
            (analysis.wordCount >= 8 && analysis.wordCount <= 12 ? 20 : 0) +
            (analysis.hasNumbers ? 15 : 0) +
            (analysis.hasYear ? 10 : 0) +
            (analysis.hasPercentage ? 15 : 0) +
            (analysis.emotionalWords * 10) +
            (analysis.powerWords * 15);

        return analysis;
    }

    showTool() {
        const currentLang = getCurrentLanguage();
        
        const content = `
            <div class="tool-header">
                <h3>${currentLang === 'ar' ? 'أداة العناوين المتقدمة' : 'Advanced Title Generator'}</h3>
                <p>${currentLang === 'ar' ? 'أنشئ عناوين احترافية ومتقدمة مع تحليل شامل' : 'Create professional and advanced titles with comprehensive analysis'}</p>
                <div class="premium-badge">
                    <i class="fas fa-crown"></i>
                    ${currentLang === 'ar' ? 'أداة متقدمة - 200 نقطة' : 'Premium Tool - 200 Points'}
                </div>
            </div>
            
            <div class="tool-form">
                <div class="form-row">
                    <div class="form-group">
                        <label for="advanced-topic">${currentLang === 'ar' ? 'الموضوع (اختياري):' : 'Topic (Optional):'}</label>
                        <input type="text" id="advanced-topic" placeholder="${currentLang === 'ar' ? 'اكتب موضوعك هنا...' : 'Enter your topic here...'}">
                    </div>
                    <div class="form-group">
                        <label for="advanced-industry">${currentLang === 'ar' ? 'الصناعة (اختياري):' : 'Industry (Optional):'}</label>
                        <input type="text" id="advanced-industry" placeholder="${currentLang === 'ar' ? 'مثل: التكنولوجيا، الصحة...' : 'e.g: Technology, Healthcare...'}">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="advanced-count">${currentLang === 'ar' ? 'عدد العناوين:' : 'Number of Titles:'}</label>
                        <select id="advanced-count">
                            <option value="3">3</option>
                            <option value="5" selected>5</option>
                            <option value="8">8</option>
                            <option value="10">10</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>
                            <input type="checkbox" id="include-analysis" checked>
                            ${currentLang === 'ar' ? 'تضمين تحليل العناوين' : 'Include Title Analysis'}
                        </label>
                    </div>
                </div>
                
                <button onclick="generateAdvancedTitles()" class="generate-btn premium">
                    <i class="fas fa-magic"></i>
                    ${currentLang === 'ar' ? 'إنشاء العناوين المتقدمة' : 'Generate Advanced Titles'}
                </button>
            </div>
            
            <div class="tool-results" id="advanced-titles-results">
                <!-- سيتم عرض النتائج هنا -->
            </div>
            
            <style>
                .tool-header {
                    text-align: center;
                    margin-bottom: 2rem;
                }
                
                .tool-header h3 {
                    color: #667eea;
                    font-size: 1.8rem;
                    margin-bottom: 0.5rem;
                }
                
                .tool-header p {
                    color: #666;
                    font-size: 1.1rem;
                    margin-bottom: 1rem;
                }
                
                .premium-badge {
                    background: linear-gradient(45deg, #ffd700, #ffed4e);
                    color: #333;
                    padding: 0.5rem 1rem;
                    border-radius: 25px;
                    display: inline-flex;
                    align-items: center;
                    gap: 0.5rem;
                    font-weight: 600;
                    box-shadow: 0 4px 15px rgba(255, 215, 0, 0.3);
                }
                
                .tool-form {
                    background: linear-gradient(135deg, #f8f9fa, #e9ecef);
                    padding: 2rem;
                    border-radius: 15px;
                    margin-bottom: 2rem;
                    border: 2px solid #ffd700;
                }
                
                .form-row {
                    display: grid;
                    grid-template-columns: 1fr 1fr;
                    gap: 1rem;
                    margin-bottom: 1.5rem;
                }
                
                .form-group {
                    display: flex;
                    flex-direction: column;
                }
                
                .form-group label {
                    margin-bottom: 0.5rem;
                    font-weight: 600;
                    color: #333;
                }
                
                .form-group input,
                .form-group select {
                    padding: 1rem;
                    border: 2px solid #e2e8f0;
                    border-radius: 10px;
                    font-size: 1rem;
                }
                
                .form-group input:focus,
                .form-group select:focus {
                    outline: none;
                    border-color: #ffd700;
                    box-shadow: 0 0 0 3px rgba(255, 215, 0, 0.1);
                }
                
                .form-group label input[type="checkbox"] {
                    width: auto;
                    margin-right: 0.5rem;
                }
                
                .generate-btn.premium {
                    background: linear-gradient(45deg, #ffd700, #ffed4e);
                    color: #333;
                    border: none;
                    padding: 1rem 2rem;
                    border-radius: 25px;
                    cursor: pointer;
                    font-weight: 600;
                    font-size: 1.1rem;
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                    margin: 0 auto;
                    transition: all 0.3s ease;
                    box-shadow: 0 4px 15px rgba(255, 215, 0, 0.3);
                }
                
                .generate-btn.premium:hover {
                    transform: translateY(-3px);
                    box-shadow: 0 8px 25px rgba(255, 215, 0, 0.4);
                }
                
                .advanced-title-item {
                    background: white;
                    border: 2px solid #ffd700;
                    border-radius: 15px;
                    padding: 2rem;
                    margin-bottom: 2rem;
                    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
                }
                
                .title-text {
                    font-size: 1.3rem;
                    font-weight: 600;
                    color: #333;
                    line-height: 1.6;
                    margin-bottom: 1rem;
                    padding: 1rem;
                    background: #f8f9fa;
                    border-radius: 10px;
                    border-left: 4px solid #ffd700;
                }
                
                .title-analysis {
                    background: linear-gradient(135deg, #667eea, #764ba2);
                    color: white;
                    padding: 1.5rem;
                    border-radius: 10px;
                    margin-top: 1rem;
                }
                
                .analysis-header {
                    font-size: 1.1rem;
                    font-weight: 600;
                    margin-bottom: 1rem;
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                }
                
                .analysis-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
                    gap: 1rem;
                    margin-bottom: 1rem;
                }
                
                .analysis-item {
                    background: rgba(255, 255, 255, 0.1);
                    padding: 0.75rem;
                    border-radius: 8px;
                    text-align: center;
                }
                
                .analysis-value {
                    font-size: 1.5rem;
                    font-weight: 700;
                    margin-bottom: 0.25rem;
                }
                
                .analysis-label {
                    font-size: 0.9rem;
                    opacity: 0.9;
                }
                
                .score-bar {
                    background: rgba(255, 255, 255, 0.2);
                    height: 8px;
                    border-radius: 4px;
                    overflow: hidden;
                    margin-top: 1rem;
                }
                
                .score-fill {
                    background: #ffd700;
                    height: 100%;
                    border-radius: 4px;
                    transition: width 0.5s ease;
                }
                
                .title-actions {
                    display: flex;
                    gap: 1rem;
                    margin-top: 1rem;
                }
                
                .copy-btn {
                    background: #4caf50;
                    color: white;
                    border: none;
                    padding: 0.75rem 1.5rem;
                    border-radius: 20px;
                    cursor: pointer;
                    font-weight: 600;
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                    transition: all 0.3s ease;
                }
                
                .copy-btn:hover {
                    background: #45a049;
                    transform: translateY(-2px);
                }
                
                .edit-btn {
                    background: #2196f3;
                    color: white;
                    border: none;
                    padding: 0.75rem 1.5rem;
                    border-radius: 20px;
                    cursor: pointer;
                    font-weight: 600;
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                    transition: all 0.3s ease;
                }
                
                .edit-btn:hover {
                    background: #1976d2;
                    transform: translateY(-2px);
                }
                
                .loading {
                    text-align: center;
                    padding: 3rem;
                    color: #ffd700;
                }
                
                .loading i {
                    font-size: 3rem;
                    animation: spin 1s linear infinite;
                }
                
                @keyframes spin {
                    from { transform: rotate(0deg); }
                    to { transform: rotate(360deg); }
                }
                
                @media (max-width: 768px) {
                    .form-row {
                        grid-template-columns: 1fr;
                    }
                    
                    .analysis-grid {
                        grid-template-columns: repeat(2, 1fr);
                    }
                    
                    .title-actions {
                        flex-direction: column;
                    }
                }
            </style>
        `;
        
        return content;
    }
}

// إنشاء مثيل من أداة العناوين المتقدمة
const advancedTitles = new AdvancedTitles();

// دالة إنشاء العناوين المتقدمة
function generateAdvancedTitles() {
    const currentUser = db.getCurrentUser();
    if (!currentUser) {
        showNotification(getCurrentLanguage() === 'ar' ? 'يجب تسجيل الدخول أولاً' : 'Please login first', 'error');
        return;
    }

    // التحقق من وجود النقاط الكافية
    if (currentUser.points < 200) {
        showNotification(
            getCurrentLanguage() === 'ar' ? 
            `تحتاج إلى 200 نقطة لاستخدام هذه الأداة. نقاطك الحالية: ${currentUser.points}` : 
            `You need 200 points to use this tool. Your current points: ${currentUser.points}`,
            'warning'
        );
        return;
    }

    const customTopic = document.getElementById('advanced-topic').value.trim();
    const customIndustry = document.getElementById('advanced-industry').value.trim();
    const titleCount = parseInt(document.getElementById('advanced-count').value);
    const includeAnalysis = document.getElementById('include-analysis').checked;
    const currentLang = getCurrentLanguage();
    
    // عرض مؤشر التحميل
    const resultsDiv = document.getElementById('advanced-titles-results');
    resultsDiv.innerHTML = `
        <div class="loading">
            <i class="fas fa-crown"></i>
            <p>${currentLang === 'ar' ? 'جاري إنشاء العناوين المتقدمة...' : 'Generating advanced titles...'}</p>
        </div>
    `;
    
    // محاكاة وقت المعالجة المتقدم
    setTimeout(() => {
        const titles = advancedTitles.generateMultipleAdvancedTitles(titleCount, currentLang, customTopic, customIndustry);
        
        let titlesHTML = '<div class="advanced-titles-list">';
        titles.forEach((title, index) => {
            const analysis = includeAnalysis ? advancedTitles.analyzeTitle(title, currentLang) : null;
            
            titlesHTML += `
                <div class="advanced-title-item">
                    <div class="title-text">${title}</div>
                    
                    ${analysis ? `
                        <div class="title-analysis">
                            <div class="analysis-header">
                                <i class="fas fa-chart-line"></i>
                                ${currentLang === 'ar' ? 'تحليل العنوان' : 'Title Analysis'}
                            </div>
                            
                            <div class="analysis-grid">
                                <div class="analysis-item">
                                    <div class="analysis-value">${analysis.wordCount}</div>
                                    <div class="analysis-label">${currentLang === 'ar' ? 'كلمات' : 'Words'}</div>
                                </div>
                                <div class="analysis-item">
                                    <div class="analysis-value">${analysis.length}</div>
                                    <div class="analysis-label">${currentLang === 'ar' ? 'أحرف' : 'Characters'}</div>
                                </div>
                                <div class="analysis-item">
                                    <div class="analysis-value">${analysis.emotionalWords}</div>
                                    <div class="analysis-label">${currentLang === 'ar' ? 'كلمات عاطفية' : 'Emotional Words'}</div>
                                </div>
                                <div class="analysis-item">
                                    <div class="analysis-value">${analysis.powerWords}</div>
                                    <div class="analysis-label">${currentLang === 'ar' ? 'كلمات قوة' : 'Power Words'}</div>
                                </div>
                            </div>
                            
                            <div style="margin-top: 1rem;">
                                <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                                    <span>${currentLang === 'ar' ? 'نقاط الجودة' : 'Quality Score'}</span>
                                    <span>${analysis.score}/100</span>
                                </div>
                                <div class="score-bar">
                                    <div class="score-fill" style="width: ${Math.min(analysis.score, 100)}%"></div>
                                </div>
                            </div>
                        </div>
                    ` : ''}
                    
                    <div class="title-actions">
                        <button class="copy-btn" onclick="copyTitle('${title.replace(/'/g, "\\'")}')">
                            <i class="fas fa-copy"></i>
                            ${currentLang === 'ar' ? 'نسخ' : 'Copy'}
                        </button>
                        <button class="edit-btn" onclick="editTitle(${index}, '${title.replace(/'/g, "\\'")}')">
                            <i class="fas fa-edit"></i>
                            ${currentLang === 'ar' ? 'تعديل' : 'Edit'}
                        </button>
                    </div>
                </div>
            `;
        });
        titlesHTML += '</div>';
        
        resultsDiv.innerHTML = titlesHTML;
        
        showNotification(
            currentLang === 'ar' ? 'تم إنشاء العناوين المتقدمة بنجاح!' : 'Advanced titles generated successfully!',
            'success'
        );
    }, 2500);
}

// دالة تعديل العنوان
function editTitle(index, title) {
    const currentLang = getCurrentLanguage();
    const newTitle = prompt(
        currentLang === 'ar' ? 'عدّل العنوان:' : 'Edit title:',
        title
    );
    
    if (newTitle && newTitle.trim() !== title) {
        const titleElement = document.querySelectorAll('.title-text')[index];
        if (titleElement) {
            titleElement.textContent = newTitle.trim();
            showNotification(
                currentLang === 'ar' ? 'تم تعديل العنوان' : 'Title edited',
                'success'
            );
        }
    }
}

