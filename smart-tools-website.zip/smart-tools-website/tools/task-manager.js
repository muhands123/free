// أداة مدير المهام
class TaskManager {
    constructor() {
        this.tasks = [];
        this.loadTasks();
    }

    loadTasks() {
        const currentUser = db.getCurrentUser();
        if (currentUser) {
            this.tasks = db.findItems('user_tasks', { user_id: currentUser.id });
        }
    }

    addTask(taskText) {
        const currentUser = db.getCurrentUser();
        if (!currentUser) return false;

        const task = {
            user_id: currentUser.id,
            task_text: taskText,
            is_completed: false,
            created_at: new Date().toISOString()
        };

        const savedTask = db.addItem('user_tasks', task);
        this.tasks.push(savedTask);
        return savedTask;
    }

    toggleTask(taskId) {
        const currentUser = db.getCurrentUser();
        if (!currentUser) return false;

        const task = this.tasks.find(t => t.id === taskId);
        if (!task) return false;

        const newStatus = !task.is_completed;
        const updates = {
            is_completed: newStatus,
            completed_at: newStatus ? new Date().toISOString() : null
        };

        db.updateItem('user_tasks', taskId, updates);
        
        // تحديث المهمة في المصفوفة المحلية
        task.is_completed = newStatus;
        task.completed_at = updates.completed_at;

        // إذا تم إكمال المهمة، التحقق من إمكانية منح النقاط
        if (newStatus && !db.hasUsedToolToday(currentUser.id, 'tasks')) {
            db.markToolUsed(currentUser.id, 'tasks');
            db.addPoints(currentUser.id, 'tasks', 25);
            updateUserPointsDisplay();
            showNotification(
                getCurrentLanguage() === 'ar' ? 'مبروك! حصلت على 25 نقطة لإكمال مهمة' : 'Congratulations! You earned 25 points for completing a task',
                'success'
            );
        }

        return true;
    }

    deleteTask(taskId) {
        const currentUser = db.getCurrentUser();
        if (!currentUser) return false;

        const success = db.deleteItem('user_tasks', taskId);
        if (success) {
            this.tasks = this.tasks.filter(t => t.id !== taskId);
        }
        return success;
    }

    getTasks() {
        return this.tasks.sort((a, b) => {
            // المهام غير المكتملة أولاً
            if (a.is_completed !== b.is_completed) {
                return a.is_completed ? 1 : -1;
            }
            // ثم ترتيب حسب تاريخ الإنشاء (الأحدث أولاً)
            return new Date(b.created_at) - new Date(a.created_at);
        });
    }

    getTaskStats() {
        const total = this.tasks.length;
        const completed = this.tasks.filter(t => t.is_completed).length;
        const pending = total - completed;
        const completionRate = total > 0 ? Math.round((completed / total) * 100) : 0;

        return { total, completed, pending, completionRate };
    }

    showTool() {
        const currentLang = getCurrentLanguage();
        const stats = this.getTaskStats();
        
        const content = `
            <div class="tool-header">
                <h3>${currentLang === 'ar' ? 'مدير المهام' : 'Task Manager'}</h3>
                <p>${currentLang === 'ar' ? 'نظم مهامك اليومية واحصل على النقاط عند إكمالها' : 'Organize your daily tasks and earn points when you complete them'}</p>
            </div>
            
            <div class="task-stats">
                <div class="stat-item">
                    <div class="stat-number">${stats.total}</div>
                    <div class="stat-label">${currentLang === 'ar' ? 'إجمالي المهام' : 'Total Tasks'}</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number">${stats.completed}</div>
                    <div class="stat-label">${currentLang === 'ar' ? 'مكتملة' : 'Completed'}</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number">${stats.pending}</div>
                    <div class="stat-label">${currentLang === 'ar' ? 'معلقة' : 'Pending'}</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number">${stats.completionRate}%</div>
                    <div class="stat-label">${currentLang === 'ar' ? 'معدل الإنجاز' : 'Completion Rate'}</div>
                </div>
            </div>
            
            <div class="task-form">
                <div class="form-group">
                    <input type="text" id="new-task-input" placeholder="${currentLang === 'ar' ? 'اكتب مهمة جديدة...' : 'Enter a new task...'}" maxlength="200">
                    <button onclick="addNewTask()" class="add-task-btn">
                        <i class="fas fa-plus"></i>
                        ${currentLang === 'ar' ? 'إضافة' : 'Add'}
                    </button>
                </div>
            </div>
            
            <div class="tasks-container" id="tasks-container">
                ${this.renderTasks()}
            </div>
            
            <style>
                .tool-header {
                    text-align: center;
                    margin-bottom: 2rem;
                }
                
                .tool-header h3 {
                    color: #667eea;
                    font-size: 1.8rem;
                    margin-bottom: 0.5rem;
                }
                
                .tool-header p {
                    color: #666;
                    font-size: 1.1rem;
                }
                
                .task-stats {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
                    gap: 1rem;
                    margin-bottom: 2rem;
                }
                
                .stat-item {
                    background: linear-gradient(45deg, #667eea, #764ba2);
                    color: white;
                    padding: 1.5rem;
                    border-radius: 15px;
                    text-align: center;
                }
                
                .stat-number {
                    font-size: 2rem;
                    font-weight: 700;
                    margin-bottom: 0.5rem;
                }
                
                .stat-label {
                    font-size: 0.9rem;
                    opacity: 0.9;
                }
                
                .task-form {
                    background: #f8f9fa;
                    padding: 1.5rem;
                    border-radius: 15px;
                    margin-bottom: 2rem;
                }
                
                .form-group {
                    display: flex;
                    gap: 1rem;
                    align-items: center;
                }
                
                #new-task-input {
                    flex: 1;
                    padding: 1rem;
                    border: 2px solid #e2e8f0;
                    border-radius: 10px;
                    font-size: 1rem;
                }
                
                #new-task-input:focus {
                    outline: none;
                    border-color: #667eea;
                }
                
                .add-task-btn {
                    background: #667eea;
                    color: white;
                    border: none;
                    padding: 1rem 1.5rem;
                    border-radius: 10px;
                    cursor: pointer;
                    font-weight: 600;
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                    transition: all 0.3s ease;
                }
                
                .add-task-btn:hover {
                    background: #5a67d8;
                    transform: translateY(-2px);
                }
                
                .tasks-container {
                    max-height: 400px;
                    overflow-y: auto;
                }
                
                .task-item {
                    background: white;
                    border: 2px solid #e2e8f0;
                    border-radius: 10px;
                    padding: 1rem;
                    margin-bottom: 1rem;
                    display: flex;
                    align-items: center;
                    gap: 1rem;
                    transition: all 0.3s ease;
                }
                
                .task-item:hover {
                    border-color: #667eea;
                    transform: translateX(5px);
                }
                
                .task-item.completed {
                    background: #f0f9ff;
                    border-color: #4caf50;
                    opacity: 0.8;
                }
                
                .task-checkbox {
                    width: 20px;
                    height: 20px;
                    border: 2px solid #667eea;
                    border-radius: 50%;
                    cursor: pointer;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    transition: all 0.3s ease;
                    flex-shrink: 0;
                }
                
                .task-checkbox.checked {
                    background: #4caf50;
                    border-color: #4caf50;
                    color: white;
                }
                
                .task-checkbox:hover {
                    transform: scale(1.1);
                }
                
                .task-text {
                    flex: 1;
                    font-size: 1rem;
                    line-height: 1.5;
                    color: #333;
                }
                
                .task-text.completed {
                    text-decoration: line-through;
                    color: #666;
                }
                
                .task-date {
                    font-size: 0.8rem;
                    color: #999;
                    margin-top: 0.25rem;
                }
                
                .task-actions {
                    display: flex;
                    gap: 0.5rem;
                }
                
                .delete-task-btn {
                    background: #f44336;
                    color: white;
                    border: none;
                    padding: 0.5rem;
                    border-radius: 5px;
                    cursor: pointer;
                    font-size: 0.8rem;
                    transition: all 0.3s ease;
                }
                
                .delete-task-btn:hover {
                    background: #d32f2f;
                    transform: scale(1.05);
                }
                
                .empty-state {
                    text-align: center;
                    padding: 3rem;
                    color: #666;
                }
                
                .empty-state i {
                    font-size: 3rem;
                    color: #ccc;
                    margin-bottom: 1rem;
                }
                
                @media (max-width: 768px) {
                    .form-group {
                        flex-direction: column;
                    }
                    
                    .task-stats {
                        grid-template-columns: repeat(2, 1fr);
                    }
                }
            </style>
        `;
        
        return content;
    }

    renderTasks() {
        const tasks = this.getTasks();
        const currentLang = getCurrentLanguage();
        
        if (tasks.length === 0) {
            return `
                <div class="empty-state">
                    <i class="fas fa-tasks"></i>
                    <h4>${currentLang === 'ar' ? 'لا توجد مهام بعد' : 'No tasks yet'}</h4>
                    <p>${currentLang === 'ar' ? 'أضف مهمتك الأولى لتبدأ' : 'Add your first task to get started'}</p>
                </div>
            `;
        }
        
        return tasks.map(task => {
            const createdDate = new Date(task.created_at).toLocaleDateString(currentLang === 'ar' ? 'ar-SA' : 'en-US');
            const completedDate = task.completed_at ? new Date(task.completed_at).toLocaleDateString(currentLang === 'ar' ? 'ar-SA' : 'en-US') : null;
            
            return `
                <div class="task-item ${task.is_completed ? 'completed' : ''}">
                    <div class="task-checkbox ${task.is_completed ? 'checked' : ''}" onclick="toggleTask('${task.id}')">
                        ${task.is_completed ? '<i class="fas fa-check"></i>' : ''}
                    </div>
                    <div class="task-content">
                        <div class="task-text ${task.is_completed ? 'completed' : ''}">${task.task_text}</div>
                        <div class="task-date">
                            ${currentLang === 'ar' ? 'أُنشئت في:' : 'Created:'} ${createdDate}
                            ${completedDate ? (currentLang === 'ar' ? ` • اكتملت في: ${completedDate}` : ` • Completed: ${completedDate}`) : ''}
                        </div>
                    </div>
                    <div class="task-actions">
                        <button class="delete-task-btn" onclick="deleteTask('${task.id}')" title="${currentLang === 'ar' ? 'حذف المهمة' : 'Delete task'}">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            `;
        }).join('');
    }
}

// إنشاء مثيل من مدير المهام
const taskManager = new TaskManager();

// دالة إضافة مهمة جديدة
function addNewTask() {
    const currentUser = db.getCurrentUser();
    if (!currentUser) {
        showNotification(getCurrentLanguage() === 'ar' ? 'يجب تسجيل الدخول أولاً' : 'Please login first', 'error');
        return;
    }

    const taskInput = document.getElementById('new-task-input');
    const taskText = taskInput.value.trim();
    
    if (!taskText) {
        showNotification(getCurrentLanguage() === 'ar' ? 'يرجى كتابة نص المهمة' : 'Please enter task text', 'warning');
        return;
    }
    
    if (taskText.length > 200) {
        showNotification(getCurrentLanguage() === 'ar' ? 'نص المهمة طويل جداً' : 'Task text is too long', 'warning');
        return;
    }

    const task = taskManager.addTask(taskText);
    if (task) {
        taskInput.value = '';
        refreshTasksDisplay();
        showNotification(getCurrentLanguage() === 'ar' ? 'تم إضافة المهمة بنجاح' : 'Task added successfully', 'success');
    }
}

// دالة تبديل حالة المهمة
function toggleTask(taskId) {
    const success = taskManager.toggleTask(taskId);
    if (success) {
        refreshTasksDisplay();
    }
}

// دالة حذف المهمة
function deleteTask(taskId) {
    const currentLang = getCurrentLanguage();
    const confirmMessage = currentLang === 'ar' ? 'هل أنت متأكد من حذف هذه المهمة؟' : 'Are you sure you want to delete this task?';
    
    if (confirm(confirmMessage)) {
        const success = taskManager.deleteTask(taskId);
        if (success) {
            refreshTasksDisplay();
            showNotification(currentLang === 'ar' ? 'تم حذف المهمة' : 'Task deleted', 'success');
        }
    }
}

// دالة تحديث عرض المهام
function refreshTasksDisplay() {
    const container = document.getElementById('tasks-container');
    if (container) {
        container.innerHTML = taskManager.renderTasks();
    }
    
    // تحديث الإحصائيات
    const stats = taskManager.getTaskStats();
    const statNumbers = document.querySelectorAll('.stat-number');
    if (statNumbers.length >= 4) {
        statNumbers[0].textContent = stats.total;
        statNumbers[1].textContent = stats.completed;
        statNumbers[2].textContent = stats.pending;
        statNumbers[3].textContent = stats.completionRate + '%';
    }
}

// إضافة مستمع لمفتاح Enter في حقل المهمة الجديدة
document.addEventListener('DOMContentLoaded', () => {
    document.addEventListener('keypress', (e) => {
        if (e.target.id === 'new-task-input' && e.key === 'Enter') {
            addNewTask();
        }
    });
});

