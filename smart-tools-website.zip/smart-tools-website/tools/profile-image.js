// أداة عرض الصورة الشخصية
class ProfileImage {
    constructor() {
        this.maxFileSize = 5 * 1024 * 1024; // 5MB
        this.allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
        this.displayDuration = 24 * 60 * 60 * 1000; // 24 hours in milliseconds
    }

    validateImage(file) {
        const errors = [];
        const currentLang = getCurrentLanguage();

        if (!file) {
            errors.push(currentLang === 'ar' ? 'يرجى اختيار صورة' : 'Please select an image');
            return errors;
        }

        // التحقق من نوع الملف
        if (!this.allowedTypes.includes(file.type)) {
            errors.push(
                currentLang === 'ar' ? 
                'نوع الملف غير مدعوم. الأنواع المدعومة: JPG, PNG, GIF, WebP' : 
                'File type not supported. Supported types: JPG, PNG, GIF, WebP'
            );
        }

        // التحقق من حجم الملف
        if (file.size > this.maxFileSize) {
            errors.push(
                currentLang === 'ar' ? 
                'حجم الملف كبير جداً. الحد الأقصى 5 ميجابايت' : 
                'File size too large. Maximum 5MB'
            );
        }

        return errors;
    }

    async uploadImage(file, userId) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            
            reader.onload = (e) => {
                const imageData = e.target.result;
                
                // حفظ الصورة في قاعدة البيانات المحلية
                const expiresAt = new Date(Date.now() + this.displayDuration);
                
                const tempImage = {
                    user_id: userId,
                    image_url: imageData,
                    expires_at: expiresAt.toISOString(),
                    is_approved: true,
                    created_at: new Date().toISOString()
                };

                const savedImage = db.addItem('temp_images', tempImage);
                
                // تحديث صورة المستخدم
                db.updateItem('users', userId, {
                    profile_image: imageData,
                    profile_image_expires: expiresAt.toISOString()
                });

                resolve(savedImage);
            };
            
            reader.onerror = () => {
                reject(new Error('Failed to read file'));
            };
            
            reader.readAsDataURL(file);
        });
    }

    getCurrentUserImage() {
        const currentUser = db.getCurrentUser();
        if (!currentUser) return null;

        // التحقق من انتهاء صلاحية الصورة
        if (currentUser.profile_image_expires) {
            const expiryDate = new Date(currentUser.profile_image_expires);
            if (expiryDate <= new Date()) {
                // إزالة الصورة المنتهية الصلاحية
                db.updateItem('users', currentUser.id, {
                    profile_image: null,
                    profile_image_expires: null
                });
                return null;
            }
        }

        return currentUser.profile_image;
    }

    getTimeRemaining(expiryDate) {
        const now = new Date();
        const expiry = new Date(expiryDate);
        const diff = expiry - now;

        if (diff <= 0) return null;

        const hours = Math.floor(diff / (1000 * 60 * 60));
        const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));

        return { hours, minutes, total: diff };
    }

    showTool() {
        const currentLang = getCurrentLanguage();
        const currentUser = db.getCurrentUser();
        const currentImage = this.getCurrentUserImage();
        
        let imageStatus = '';
        if (currentImage && currentUser.profile_image_expires) {
            const timeRemaining = this.getTimeRemaining(currentUser.profile_image_expires);
            if (timeRemaining) {
                imageStatus = `
                    <div class="current-image-status">
                        <div class="status-header">
                            <i class="fas fa-clock"></i>
                            ${currentLang === 'ar' ? 'صورتك معروضة حالياً' : 'Your image is currently displayed'}
                        </div>
                        <div class="current-image-preview">
                            <img src="${currentImage}" alt="Profile Image">
                        </div>
                        <div class="time-remaining">
                            ${currentLang === 'ar' ? 'الوقت المتبقي:' : 'Time remaining:'} 
                            ${timeRemaining.hours}${currentLang === 'ar' ? ' ساعة' : 'h'} 
                            ${timeRemaining.minutes}${currentLang === 'ar' ? ' دقيقة' : 'm'}
                        </div>
                    </div>
                `;
            }
        }
        
        const content = `
            <div class="tool-header">
                <h3>${currentLang === 'ar' ? 'عرض الصورة الشخصية' : 'Profile Image Display'}</h3>
                <p>${currentLang === 'ar' ? 'اعرض صورتك في الموقع لمدة 24 ساعة' : 'Display your image on the site for 24 hours'}</p>
                <div class="premium-badge">
                    <i class="fas fa-star"></i>
                    ${currentLang === 'ar' ? 'أداة مميزة - 500 نقطة' : 'Premium Tool - 500 Points'}
                </div>
            </div>
            
            ${imageStatus}
            
            <div class="tool-form">
                <div class="upload-section">
                    <div class="upload-area" id="upload-area">
                        <div class="upload-icon">
                            <i class="fas fa-cloud-upload-alt"></i>
                        </div>
                        <div class="upload-text">
                            <h4>${currentLang === 'ar' ? 'اسحب الصورة هنا أو انقر للاختيار' : 'Drag image here or click to select'}</h4>
                            <p>${currentLang === 'ar' ? 'JPG, PNG, GIF, WebP - حد أقصى 5 ميجابايت' : 'JPG, PNG, GIF, WebP - Max 5MB'}</p>
                        </div>
                        <input type="file" id="image-input" accept="image/*" style="display: none;">
                    </div>
                    
                    <div class="image-preview" id="image-preview" style="display: none;">
                        <img id="preview-img" src="" alt="Preview">
                        <div class="preview-actions">
                            <button class="remove-btn" onclick="removePreview()">
                                <i class="fas fa-times"></i>
                                ${currentLang === 'ar' ? 'إزالة' : 'Remove'}
                            </button>
                        </div>
                    </div>
                </div>
                
                <div class="image-guidelines">
                    <h4>${currentLang === 'ar' ? 'إرشادات الصورة:' : 'Image Guidelines:'}</h4>
                    <ul>
                        <li>${currentLang === 'ar' ? 'يجب أن تكون الصورة مناسبة وغير مخلة بالآداب' : 'Image must be appropriate and not offensive'}</li>
                        <li>${currentLang === 'ar' ? 'ستظهر الصورة لمدة 24 ساعة فقط' : 'Image will be displayed for 24 hours only'}</li>
                        <li>${currentLang === 'ar' ? 'يحق للإدارة حذف الصور المخالفة' : 'Management reserves the right to remove inappropriate images'}</li>
                        <li>${currentLang === 'ar' ? 'الحد الأقصى لحجم الصورة 5 ميجابايت' : 'Maximum image size is 5MB'}</li>
                    </ul>
                </div>
                
                <button onclick="uploadProfileImage()" class="upload-btn premium" id="upload-btn" disabled>
                    <i class="fas fa-upload"></i>
                    ${currentLang === 'ar' ? 'رفع الصورة (500 نقطة)' : 'Upload Image (500 Points)'}
                </button>
            </div>
            
            <div class="featured-images-section">
                <h4>${currentLang === 'ar' ? 'الصور المعروضة حالياً' : 'Currently Featured Images'}</h4>
                <div class="featured-images-grid" id="featured-images">
                    <!-- سيتم ملؤها بواسطة JavaScript -->
                </div>
            </div>
            
            <style>
                .tool-header {
                    text-align: center;
                    margin-bottom: 2rem;
                }
                
                .tool-header h3 {
                    color: #667eea;
                    font-size: 1.8rem;
                    margin-bottom: 0.5rem;
                }
                
                .tool-header p {
                    color: #666;
                    font-size: 1.1rem;
                    margin-bottom: 1rem;
                }
                
                .premium-badge {
                    background: linear-gradient(45deg, #ff6b6b, #ee5a24);
                    color: white;
                    padding: 0.5rem 1rem;
                    border-radius: 25px;
                    display: inline-flex;
                    align-items: center;
                    gap: 0.5rem;
                    font-weight: 600;
                    box-shadow: 0 4px 15px rgba(255, 107, 107, 0.3);
                }
                
                .current-image-status {
                    background: linear-gradient(135deg, #4caf50, #45a049);
                    color: white;
                    padding: 2rem;
                    border-radius: 15px;
                    margin-bottom: 2rem;
                    text-align: center;
                }
                
                .status-header {
                    font-size: 1.2rem;
                    font-weight: 600;
                    margin-bottom: 1rem;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    gap: 0.5rem;
                }
                
                .current-image-preview {
                    margin: 1rem 0;
                }
                
                .current-image-preview img {
                    width: 150px;
                    height: 150px;
                    object-fit: cover;
                    border-radius: 50%;
                    border: 4px solid white;
                    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
                }
                
                .time-remaining {
                    font-size: 1.1rem;
                    font-weight: 600;
                    background: rgba(255, 255, 255, 0.2);
                    padding: 0.5rem 1rem;
                    border-radius: 20px;
                    display: inline-block;
                }
                
                .tool-form {
                    background: linear-gradient(135deg, #f8f9fa, #e9ecef);
                    padding: 2rem;
                    border-radius: 15px;
                    margin-bottom: 2rem;
                    border: 2px solid #ff6b6b;
                }
                
                .upload-section {
                    margin-bottom: 2rem;
                }
                
                .upload-area {
                    border: 3px dashed #ccc;
                    border-radius: 15px;
                    padding: 3rem;
                    text-align: center;
                    cursor: pointer;
                    transition: all 0.3s ease;
                    background: white;
                }
                
                .upload-area:hover {
                    border-color: #ff6b6b;
                    background: #fff5f5;
                }
                
                .upload-area.dragover {
                    border-color: #ff6b6b;
                    background: #fff5f5;
                    transform: scale(1.02);
                }
                
                .upload-icon {
                    font-size: 4rem;
                    color: #ccc;
                    margin-bottom: 1rem;
                }
                
                .upload-area:hover .upload-icon {
                    color: #ff6b6b;
                }
                
                .upload-text h4 {
                    color: #333;
                    margin-bottom: 0.5rem;
                }
                
                .upload-text p {
                    color: #666;
                    font-size: 0.9rem;
                }
                
                .image-preview {
                    text-align: center;
                    background: white;
                    padding: 2rem;
                    border-radius: 15px;
                    border: 2px solid #4caf50;
                }
                
                .image-preview img {
                    max-width: 300px;
                    max-height: 300px;
                    object-fit: contain;
                    border-radius: 10px;
                    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
                }
                
                .preview-actions {
                    margin-top: 1rem;
                }
                
                .remove-btn {
                    background: #f44336;
                    color: white;
                    border: none;
                    padding: 0.75rem 1.5rem;
                    border-radius: 20px;
                    cursor: pointer;
                    font-weight: 600;
                    display: inline-flex;
                    align-items: center;
                    gap: 0.5rem;
                    transition: all 0.3s ease;
                }
                
                .remove-btn:hover {
                    background: #d32f2f;
                    transform: translateY(-2px);
                }
                
                .image-guidelines {
                    background: #fff3cd;
                    border: 1px solid #ffeaa7;
                    border-radius: 10px;
                    padding: 1.5rem;
                    margin-bottom: 2rem;
                }
                
                .image-guidelines h4 {
                    color: #856404;
                    margin-bottom: 1rem;
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                }
                
                .image-guidelines ul {
                    list-style: none;
                    padding: 0;
                }
                
                .image-guidelines li {
                    color: #856404;
                    margin-bottom: 0.5rem;
                    padding-left: 1.5rem;
                    position: relative;
                }
                
                .image-guidelines li::before {
                    content: '⚠️';
                    position: absolute;
                    left: 0;
                }
                
                .upload-btn.premium {
                    background: linear-gradient(45deg, #ff6b6b, #ee5a24);
                    color: white;
                    border: none;
                    padding: 1rem 2rem;
                    border-radius: 25px;
                    cursor: pointer;
                    font-weight: 600;
                    font-size: 1.1rem;
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                    margin: 0 auto;
                    transition: all 0.3s ease;
                    box-shadow: 0 4px 15px rgba(255, 107, 107, 0.3);
                }
                
                .upload-btn.premium:hover:not(:disabled) {
                    transform: translateY(-3px);
                    box-shadow: 0 8px 25px rgba(255, 107, 107, 0.4);
                }
                
                .upload-btn:disabled {
                    opacity: 0.5;
                    cursor: not-allowed;
                    transform: none !important;
                }
                
                .featured-images-section {
                    background: white;
                    padding: 2rem;
                    border-radius: 15px;
                    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
                }
                
                .featured-images-section h4 {
                    color: #667eea;
                    margin-bottom: 1.5rem;
                    text-align: center;
                }
                
                .featured-images-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
                    gap: 1rem;
                }
                
                .featured-image-item {
                    position: relative;
                    border-radius: 10px;
                    overflow: hidden;
                    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
                    transition: transform 0.3s ease;
                }
                
                .featured-image-item:hover {
                    transform: scale(1.05);
                }
                
                .featured-image-item img {
                    width: 100%;
                    height: 150px;
                    object-fit: cover;
                }
                
                .image-overlay {
                    position: absolute;
                    bottom: 0;
                    left: 0;
                    right: 0;
                    background: linear-gradient(transparent, rgba(0, 0, 0, 0.7));
                    color: white;
                    padding: 1rem 0.5rem 0.5rem;
                    font-size: 0.8rem;
                    text-align: center;
                }
                
                .no-images {
                    text-align: center;
                    color: #666;
                    font-style: italic;
                    padding: 2rem;
                }
                
                @media (max-width: 768px) {
                    .upload-area {
                        padding: 2rem 1rem;
                    }
                    
                    .upload-icon {
                        font-size: 3rem;
                    }
                    
                    .image-preview img {
                        max-width: 250px;
                        max-height: 250px;
                    }
                    
                    .featured-images-grid {
                        grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
                    }
                }
            </style>
        `;
        
        return content;
    }

    loadFeaturedImages() {
        const images = db.getData('temp_images');
        const now = new Date();
        
        // تصفية الصور النشطة فقط
        const activeImages = images.filter(img => {
            const expiryDate = new Date(img.expires_at);
            return expiryDate > now && img.is_approved;
        });

        return activeImages;
    }
}

// إنشاء مثيل من أداة الصورة الشخصية
const profileImage = new ProfileImage();

// إعداد مستمعي الأحداث عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    // إعداد منطقة الرفع
    document.addEventListener('click', (e) => {
        if (e.target.closest('#upload-area')) {
            document.getElementById('image-input').click();
        }
    });

    // إعداد تغيير الملف
    document.addEventListener('change', (e) => {
        if (e.target.id === 'image-input') {
            handleFileSelect(e.target.files[0]);
        }
    });

    // إعداد السحب والإفلات
    document.addEventListener('dragover', (e) => {
        if (e.target.closest('#upload-area')) {
            e.preventDefault();
            e.target.closest('#upload-area').classList.add('dragover');
        }
    });

    document.addEventListener('dragleave', (e) => {
        if (e.target.closest('#upload-area')) {
            e.target.closest('#upload-area').classList.remove('dragover');
        }
    });

    document.addEventListener('drop', (e) => {
        if (e.target.closest('#upload-area')) {
            e.preventDefault();
            e.target.closest('#upload-area').classList.remove('dragover');
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                handleFileSelect(files[0]);
            }
        }
    });
});

// دالة معالجة اختيار الملف
function handleFileSelect(file) {
    const errors = profileImage.validateImage(file);
    
    if (errors.length > 0) {
        showNotification(errors.join('\n'), 'error');
        return;
    }

    // عرض معاينة الصورة
    const reader = new FileReader();
    reader.onload = (e) => {
        document.getElementById('upload-area').style.display = 'none';
        document.getElementById('image-preview').style.display = 'block';
        document.getElementById('preview-img').src = e.target.result;
        document.getElementById('upload-btn').disabled = false;
    };
    reader.readAsDataURL(file);
}

// دالة إزالة المعاينة
function removePreview() {
    document.getElementById('upload-area').style.display = 'block';
    document.getElementById('image-preview').style.display = 'none';
    document.getElementById('image-input').value = '';
    document.getElementById('upload-btn').disabled = true;
}

// دالة رفع الصورة الشخصية
async function uploadProfileImage() {
    const currentUser = db.getCurrentUser();
    if (!currentUser) {
        showNotification(getCurrentLanguage() === 'ar' ? 'يجب تسجيل الدخول أولاً' : 'Please login first', 'error');
        return;
    }

    // التحقق من وجود النقاط الكافية
    if (currentUser.points < 500) {
        showNotification(
            getCurrentLanguage() === 'ar' ? 
            `تحتاج إلى 500 نقطة لاستخدام هذه الأداة. نقاطك الحالية: ${currentUser.points}` : 
            `You need 500 points to use this tool. Your current points: ${currentUser.points}`,
            'warning'
        );
        return;
    }

    const fileInput = document.getElementById('image-input');
    const file = fileInput.files[0];
    
    if (!file) {
        showNotification(getCurrentLanguage() === 'ar' ? 'يرجى اختيار صورة' : 'Please select an image', 'warning');
        return;
    }

    const currentLang = getCurrentLanguage();
    const uploadBtn = document.getElementById('upload-btn');
    
    // تعطيل الزر وإظهار مؤشر التحميل
    uploadBtn.disabled = true;
    uploadBtn.innerHTML = `
        <i class="fas fa-spinner fa-spin"></i>
        ${currentLang === 'ar' ? 'جاري الرفع...' : 'Uploading...'}
    `;

    try {
        // رفع الصورة
        await profileImage.uploadImage(file, currentUser.id);
        
        // خصم النقاط
        const newPoints = currentUser.points - 500;
        db.updateItem('users', currentUser.id, { points: newPoints });
        
        // تحديث عرض النقاط
        updateUserPointsDisplay();
        
        // تحديث الصور المعروضة
        loadFeaturedImages();
        
        // إعادة تعيين النموذج
        removePreview();
        
        showNotification(
            currentLang === 'ar' ? 'تم رفع الصورة بنجاح! ستظهر لمدة 24 ساعة' : 'Image uploaded successfully! It will be displayed for 24 hours',
            'success'
        );
        
        // إعادة تحميل الأداة لإظهار الحالة الجديدة
        setTimeout(() => {
            const toolContent = document.getElementById('tool-content');
            if (toolContent) {
                toolContent.innerHTML = profileImage.showTool();
                loadFeaturedImages();
            }
        }, 1000);
        
    } catch (error) {
        showNotification(
            currentLang === 'ar' ? 'حدث خطأ أثناء رفع الصورة' : 'Error uploading image',
            'error'
        );
    } finally {
        // إعادة تفعيل الزر
        uploadBtn.disabled = false;
        uploadBtn.innerHTML = `
            <i class="fas fa-upload"></i>
            ${currentLang === 'ar' ? 'رفع الصورة (500 نقطة)' : 'Upload Image (500 Points)'}
        `;
    }
}

// دالة تحميل الصور المعروضة
function loadFeaturedImages() {
    const featuredImagesContainer = document.getElementById('featured-images');
    if (!featuredImagesContainer) return;

    const images = profileImage.loadFeaturedImages();
    const currentLang = getCurrentLanguage();
    
    if (images.length === 0) {
        featuredImagesContainer.innerHTML = `
            <div class="no-images">
                ${currentLang === 'ar' ? 'لا توجد صور معروضة حالياً' : 'No images currently displayed'}
            </div>
        `;
        return;
    }

    featuredImagesContainer.innerHTML = images.map(img => {
        const timeRemaining = profileImage.getTimeRemaining(img.expires_at);
        const timeText = timeRemaining ? 
            `${timeRemaining.hours}${currentLang === 'ar' ? 'س' : 'h'} ${timeRemaining.minutes}${currentLang === 'ar' ? 'د' : 'm'}` : 
            (currentLang === 'ar' ? 'منتهية الصلاحية' : 'Expired');
            
        return `
            <div class="featured-image-item">
                <img src="${img.image_url}" alt="Featured Image">
                <div class="image-overlay">
                    ${timeText}
                </div>
            </div>
        `;
    }).join('');
}

// تحميل الصور المعروضة عند فتح الأداة
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        loadFeaturedImages();
    }, 500);
});

