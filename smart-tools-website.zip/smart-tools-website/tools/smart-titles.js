// أداة إنشاء العناوين الذكية
class SmartTitles {
    constructor() {
        this.titleTemplates = {
            ar: [
                "كيف تصبح {topic} في {time}",
                "أسرار {topic} التي لا يعرفها أحد",
                "دليلك الشامل لـ {topic}",
                "أفضل {number} طرق لـ {topic}",
                "تعلم {topic} من الصفر حتى الاحتراف",
                "أخطاء شائعة في {topic} وكيفية تجنبها",
                "مستقبل {topic} في عام {year}",
                "لماذا يجب عليك تعلم {topic} الآن؟",
                "أدوات {topic} المجانية التي تحتاجها",
                "قصة نجاح في {topic} ستلهمك",
                "تحدي {topic} لمدة {time}",
                "مقارنة بين أفضل {topic} في السوق",
                "نصائح {topic} للمبتدئين",
                "كيف غيّر {topic} حياتي؟",
                "أهم اتجاهات {topic} لهذا العام"
            ],
            en: [
                "How to Master {topic} in {time}",
                "Secret {topic} Tips Nobody Tells You",
                "Complete Guide to {topic}",
                "Top {number} Ways to {topic}",
                "Learn {topic} from Zero to Hero",
                "Common {topic} Mistakes and How to Avoid Them",
                "The Future of {topic} in {year}",
                "Why You Should Learn {topic} Now",
                "Free {topic} Tools You Need",
                "Inspiring {topic} Success Story",
                "{topic} Challenge for {time}",
                "Best {topic} Comparison in the Market",
                "{topic} Tips for Beginners",
                "How {topic} Changed My Life",
                "Top {topic} Trends This Year"
            ]
        };

        this.topics = {
            ar: [
                "البرمجة", "التسويق الرقمي", "التصميم", "ريادة الأعمال", "الذكاء الاصطناعي",
                "التجارة الإلكترونية", "إدارة الوقت", "التطوير الشخصي", "الاستثمار", "التصوير",
                "الكتابة", "اللغات", "الطبخ", "الرياضة", "الصحة", "التكنولوجيا", "السفر",
                "الموسيقى", "الفن", "العلوم", "التاريخ", "الفلسفة", "علم النفس", "التعليم"
            ],
            en: [
                "Programming", "Digital Marketing", "Design", "Entrepreneurship", "Artificial Intelligence",
                "E-commerce", "Time Management", "Personal Development", "Investment", "Photography",
                "Writing", "Languages", "Cooking", "Sports", "Health", "Technology", "Travel",
                "Music", "Art", "Science", "History", "Philosophy", "Psychology", "Education"
            ]
        };

        this.timeFrames = {
            ar: ["30 يوماً", "3 أشهر", "6 أشهر", "سنة واحدة", "أسبوع واحد", "شهر واحد"],
            en: ["30 Days", "3 Months", "6 Months", "One Year", "One Week", "One Month"]
        };

        this.numbers = ["5", "10", "7", "15", "20", "3", "12"];
        this.currentYear = new Date().getFullYear();
    }

    generateTitle(language = 'ar', customTopic = '') {
        const templates = this.titleTemplates[language];
        const topics = this.topics[language];
        const timeFrames = this.timeFrames[language];

        // اختيار قالب عشوائي
        const template = templates[Math.floor(Math.random() * templates.length)];
        
        // اختيار موضوع
        const topic = customTopic || topics[Math.floor(Math.random() * topics.length)];
        
        // اختيار إطار زمني عشوائي
        const time = timeFrames[Math.floor(Math.random() * timeFrames.length)];
        
        // اختيار رقم عشوائي
        const number = this.numbers[Math.floor(Math.random() * this.numbers.length)];
        
        // استبدال المتغيرات في القالب
        let title = template
            .replace('{topic}', topic)
            .replace('{time}', time)
            .replace('{number}', number)
            .replace('{year}', this.currentYear);

        return title;
    }

    generateMultipleTitles(count = 5, language = 'ar', customTopic = '') {
        const titles = [];
        for (let i = 0; i < count; i++) {
            titles.push(this.generateTitle(language, customTopic));
        }
        return titles;
    }

    showTool() {
        const currentLang = getCurrentLanguage();
        const content = `
            <div class="tool-header">
                <h3>${currentLang === 'ar' ? 'أداة إنشاء العناوين الذكية' : 'Smart Title Generator'}</h3>
                <p>${currentLang === 'ar' ? 'أنشئ عناوين جذابة ومبتكرة لمحتواك' : 'Create attractive and innovative titles for your content'}</p>
            </div>
            
            <div class="tool-form">
                <div class="form-group">
                    <label for="custom-topic">${currentLang === 'ar' ? 'الموضوع (اختياري):' : 'Topic (Optional):'}</label>
                    <input type="text" id="custom-topic" placeholder="${currentLang === 'ar' ? 'اكتب موضوعك هنا...' : 'Enter your topic here...'}">
                </div>
                
                <div class="form-group">
                    <label for="title-count">${currentLang === 'ar' ? 'عدد العناوين:' : 'Number of Titles:'}</label>
                    <select id="title-count">
                        <option value="3">3</option>
                        <option value="5" selected>5</option>
                        <option value="10">10</option>
                        <option value="15">15</option>
                    </select>
                </div>
                
                <button onclick="generateTitles()" class="generate-btn">
                    <i class="fas fa-magic"></i>
                    ${currentLang === 'ar' ? 'إنشاء العناوين' : 'Generate Titles'}
                </button>
            </div>
            
            <div class="tool-results" id="titles-results">
                <!-- سيتم عرض النتائج هنا -->
            </div>
            
            <style>
                .tool-header {
                    text-align: center;
                    margin-bottom: 2rem;
                }
                
                .tool-header h3 {
                    color: #667eea;
                    font-size: 1.8rem;
                    margin-bottom: 0.5rem;
                }
                
                .tool-header p {
                    color: #666;
                    font-size: 1.1rem;
                }
                
                .tool-form {
                    background: #f8f9fa;
                    padding: 2rem;
                    border-radius: 15px;
                    margin-bottom: 2rem;
                }
                
                .form-group {
                    margin-bottom: 1.5rem;
                }
                
                .form-group label {
                    display: block;
                    margin-bottom: 0.5rem;
                    font-weight: 600;
                    color: #333;
                }
                
                .form-group input,
                .form-group select {
                    width: 100%;
                    padding: 1rem;
                    border: 2px solid #e2e8f0;
                    border-radius: 10px;
                    font-size: 1rem;
                }
                
                .form-group input:focus,
                .form-group select:focus {
                    outline: none;
                    border-color: #667eea;
                }
                
                .generate-btn {
                    background: linear-gradient(45deg, #667eea, #764ba2);
                    color: white;
                    border: none;
                    padding: 1rem 2rem;
                    border-radius: 25px;
                    cursor: pointer;
                    font-weight: 600;
                    font-size: 1.1rem;
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                    margin: 0 auto;
                    transition: all 0.3s ease;
                }
                
                .generate-btn:hover {
                    transform: translateY(-2px);
                    box-shadow: 0 8px 20px rgba(102, 126, 234, 0.3);
                }
                
                .tool-results {
                    min-height: 100px;
                }
                
                .titles-list {
                    display: flex;
                    flex-direction: column;
                    gap: 1rem;
                }
                
                .title-item {
                    background: white;
                    padding: 1.5rem;
                    border-radius: 10px;
                    border-left: 4px solid #667eea;
                    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    transition: transform 0.2s ease;
                }
                
                .title-item:hover {
                    transform: translateX(5px);
                }
                
                .title-text {
                    flex: 1;
                    font-size: 1.1rem;
                    color: #333;
                    line-height: 1.5;
                }
                
                .copy-btn {
                    background: #667eea;
                    color: white;
                    border: none;
                    padding: 0.5rem 1rem;
                    border-radius: 20px;
                    cursor: pointer;
                    font-size: 0.9rem;
                    transition: all 0.2s ease;
                }
                
                .copy-btn:hover {
                    background: #5a67d8;
                }
                
                .loading {
                    text-align: center;
                    padding: 2rem;
                    color: #667eea;
                }
                
                .loading i {
                    font-size: 2rem;
                    animation: spin 1s linear infinite;
                }
                
                @keyframes spin {
                    from { transform: rotate(0deg); }
                    to { transform: rotate(360deg); }
                }
            </style>
        `;
        
        return content;
    }
}

// إنشاء مثيل من الأداة
const smartTitles = new SmartTitles();

// دالة إنشاء العناوين
function generateTitles() {
    const currentUser = db.getCurrentUser();
    if (!currentUser) {
        showNotification(getCurrentLanguage() === 'ar' ? 'يجب تسجيل الدخول أولاً' : 'Please login first', 'error');
        return;
    }

    // التحقق من استخدام الأداة اليوم
    if (db.hasUsedToolToday(currentUser.id, 'smart_titles')) {
        showNotification(getCurrentLanguage() === 'ar' ? 'لقد استخدمت هذه الأداة اليوم بالفعل' : 'You have already used this tool today', 'warning');
        return;
    }

    const customTopic = document.getElementById('custom-topic').value.trim();
    const titleCount = parseInt(document.getElementById('title-count').value);
    const currentLang = getCurrentLanguage();
    
    // عرض مؤشر التحميل
    const resultsDiv = document.getElementById('titles-results');
    resultsDiv.innerHTML = `
        <div class="loading">
            <i class="fas fa-spinner"></i>
            <p>${currentLang === 'ar' ? 'جاري إنشاء العناوين...' : 'Generating titles...'}</p>
        </div>
    `;
    
    // محاكاة وقت المعالجة
    setTimeout(() => {
        const titles = smartTitles.generateMultipleTitles(titleCount, currentLang, customTopic);
        
        let titlesHTML = '<div class="titles-list">';
        titles.forEach((title, index) => {
            titlesHTML += `
                <div class="title-item">
                    <div class="title-text">${title}</div>
                    <button class="copy-btn" onclick="copyTitle('${title.replace(/'/g, "\\'")}')">
                        <i class="fas fa-copy"></i>
                        ${currentLang === 'ar' ? 'نسخ' : 'Copy'}
                    </button>
                </div>
            `;
        });
        titlesHTML += '</div>';
        
        resultsDiv.innerHTML = titlesHTML;
        
        // إضافة النقاط وتسجيل الاستخدام
        db.markToolUsed(currentUser.id, 'smart_titles');
        db.addPoints(currentUser.id, 'smart_titles', 25);
        
        // تحديث عرض النقاط
        updateUserPointsDisplay();
        
        showNotification(
            currentLang === 'ar' ? 'تم إنشاء العناوين بنجاح! حصلت على 25 نقطة' : 'Titles generated successfully! You earned 25 points',
            'success'
        );
    }, 1500);
}

// دالة نسخ العنوان
function copyTitle(title) {
    navigator.clipboard.writeText(title).then(() => {
        showNotification(
            getCurrentLanguage() === 'ar' ? 'تم نسخ العنوان' : 'Title copied',
            'success'
        );
    }).catch(() => {
        // طريقة بديلة للنسخ
        const textArea = document.createElement('textarea');
        textArea.value = title;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
        
        showNotification(
            getCurrentLanguage() === 'ar' ? 'تم نسخ العنوان' : 'Title copied',
            'success'
        );
    });
}

