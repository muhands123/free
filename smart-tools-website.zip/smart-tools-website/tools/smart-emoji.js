// أداة إنشاء الإيموجي الذكية
class SmartEmoji {
    constructor() {
        this.emojiCategories = {
            faces: ['😀', '😃', '😄', '😁', '😆', '😅', '🤣', '😂', '🙂', '🙃', '😉', '😊', '😇', '🥰', '😍', '🤩', '😘', '😗', '😚', '😙', '😋', '😛', '😜', '🤪', '😝', '🤑', '🤗', '🤭', '🤫', '🤔', '🤐', '🤨', '😐', '😑', '😶', '😏', '😒', '🙄', '😬', '🤥', '😔', '😪', '🤤', '😴', '😷', '🤒', '🤕', '🤢', '🤮', '🤧', '🥵', '🥶', '🥴', '😵', '🤯', '🤠', '🥳', '😎', '🤓', '🧐'],
            animals: ['🐶', '🐱', '🐭', '🐹', '🐰', '🦊', '🐻', '🐼', '🐨', '🐯', '🦁', '🐮', '🐷', '🐽', '🐸', '🐵', '🙈', '🙉', '🙊', '🐒', '🐔', '🐧', '🐦', '🐤', '🐣', '🐥', '🦆', '🦅', '🦉', '🦇', '🐺', '🐗', '🐴', '🦄', '🐝', '🐛', '🦋', '🐌', '🐞', '🐜', '🦟', '🦗', '🕷', '🕸', '🦂', '🐢', '🐍', '🦎', '🦖', '🦕', '🐙', '🦑', '🦐', '🦞', '🦀', '🐡', '🐠', '🐟', '🐬', '🐳', '🐋', '🦈', '🐊', '🐅', '🐆', '🦓', '🦍', '🦧', '🐘', '🦛', '🦏', '🐪', '🐫', '🦒', '🦘', '🐃', '🐂', '🐄', '🐎', '🐖', '🐏', '🐑', '🦙', '🐐', '🦌', '🐕', '🐩', '🦮', '🐕‍🦺', '🐈', '🐓', '🦃', '🦚', '🦜', '🦢', '🦩', '🕊', '🐇', '🦝', '🦨', '🦡', '🦦', '🦥', '🐁', '🐀', '🐿', '🦔'],
            food: ['🍎', '🍐', '🍊', '🍋', '🍌', '🍉', '🍇', '🍓', '🫐', '🍈', '🍒', '🍑', '🥭', '🍍', '🥥', '🥝', '🍅', '🍆', '🥑', '🥦', '🥬', '🥒', '🌶', '🫑', '🌽', '🥕', '🫒', '🧄', '🧅', '🥔', '🍠', '🥐', '🥯', '🍞', '🥖', '🥨', '🧀', '🥚', '🍳', '🧈', '🥞', '🧇', '🥓', '🥩', '🍗', '🍖', '🦴', '🌭', '🍔', '🍟', '🍕', '🫓', '🥪', '🥙', '🧆', '🌮', '🌯', '🫔', '🥗', '🥘', '🫕', '🥫', '🍝', '🍜', '🍲', '🍛', '🍣', '🍱', '🥟', '🦪', '🍤', '🍙', '🍚', '🍘', '🍥', '🥠', '🥮', '🍢', '🍡', '🍧', '🍨', '🍦', '🥧', '🧁', '🍰', '🎂', '🍮', '🍭', '🍬', '🍫', '🍿', '🍩', '🍪', '🌰', '🥜', '🍯'],
            activities: ['⚽', '🏀', '🏈', '⚾', '🥎', '🎾', '🏐', '🏉', '🥏', '🎱', '🪀', '🏓', '🏸', '🏒', '🏑', '🥍', '🏏', '🪃', '🥅', '⛳', '🪁', '🏹', '🎣', '🤿', '🥊', '🥋', '🎽', '🛹', '🛷', '⛸', '🥌', '🎿', '⛷', '🏂', '🪂', '🏋️‍♀️', '🏋️', '🏋️‍♂️', '🤼‍♀️', '🤼', '🤼‍♂️', '🤸‍♀️', '🤸', '🤸‍♂️', '⛹️‍♀️', '⛹️', '⛹️‍♂️', '🤺', '🤾‍♀️', '🤾', '🤾‍♂️', '🏌️‍♀️', '🏌️', '🏌️‍♂️', '🏇', '🧘‍♀️', '🧘', '🧘‍♂️', '🏄‍♀️', '🏄', '🏄‍♂️', '🏊‍♀️', '🏊', '🏊‍♂️', '🤽‍♀️', '🤽', '🤽‍♂️', '🚣‍♀️', '🚣', '🚣‍♂️', '🧗‍♀️', '🧗', '🧗‍♂️', '🚵‍♀️', '🚵', '🚵‍♂️', '🚴‍♀️', '🚴', '🚴‍♂️', '🏆', '🥇', '🥈', '🥉', '🏅', '🎖', '🏵', '🎗', '🎫', '🎟', '🎪', '🤹‍♀️', '🤹', '🤹‍♂️', '🎭', '🩰', '🎨', '🎬', '🎤', '🎧', '🎼', '🎵', '🎶', '🥁', '🪘', '🎹', '🎷', '🎺', '🎸', '🪕', '🎻', '🎲', '♠️', '♥️', '♦️', '♣️', '♟', '🃏', '🀄', '🎴'],
            objects: ['⌚', '📱', '📲', '💻', '⌨️', '🖥', '🖨', '🖱', '🖲', '🕹', '🗜', '💽', '💾', '💿', '📀', '📼', '📷', '📸', '📹', '🎥', '📽', '🎞', '📞', '☎️', '📟', '📠', '📺', '📻', '🎙', '🎚', '🎛', '🧭', '⏱', '⏲', '⏰', '🕰', '⌛', '⏳', '📡', '🔋', '🔌', '💡', '🔦', '🕯', '🪔', '🧯', '🛢', '💸', '💵', '💴', '💶', '💷', '🪙', '💰', '💳', '💎', '⚖️', '🪜', '🧰', '🔧', '🔨', '⚒', '🛠', '⛏', '🪓', '🪚', '🔩', '⚙️', '🪤', '🧱', '⛓', '🧲', '🔫', '💣', '🧨', '🪓', '🔪', '🗡', '⚔️', '🛡', '🚬', '⚰️', '🪦', '⚱️', '🏺', '🔮', '📿', '🧿', '💈', '⚗️', '🔭', '🔬', '🕳', '🩹', '🩺', '💊', '💉', '🩸', '🧬', '🦠', '🧫', '🧪', '🌡', '🧹', '🪣', '🧽', '🧴', '🛎', '🔑', '🗝', '🚪', '🪑', '🛋', '🛏', '🛌', '🧸', '🪆', '🖼', '🪞', '🪟', '🛍', '🛒', '🎁', '🎈', '🎏', '🎀', '🪄', '🪅', '🎊', '🎉', '🪩', '🎎', '🏮', '🎐', '🧧', '✉️', '📩', '📨', '📧', '💌', '📥', '📤', '📦', '🏷', '🪧', '📪', '📫', '📬', '📭', '📮', '📯', '📜', '📃', '📄', '📑', '🧾', '📊', '📈', '📉', '🗒', '🗓', '📆', '📅', '🗑', '📇', '🗃', '🗳', '🗄', '📋', '📁', '📂', '🗂', '🗞', '📰', '📓', '📔', '📒', '📕', '📗', '📘', '📙', '📚', '📖', '🔖', '🧷', '🔗', '📎', '🖇', '📐', '📏', '🧮', '📌', '📍', '✂️', '🖊', '🖋', '✒️', '🖌', '🖍', '📝', '✏️', '🔍', '🔎', '🔏', '🔐', '🔒', '🔓'],
            symbols: ['❤️', '🧡', '💛', '💚', '💙', '💜', '🖤', '🤍', '🤎', '💔', '❣️', '💕', '💞', '💓', '💗', '💖', '💘', '💝', '💟', '☮️', '✝️', '☪️', '🕉', '☸️', '✡️', '🔯', '🕎', '☯️', '☦️', '🛐', '⛎', '♈', '♉', '♊', '♋', '♌', '♍', '♎', '♏', '♐', '♑', '♒', '♓', '🆔', '⚛️', '🉑', '☢️', '☣️', '📴', '📳', '🈶', '🈚', '🈸', '🈺', '🈷️', '✴️', '🆚', '💮', '🉐', '㊙️', '㊗️', '🈴', '🈵', '🈹', '🈲', '🅰️', '🅱️', '🆎', '🆑', '🅾️', '🆘', '❌', '⭕', '🛑', '⛔', '📛', '🚫', '💯', '💢', '♨️', '🚷', '🚯', '🚳', '🚱', '🔞', '📵', '🚭', '❗', '❕', '❓', '❔', '‼️', '⁉️', '🔅', '🔆', '〽️', '⚠️', '🚸', '🔱', '⚜️', '🔰', '♻️', '✅', '🈯', '💹', '❇️', '✳️', '❎', '🌐', '💠', 'Ⓜ️', '🌀', '💤', '🏧', '🚾', '♿', '🅿️', '🛗', '🈳', '🈂️', '🛂', '🛃', '🛄', '🛅', '🚹', '🚺', '🚼', '⚧', '🚻', '🚮', '🎦', '📶', '🈁', '🔣', 'ℹ️', '🔤', '🔡', '🔠', '🆖', '🆗', '🆙', '🆒', '🆕', '🆓', '0️⃣', '1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟', '🔢', '#️⃣', '*️⃣', '⏏️', '▶️', '⏸', '⏯', '⏹', '⏺', '⏭', '⏮', '⏩', '⏪', '⏫', '⏬', '◀️', '🔼', '🔽', '➡️', '⬅️', '⬆️', '⬇️', '↗️', '↘️', '↙️', '↖️', '↕️', '↔️', '↪️', '↩️', '⤴️', '⤵️', '🔀', '🔁', '🔂', '🔄', '🔃', '🎵', '🎶', '➕', '➖', '➗', '✖️', '🟰', '♾', '💲', '💱', '™️', '©️', '®️', '〰️', '➰', '➿', '🔚', '🔙', '🔛', '🔝', '🔜', '✔️', '☑️', '🔘', '🔴', '🟠', '🟡', '🟢', '🔵', '🟣', '⚫', '⚪', '🟤', '🔺', '🔻', '🔸', '🔹', '🔶', '🔷', '🔳', '🔲', '▪️', '▫️', '◾', '◽', '◼️', '◻️', '🟥', '🟧', '🟨', '🟩', '🟦', '🟪', '⬛', '⬜', '🟫', '🔈', '🔇', '🔉', '🔊', '🔔', '🔕', '📣', '📢', '👁‍🗨', '💬', '💭', '🗯', '♠️', '♣️', '♥️', '♦️', '🃏', '🎴', '🀄', '🕐', '🕑', '🕒', '🕓', '🕔', '🕕', '🕖', '🕗', '🕘', '🕙', '🕚', '🕛', '🕜', '🕝', '🕞', '🕟', '🕠', '🕡', '🕢', '🕣', '🕤', '🕥', '🕦', '🕧']
        };

        this.emojiMoods = {
            ar: {
                'سعيد': ['😀', '😃', '😄', '😁', '😆', '😊', '🙂', '😍', '🥰', '😘'],
                'حزين': ['😢', '😭', '😔', '😞', '😟', '😕', '🙁', '☹️', '😣', '😖'],
                'غاضب': ['😠', '😡', '🤬', '😤', '💢', '👿', '😾', '🗯️', '💥', '🔥'],
                'مفاجئ': ['😲', '😱', '🤯', '😵', '🤭', '😮', '😯', '😦', '😧', '😨'],
                'مضحك': ['😂', '🤣', '😹', '😆', '🤪', '😜', '😝', '🤡', '🙃', '😋'],
                'رومانسي': ['😍', '🥰', '😘', '💕', '💖', '💗', '💓', '💞', '💝', '❤️'],
                'متعب': ['😴', '😪', '🥱', '😫', '😩', '🤤', '💤', '😵‍💫', '🫠', '😮‍💨'],
                'متحمس': ['🤩', '🥳', '🎉', '🎊', '✨', '🌟', '⭐', '💫', '🔥', '💯']
            },
            en: {
                'happy': ['😀', '😃', '😄', '😁', '😆', '😊', '🙂', '😍', '🥰', '😘'],
                'sad': ['😢', '😭', '😔', '😞', '😟', '😕', '🙁', '☹️', '😣', '😖'],
                'angry': ['😠', '😡', '🤬', '😤', '💢', '👿', '😾', '🗯️', '💥', '🔥'],
                'surprised': ['😲', '😱', '🤯', '😵', '🤭', '😮', '😯', '😦', '😧', '😨'],
                'funny': ['😂', '🤣', '😹', '😆', '🤪', '😜', '😝', '🤡', '🙃', '😋'],
                'romantic': ['😍', '🥰', '😘', '💕', '💖', '💗', '💓', '💞', '💝', '❤️'],
                'tired': ['😴', '😪', '🥱', '😫', '😩', '🤤', '💤', '😵‍💫', '🫠', '😮‍💨'],
                'excited': ['🤩', '🥳', '🎉', '🎊', '✨', '🌟', '⭐', '💫', '🔥', '💯']
            }
        };

        this.emojiCombinations = {
            ar: [
                { name: 'احتفال', emojis: ['🎉', '🎊', '🥳', '🎈', '🎁'] },
                { name: 'حب', emojis: ['❤️', '💕', '😍', '💖', '💘'] },
                { name: 'طعام لذيذ', emojis: ['😋', '🍕', '🍔', '🍰', '🤤'] },
                { name: 'سفر', emojis: ['✈️', '🏖️', '🗺️', '📸', '🧳'] },
                { name: 'رياضة', emojis: ['⚽', '🏀', '🏆', '💪', '🥇'] },
                { name: 'دراسة', emojis: ['📚', '✏️', '🤓', '💡', '🎓'] },
                { name: 'عمل', emojis: ['💼', '💻', '📊', '⏰', '☕'] },
                { name: 'طبيعة', emojis: ['🌳', '🌸', '🦋', '🌞', '🌈'] },
                { name: 'موسيقى', emojis: ['🎵', '🎶', '🎤', '🎸', '🎧'] },
                { name: 'تكنولوجيا', emojis: ['💻', '📱', '🤖', '⚡', '🔬'] }
            ],
            en: [
                { name: 'celebration', emojis: ['🎉', '🎊', '🥳', '🎈', '🎁'] },
                { name: 'love', emojis: ['❤️', '💕', '😍', '💖', '💘'] },
                { name: 'delicious food', emojis: ['😋', '🍕', '🍔', '🍰', '🤤'] },
                { name: 'travel', emojis: ['✈️', '🏖️', '🗺️', '📸', '🧳'] },
                { name: 'sports', emojis: ['⚽', '🏀', '🏆', '💪', '🥇'] },
                { name: 'study', emojis: ['📚', '✏️', '🤓', '💡', '🎓'] },
                { name: 'work', emojis: ['💼', '💻', '📊', '⏰', '☕'] },
                { name: 'nature', emojis: ['🌳', '🌸', '🦋', '🌞', '🌈'] },
                { name: 'music', emojis: ['🎵', '🎶', '🎤', '🎸', '🎧'] },
                { name: 'technology', emojis: ['💻', '📱', '🤖', '⚡', '🔬'] }
            ]
        };
    }

    generateByMood(mood, language = 'ar', count = 5) {
        const moodEmojis = this.emojiMoods[language][mood.toLowerCase()];
        if (!moodEmojis) return [];

        const result = [];
        for (let i = 0; i < count; i++) {
            const randomEmoji = moodEmojis[Math.floor(Math.random() * moodEmojis.length)];
            result.push(randomEmoji);
        }
        return result;
    }

    generateByCategory(category, count = 5) {
        const categoryEmojis = this.emojiCategories[category];
        if (!categoryEmojis) return [];

        const result = [];
        for (let i = 0; i < count; i++) {
            const randomEmoji = categoryEmojis[Math.floor(Math.random() * categoryEmojis.length)];
            result.push(randomEmoji);
        }
        return result;
    }

    generateCombination(language = 'ar') {
        const combinations = this.emojiCombinations[language];
        const randomCombination = combinations[Math.floor(Math.random() * combinations.length)];
        return randomCombination;
    }

    generateRandomEmojis(count = 10) {
        const allEmojis = Object.values(this.emojiCategories).flat();
        const result = [];
        
        for (let i = 0; i < count; i++) {
            const randomEmoji = allEmojis[Math.floor(Math.random() * allEmojis.length)];
            result.push(randomEmoji);
        }
        
        return result;
    }

    createEmojiStory(language = 'ar') {
        const stories = {
            ar: [
                ['👨‍💻', '☕', '💡', '🎉', '🏆'],
                ['🌅', '🏃‍♂️', '🥗', '💪', '😊'],
                ['📚', '🤓', '✏️', '🎓', '🥳'],
                ['✈️', '🏖️', '📸', '🍹', '😎'],
                ['👨‍🍳', '🍅', '🧄', '🍝', '😋'],
                ['🎵', '🎸', '🎤', '👏', '🌟'],
                ['🌱', '🌞', '💧', '🌸', '🦋'],
                ['💻', '🤖', '⚡', '🔬', '🚀']
            ],
            en: [
                ['👨‍💻', '☕', '💡', '🎉', '🏆'],
                ['🌅', '🏃‍♂️', '🥗', '💪', '😊'],
                ['📚', '🤓', '✏️', '🎓', '🥳'],
                ['✈️', '🏖️', '📸', '🍹', '😎'],
                ['👨‍🍳', '🍅', '🧄', '🍝', '😋'],
                ['🎵', '🎸', '🎤', '👏', '🌟'],
                ['🌱', '🌞', '💧', '🌸', '🦋'],
                ['💻', '🤖', '⚡', '🔬', '🚀']
            ]
        };

        const randomStory = stories[language][Math.floor(Math.random() * stories[language].length)];
        return randomStory;
    }

    showTool() {
        const currentLang = getCurrentLanguage();
        
        const content = `
            <div class="tool-header">
                <h3>${currentLang === 'ar' ? 'أداة إنشاء الإيموجي الذكية' : 'Smart Emoji Generator'}</h3>
                <p>${currentLang === 'ar' ? 'أنشئ تركيبات إيموجي مبتكرة ومعبرة' : 'Create innovative and expressive emoji combinations'}</p>
            </div>
            
            <div class="emoji-tabs">
                <button class="tab-btn active" onclick="switchEmojiTab('mood')">${currentLang === 'ar' ? 'حسب المزاج' : 'By Mood'}</button>
                <button class="tab-btn" onclick="switchEmojiTab('category')">${currentLang === 'ar' ? 'حسب الفئة' : 'By Category'}</button>
                <button class="tab-btn" onclick="switchEmojiTab('combination')">${currentLang === 'ar' ? 'تركيبات' : 'Combinations'}</button>
                <button class="tab-btn" onclick="switchEmojiTab('story')">${currentLang === 'ar' ? 'قصة إيموجي' : 'Emoji Story'}</button>
                <button class="tab-btn" onclick="switchEmojiTab('random')">${currentLang === 'ar' ? 'عشوائي' : 'Random'}</button>
            </div>
            
            <div class="tab-content" id="mood-tab">
                <div class="tool-form">
                    <div class="form-group">
                        <label for="mood-select">${currentLang === 'ar' ? 'اختر المزاج:' : 'Select Mood:'}</label>
                        <select id="mood-select">
                            ${this.getMoodOptions(currentLang)}
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="mood-count">${currentLang === 'ar' ? 'عدد الإيموجي:' : 'Number of Emojis:'}</label>
                        <select id="mood-count">
                            <option value="5">5</option>
                            <option value="10" selected>10</option>
                            <option value="15">15</option>
                            <option value="20">20</option>
                        </select>
                    </div>
                    <button onclick="generateEmojisByMood()" class="generate-btn">
                        <i class="fas fa-smile"></i>
                        ${currentLang === 'ar' ? 'إنشاء إيموجي' : 'Generate Emojis'}
                    </button>
                </div>
            </div>
            
            <div class="tab-content" id="category-tab" style="display: none;">
                <div class="tool-form">
                    <div class="form-group">
                        <label for="category-select">${currentLang === 'ar' ? 'اختر الفئة:' : 'Select Category:'}</label>
                        <select id="category-select">
                            <option value="faces">${currentLang === 'ar' ? 'وجوه' : 'Faces'}</option>
                            <option value="animals">${currentLang === 'ar' ? 'حيوانات' : 'Animals'}</option>
                            <option value="food">${currentLang === 'ar' ? 'طعام' : 'Food'}</option>
                            <option value="activities">${currentLang === 'ar' ? 'أنشطة' : 'Activities'}</option>
                            <option value="objects">${currentLang === 'ar' ? 'أشياء' : 'Objects'}</option>
                            <option value="symbols">${currentLang === 'ar' ? 'رموز' : 'Symbols'}</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="category-count">${currentLang === 'ar' ? 'عدد الإيموجي:' : 'Number of Emojis:'}</label>
                        <select id="category-count">
                            <option value="5">5</option>
                            <option value="10" selected>10</option>
                            <option value="15">15</option>
                            <option value="20">20</option>
                        </select>
                    </div>
                    <button onclick="generateEmojisByCategory()" class="generate-btn">
                        <i class="fas fa-th-large"></i>
                        ${currentLang === 'ar' ? 'إنشاء إيموجي' : 'Generate Emojis'}
                    </button>
                </div>
            </div>
            
            <div class="tab-content" id="combination-tab" style="display: none;">
                <div class="tool-form">
                    <button onclick="generateEmojiCombination()" class="generate-btn">
                        <i class="fas fa-magic"></i>
                        ${currentLang === 'ar' ? 'إنشاء تركيبة' : 'Generate Combination'}
                    </button>
                </div>
            </div>
            
            <div class="tab-content" id="story-tab" style="display: none;">
                <div class="tool-form">
                    <button onclick="generateEmojiStory()" class="generate-btn">
                        <i class="fas fa-book"></i>
                        ${currentLang === 'ar' ? 'إنشاء قصة إيموجي' : 'Generate Emoji Story'}
                    </button>
                </div>
            </div>
            
            <div class="tab-content" id="random-tab" style="display: none;">
                <div class="tool-form">
                    <div class="form-group">
                        <label for="random-count">${currentLang === 'ar' ? 'عدد الإيموجي:' : 'Number of Emojis:'}</label>
                        <select id="random-count">
                            <option value="5">5</option>
                            <option value="10" selected>10</option>
                            <option value="15">15</option>
                            <option value="20">20</option>
                            <option value="30">30</option>
                        </select>
                    </div>
                    <button onclick="generateRandomEmojis()" class="generate-btn">
                        <i class="fas fa-random"></i>
                        ${currentLang === 'ar' ? 'إنشاء عشوائي' : 'Generate Random'}
                    </button>
                </div>
            </div>
            
            <div class="tool-results" id="emoji-results">
                <!-- سيتم عرض النتائج هنا -->
            </div>
            
            <style>
                .tool-header {
                    text-align: center;
                    margin-bottom: 2rem;
                }
                
                .tool-header h3 {
                    color: #667eea;
                    font-size: 1.8rem;
                    margin-bottom: 0.5rem;
                }
                
                .tool-header p {
                    color: #666;
                    font-size: 1.1rem;
                }
                
                .emoji-tabs {
                    display: flex;
                    justify-content: center;
                    gap: 0.5rem;
                    margin-bottom: 2rem;
                    flex-wrap: wrap;
                }
                
                .tab-btn {
                    background: #f8f9fa;
                    border: 2px solid #e2e8f0;
                    color: #666;
                    padding: 0.75rem 1.5rem;
                    border-radius: 25px;
                    cursor: pointer;
                    font-weight: 600;
                    transition: all 0.3s ease;
                }
                
                .tab-btn:hover {
                    border-color: #667eea;
                    color: #667eea;
                }
                
                .tab-btn.active {
                    background: #667eea;
                    border-color: #667eea;
                    color: white;
                }
                
                .tab-content {
                    animation: fadeIn 0.3s ease;
                }
                
                .tool-form {
                    background: #f8f9fa;
                    padding: 2rem;
                    border-radius: 15px;
                    margin-bottom: 2rem;
                }
                
                .form-group {
                    margin-bottom: 1.5rem;
                }
                
                .form-group label {
                    display: block;
                    margin-bottom: 0.5rem;
                    font-weight: 600;
                    color: #333;
                }
                
                .form-group select {
                    width: 100%;
                    padding: 1rem;
                    border: 2px solid #e2e8f0;
                    border-radius: 10px;
                    font-size: 1rem;
                }
                
                .form-group select:focus {
                    outline: none;
                    border-color: #667eea;
                }
                
                .generate-btn {
                    background: linear-gradient(45deg, #667eea, #764ba2);
                    color: white;
                    border: none;
                    padding: 1rem 2rem;
                    border-radius: 25px;
                    cursor: pointer;
                    font-weight: 600;
                    font-size: 1.1rem;
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                    margin: 0 auto;
                    transition: all 0.3s ease;
                }
                
                .generate-btn:hover {
                    transform: translateY(-2px);
                    box-shadow: 0 8px 20px rgba(102, 126, 234, 0.3);
                }
                
                .emoji-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fill, minmax(60px, 1fr));
                    gap: 1rem;
                    margin-bottom: 2rem;
                }
                
                .emoji-item {
                    background: white;
                    border: 2px solid #e2e8f0;
                    border-radius: 15px;
                    padding: 1rem;
                    text-align: center;
                    font-size: 2rem;
                    cursor: pointer;
                    transition: all 0.3s ease;
                    position: relative;
                }
                
                .emoji-item:hover {
                    border-color: #667eea;
                    transform: scale(1.1);
                    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
                }
                
                .emoji-item:active {
                    transform: scale(0.95);
                }
                
                .emoji-combination {
                    background: white;
                    border: 2px solid #667eea;
                    border-radius: 15px;
                    padding: 2rem;
                    text-align: center;
                    margin-bottom: 2rem;
                }
                
                .combination-title {
                    font-size: 1.2rem;
                    font-weight: 600;
                    color: #667eea;
                    margin-bottom: 1rem;
                }
                
                .combination-emojis {
                    font-size: 3rem;
                    margin-bottom: 1rem;
                    letter-spacing: 0.5rem;
                }
                
                .emoji-story {
                    background: white;
                    border: 2px solid #667eea;
                    border-radius: 15px;
                    padding: 2rem;
                    text-align: center;
                    margin-bottom: 2rem;
                }
                
                .story-title {
                    font-size: 1.2rem;
                    font-weight: 600;
                    color: #667eea;
                    margin-bottom: 1rem;
                }
                
                .story-emojis {
                    font-size: 3rem;
                    margin-bottom: 1rem;
                    letter-spacing: 0.5rem;
                }
                
                .copy-all-btn {
                    background: #4caf50;
                    color: white;
                    border: none;
                    padding: 1rem 2rem;
                    border-radius: 25px;
                    cursor: pointer;
                    font-weight: 600;
                    margin: 1rem auto;
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                    transition: all 0.3s ease;
                }
                
                .copy-all-btn:hover {
                    background: #45a049;
                    transform: translateY(-2px);
                }
                
                .loading {
                    text-align: center;
                    padding: 2rem;
                    color: #667eea;
                }
                
                .loading i {
                    font-size: 2rem;
                    animation: spin 1s linear infinite;
                }
                
                @keyframes spin {
                    from { transform: rotate(0deg); }
                    to { transform: rotate(360deg); }
                }
                
                @media (max-width: 768px) {
                    .emoji-tabs {
                        flex-direction: column;
                        align-items: center;
                    }
                    
                    .tab-btn {
                        width: 200px;
                    }
                    
                    .emoji-grid {
                        grid-template-columns: repeat(auto-fill, minmax(50px, 1fr));
                    }
                    
                    .combination-emojis,
                    .story-emojis {
                        font-size: 2rem;
                        letter-spacing: 0.3rem;
                    }
                }
            </style>
        `;
        
        return content;
    }

    getMoodOptions(language) {
        const moods = Object.keys(this.emojiMoods[language]);
        return moods.map(mood => `<option value="${mood}">${mood}</option>`).join('');
    }
}

// إنشاء مثيل من أداة الإيموجي
const smartEmoji = new SmartEmoji();

// دالة تبديل التبويبات
function switchEmojiTab(tabName) {
    // إخفاء جميع التبويبات
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.style.display = 'none';
    });
    
    // إزالة الفئة النشطة من جميع الأزرار
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    
    // إظهار التبويب المحدد
    document.getElementById(tabName + '-tab').style.display = 'block';
    
    // إضافة الفئة النشطة للزر المحدد
    event.target.classList.add('active');
}

// دالة إنشاء إيموجي حسب المزاج
function generateEmojisByMood() {
    const currentUser = db.getCurrentUser();
    if (!currentUser) {
        showNotification(getCurrentLanguage() === 'ar' ? 'يجب تسجيل الدخول أولاً' : 'Please login first', 'error');
        return;
    }

    if (db.hasUsedToolToday(currentUser.id, 'smart_emoji')) {
        showNotification(getCurrentLanguage() === 'ar' ? 'لقد استخدمت هذه الأداة اليوم بالفعل' : 'You have already used this tool today', 'warning');
        return;
    }

    const mood = document.getElementById('mood-select').value;
    const count = parseInt(document.getElementById('mood-count').value);
    const currentLang = getCurrentLanguage();
    
    showLoadingEmojis();
    
    setTimeout(() => {
        const emojis = smartEmoji.generateByMood(mood, currentLang, count);
        displayEmojis(emojis, `${currentLang === 'ar' ? 'إيموجي' : 'Emojis'} ${mood}`);
        
        // إضافة النقاط وتسجيل الاستخدام
        db.markToolUsed(currentUser.id, 'smart_emoji');
        db.addPoints(currentUser.id, 'smart_emoji', 25);
        updateUserPointsDisplay();
        
        showNotification(
            currentLang === 'ar' ? 'تم إنشاء الإيموجي بنجاح! حصلت على 25 نقطة' : 'Emojis generated successfully! You earned 25 points',
            'success'
        );
    }, 1000);
}

// دالة إنشاء إيموجي حسب الفئة
function generateEmojisByCategory() {
    const currentUser = db.getCurrentUser();
    if (!currentUser) {
        showNotification(getCurrentLanguage() === 'ar' ? 'يجب تسجيل الدخول أولاً' : 'Please login first', 'error');
        return;
    }

    if (db.hasUsedToolToday(currentUser.id, 'smart_emoji')) {
        showNotification(getCurrentLanguage() === 'ar' ? 'لقد استخدمت هذه الأداة اليوم بالفعل' : 'You have already used this tool today', 'warning');
        return;
    }

    const category = document.getElementById('category-select').value;
    const count = parseInt(document.getElementById('category-count').value);
    const currentLang = getCurrentLanguage();
    
    showLoadingEmojis();
    
    setTimeout(() => {
        const emojis = smartEmoji.generateByCategory(category, count);
        const categoryNames = {
            ar: { faces: 'وجوه', animals: 'حيوانات', food: 'طعام', activities: 'أنشطة', objects: 'أشياء', symbols: 'رموز' },
            en: { faces: 'Faces', animals: 'Animals', food: 'Food', activities: 'Activities', objects: 'Objects', symbols: 'Symbols' }
        };
        displayEmojis(emojis, categoryNames[currentLang][category]);
        
        // إضافة النقاط وتسجيل الاستخدام
        db.markToolUsed(currentUser.id, 'smart_emoji');
        db.addPoints(currentUser.id, 'smart_emoji', 25);
        updateUserPointsDisplay();
        
        showNotification(
            currentLang === 'ar' ? 'تم إنشاء الإيموجي بنجاح! حصلت على 25 نقطة' : 'Emojis generated successfully! You earned 25 points',
            'success'
        );
    }, 1000);
}

// دالة إنشاء تركيبة إيموجي
function generateEmojiCombination() {
    const currentUser = db.getCurrentUser();
    if (!currentUser) {
        showNotification(getCurrentLanguage() === 'ar' ? 'يجب تسجيل الدخول أولاً' : 'Please login first', 'error');
        return;
    }

    if (db.hasUsedToolToday(currentUser.id, 'smart_emoji')) {
        showNotification(getCurrentLanguage() === 'ar' ? 'لقد استخدمت هذه الأداة اليوم بالفعل' : 'You have already used this tool today', 'warning');
        return;
    }

    const currentLang = getCurrentLanguage();
    
    showLoadingEmojis();
    
    setTimeout(() => {
        const combination = smartEmoji.generateCombination(currentLang);
        displayCombination(combination);
        
        // إضافة النقاط وتسجيل الاستخدام
        db.markToolUsed(currentUser.id, 'smart_emoji');
        db.addPoints(currentUser.id, 'smart_emoji', 25);
        updateUserPointsDisplay();
        
        showNotification(
            currentLang === 'ar' ? 'تم إنشاء التركيبة بنجاح! حصلت على 25 نقطة' : 'Combination generated successfully! You earned 25 points',
            'success'
        );
    }, 1000);
}

// دالة إنشاء قصة إيموجي
function generateEmojiStory() {
    const currentUser = db.getCurrentUser();
    if (!currentUser) {
        showNotification(getCurrentLanguage() === 'ar' ? 'يجب تسجيل الدخول أولاً' : 'Please login first', 'error');
        return;
    }

    if (db.hasUsedToolToday(currentUser.id, 'smart_emoji')) {
        showNotification(getCurrentLanguage() === 'ar' ? 'لقد استخدمت هذه الأداة اليوم بالفعل' : 'You have already used this tool today', 'warning');
        return;
    }

    const currentLang = getCurrentLanguage();
    
    showLoadingEmojis();
    
    setTimeout(() => {
        const story = smartEmoji.createEmojiStory(currentLang);
        displayStory(story);
        
        // إضافة النقاط وتسجيل الاستخدام
        db.markToolUsed(currentUser.id, 'smart_emoji');
        db.addPoints(currentUser.id, 'smart_emoji', 25);
        updateUserPointsDisplay();
        
        showNotification(
            currentLang === 'ar' ? 'تم إنشاء القصة بنجاح! حصلت على 25 نقطة' : 'Story generated successfully! You earned 25 points',
            'success'
        );
    }, 1000);
}

// دالة إنشاء إيموجي عشوائي
function generateRandomEmojis() {
    const currentUser = db.getCurrentUser();
    if (!currentUser) {
        showNotification(getCurrentLanguage() === 'ar' ? 'يجب تسجيل الدخول أولاً' : 'Please login first', 'error');
        return;
    }

    if (db.hasUsedToolToday(currentUser.id, 'smart_emoji')) {
        showNotification(getCurrentLanguage() === 'ar' ? 'لقد استخدمت هذه الأداة اليوم بالفعل' : 'You have already used this tool today', 'warning');
        return;
    }

    const count = parseInt(document.getElementById('random-count').value);
    const currentLang = getCurrentLanguage();
    
    showLoadingEmojis();
    
    setTimeout(() => {
        const emojis = smartEmoji.generateRandomEmojis(count);
        displayEmojis(emojis, currentLang === 'ar' ? 'إيموجي عشوائي' : 'Random Emojis');
        
        // إضافة النقاط وتسجيل الاستخدام
        db.markToolUsed(currentUser.id, 'smart_emoji');
        db.addPoints(currentUser.id, 'smart_emoji', 25);
        updateUserPointsDisplay();
        
        showNotification(
            currentLang === 'ar' ? 'تم إنشاء الإيموجي بنجاح! حصلت على 25 نقطة' : 'Emojis generated successfully! You earned 25 points',
            'success'
        );
    }, 1000);
}

// دالة عرض مؤشر التحميل
function showLoadingEmojis() {
    const resultsDiv = document.getElementById('emoji-results');
    const currentLang = getCurrentLanguage();
    resultsDiv.innerHTML = `
        <div class="loading">
            <i class="fas fa-spinner"></i>
            <p>${currentLang === 'ar' ? 'جاري إنشاء الإيموجي...' : 'Generating emojis...'}</p>
        </div>
    `;
}

// دالة عرض الإيموجي
function displayEmojis(emojis, title) {
    const resultsDiv = document.getElementById('emoji-results');
    const currentLang = getCurrentLanguage();
    
    let html = `
        <div class="emoji-section">
            <h4 style="text-align: center; color: #667eea; margin-bottom: 1rem;">${title}</h4>
            <div class="emoji-grid">
    `;
    
    emojis.forEach(emoji => {
        html += `
            <div class="emoji-item" onclick="copyEmoji('${emoji}')" title="${currentLang === 'ar' ? 'انقر للنسخ' : 'Click to copy'}">
                ${emoji}
            </div>
        `;
    });
    
    html += `
            </div>
            <button class="copy-all-btn" onclick="copyAllEmojis('${emojis.join('')}')">
                <i class="fas fa-copy"></i>
                ${currentLang === 'ar' ? 'نسخ الكل' : 'Copy All'}
            </button>
        </div>
    `;
    
    resultsDiv.innerHTML = html;
}

// دالة عرض التركيبة
function displayCombination(combination) {
    const resultsDiv = document.getElementById('emoji-results');
    const currentLang = getCurrentLanguage();
    
    const html = `
        <div class="emoji-combination">
            <div class="combination-title">${combination.name}</div>
            <div class="combination-emojis">${combination.emojis.join(' ')}</div>
            <button class="copy-all-btn" onclick="copyAllEmojis('${combination.emojis.join(' ')}')">
                <i class="fas fa-copy"></i>
                ${currentLang === 'ar' ? 'نسخ التركيبة' : 'Copy Combination'}
            </button>
        </div>
    `;
    
    resultsDiv.innerHTML = html;
}

// دالة عرض القصة
function displayStory(story) {
    const resultsDiv = document.getElementById('emoji-results');
    const currentLang = getCurrentLanguage();
    
    const html = `
        <div class="emoji-story">
            <div class="story-title">${currentLang === 'ar' ? 'قصة إيموجي' : 'Emoji Story'}</div>
            <div class="story-emojis">${story.join(' → ')}</div>
            <button class="copy-all-btn" onclick="copyAllEmojis('${story.join(' → ')}')">
                <i class="fas fa-copy"></i>
                ${currentLang === 'ar' ? 'نسخ القصة' : 'Copy Story'}
            </button>
        </div>
    `;
    
    resultsDiv.innerHTML = html;
}

// دالة نسخ إيموجي واحد
function copyEmoji(emoji) {
    navigator.clipboard.writeText(emoji).then(() => {
        showNotification(
            getCurrentLanguage() === 'ar' ? 'تم نسخ الإيموجي' : 'Emoji copied',
            'success'
        );
    }).catch(() => {
        // طريقة بديلة للنسخ
        const textArea = document.createElement('textarea');
        textArea.value = emoji;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
        
        showNotification(
            getCurrentLanguage() === 'ar' ? 'تم نسخ الإيموجي' : 'Emoji copied',
            'success'
        );
    });
}

// دالة نسخ جميع الإيموجي
function copyAllEmojis(emojis) {
    navigator.clipboard.writeText(emojis).then(() => {
        showNotification(
            getCurrentLanguage() === 'ar' ? 'تم نسخ جميع الإيموجي' : 'All emojis copied',
            'success'
        );
    }).catch(() => {
        // طريقة بديلة للنسخ
        const textArea = document.createElement('textarea');
        textArea.value = emojis;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
        
        showNotification(
            getCurrentLanguage() === 'ar' ? 'تم نسخ جميع الإيموجي' : 'All emojis copied',
            'success'
        );
    });
}

