// قاعدة البيانات المحلية للموقع
// يتم حفظ البيانات في localStorage للمتصفح

class LocalDatabase {
    constructor() {
        this.initializeData();
    }

    // تهيئة البيانات الأساسية
    initializeData() {
        if (!localStorage.getItem('users')) {
            localStorage.setItem('users', JSON.stringify([]));
        }
        if (!localStorage.getItem('points_history')) {
            localStorage.setItem('points_history', JSON.stringify([]));
        }
        if (!localStorage.getItem('posts')) {
            localStorage.setItem('posts', JSON.stringify(this.getDefaultPosts()));
        }
        if (!localStorage.getItem('comments')) {
            localStorage.setItem('comments', JSON.stringify([]));
        }
        if (!localStorage.getItem('user_tasks')) {
            localStorage.setItem('user_tasks', JSON.stringify([]));
        }
        if (!localStorage.getItem('temp_images')) {
            localStorage.setItem('temp_images', JSON.stringify([]));
        }
        if (!localStorage.getItem('site_settings')) {
            localStorage.setItem('site_settings', JSON.stringify(this.getDefaultSettings()));
        }
        if (!localStorage.getItem('current_user')) {
            localStorage.setItem('current_user', JSON.stringify(null));
        }
        if (!localStorage.getItem('tools')) {
            localStorage.setItem('tools', JSON.stringify(this.getDefaultTools()));
        }
    }

    // الحصول على الأدوات الافتراضية
    getDefaultTools() {
        return [
            {
                id: 'smart-titles',
                name: 'smart_titles',
                name_ar: 'إنشاء العناوين الذكية',
                name_en: 'Smart Title Generator',
                description_ar: 'أداة لإنشاء عناوين جذابة ومبتكرة',
                description_en: 'Tool for creating attractive and innovative titles',
                type: 'free',
                required_points: 0,
                daily_points: 25,
                is_active: true,
                position: 1
            },
            {
                id: 'task-manager',
                name: 'tasks',
                name_ar: 'مدير المهام',
                name_en: 'Task Manager',
                description_ar: 'أداة لإدارة وتتبع المهام اليومية',
                description_en: 'Tool for managing and tracking daily tasks',
                type: 'free',
                required_points: 0,
                daily_points: 25,
                is_active: true,
                position: 2
            },
            {
                id: 'smart-emoji',
                name: 'smart_emoji',
                name_ar: 'إنشاء الإيموجي الذكية',
                name_en: 'Smart Emoji Generator',
                description_ar: 'أداة لإنشاء تركيبات إيموجي مبتكرة',
                description_en: 'Tool for creating innovative emoji combinations',
                type: 'free',
                required_points: 0,
                daily_points: 25,
                is_active: true,
                position: 3
            },
            {
                id: 'advanced-titles',
                name: 'advanced_titles',
                name_ar: 'العناوين المتقدمة',
                name_en: 'Advanced Titles',
                description_ar: 'أداة متقدمة لإنشاء عناوين احترافية',
                description_en: 'Advanced tool for creating professional titles',
                type: 'premium',
                required_points: 200,
                daily_points: 0,
                is_active: true,
                position: 4
            },
            {
                id: 'profile-image',
                name: 'profile_image',
                name_ar: 'عرض الصورة الشخصية',
                name_en: 'Profile Image Display',
                description_ar: 'عرض صورتك في الموقع لمدة يوم واحد',
                description_en: 'Display your image on the site for one day',
                type: 'premium',
                required_points: 500,
                daily_points: 0,
                is_active: true,
                position: 5
            }
        ];
    }

    // الحصول على المنشورات الافتراضية
    getDefaultPosts() {
        return [
            {
                id: this.generateId(),
                title_ar: 'مرحباً بكم في موقع الأدوات الذكية',
                title_en: 'Welcome to Smart Tools Website',
                content_ar: 'اكتشف مجموعة رائعة من الأدوات الذكية التي ستساعدك في حياتك اليومية',
                content_en: 'Discover an amazing collection of smart tools that will help you in your daily life',
                image_url: '',
                is_active: true,
                display_date: new Date().toISOString().split('T')[0],
                created_at: new Date().toISOString()
            },
            {
                id: this.generateId(),
                title_ar: 'اجمع النقاط واحصل على مزايا إضافية',
                title_en: 'Collect Points and Get Additional Benefits',
                content_ar: 'استخدم الأدوات يومياً واجمع النقاط لفتح أدوات متقدمة',
                content_en: 'Use tools daily and collect points to unlock advanced tools',
                image_url: '',
                is_active: true,
                display_date: new Date().toISOString().split('T')[0],
                created_at: new Date().toISOString()
            },
            {
                id: this.generateId(),
                title_ar: 'شارك في المنافسة وكن من المتصدرين',
                title_en: 'Join the Competition and Be Among the Leaders',
                content_ar: 'تنافس مع المستخدمين الآخرين وكن من أول 10 في لوحة المتصدرين',
                content_en: 'Compete with other users and be among the top 10 on the leaderboard',
                image_url: '',
                is_active: true,
                display_date: new Date().toISOString().split('T')[0],
                created_at: new Date().toISOString()
            }
        ];
    }

    // الحصول على الإعدادات الافتراضية
    getDefaultSettings() {
        return [
            { key: 'site_title_ar', value: 'موقع الأدوات الذكية', description: 'عنوان الموقع بالعربية' },
            { key: 'site_title_en', value: 'Smart Tools Website', description: 'عنوان الموقع بالإنجليزية' },
            { key: 'daily_points_limit', value: '75', description: 'الحد الأقصى للنقاط اليومية' },
            { key: 'leaderboard_size', value: '10', description: 'عدد المستخدمين في لوحة المتصدرين' },
            { key: 'image_display_duration', value: '1', description: 'مدة عرض الصورة بالأيام' }
        ];
    }

    // توليد معرف فريد
    generateId() {
        return 'id_' + Math.random().toString(36).substr(2, 9) + '_' + Date.now();
    }

    // الحصول على البيانات
    getData(table) {
        return JSON.parse(localStorage.getItem(table) || '[]');
    }

    // حفظ البيانات
    setData(table, data) {
        localStorage.setItem(table, JSON.stringify(data));
    }

    // إضافة عنصر جديد
    addItem(table, item) {
        const data = this.getData(table);
        item.id = item.id || this.generateId();
        item.created_at = item.created_at || new Date().toISOString();
        data.push(item);
        this.setData(table, data);
        return item;
    }

    // تحديث عنصر
    updateItem(table, id, updates) {
        const data = this.getData(table);
        const index = data.findIndex(item => item.id === id);
        if (index !== -1) {
            data[index] = { ...data[index], ...updates, updated_at: new Date().toISOString() };
            this.setData(table, data);
            return data[index];
        }
        return null;
    }

    // حذف عنصر
    deleteItem(table, id) {
        const data = this.getData(table);
        const filteredData = data.filter(item => item.id !== id);
        this.setData(table, filteredData);
        return filteredData.length < data.length;
    }

    // البحث عن عنصر
    findItem(table, criteria) {
        const data = this.getData(table);
        return data.find(item => {
            return Object.keys(criteria).every(key => item[key] === criteria[key]);
        });
    }

    // البحث عن عناصر متعددة
    findItems(table, criteria) {
        const data = this.getData(table);
        return data.filter(item => {
            return Object.keys(criteria).every(key => item[key] === criteria[key]);
        });
    }

    // الحصول على المستخدم الحالي
    getCurrentUser() {
        return JSON.parse(localStorage.getItem('current_user'));
    }

    // تسجيل دخول المستخدم
    setCurrentUser(user) {
        localStorage.setItem('current_user', JSON.stringify(user));
    }

    // تسجيل خروج المستخدم
    logout() {
        localStorage.setItem('current_user', JSON.stringify(null));
    }

    // التحقق من استخدام الأداة اليوم
    hasUsedToolToday(userId, toolName) {
        const user = this.findItem('users', { id: userId });
        if (!user || !user.daily_tool_usage) return false;
        
        const today = new Date().toISOString().split('T')[0];
        const toolUsage = user.daily_tool_usage[toolName];
        
        return toolUsage && toolUsage.used && toolUsage.date === today;
    }

    // تسجيل استخدام الأداة
    markToolUsed(userId, toolName) {
        const user = this.findItem('users', { id: userId });
        if (!user) return false;

        const today = new Date().toISOString().split('T')[0];
        
        if (!user.daily_tool_usage) {
            user.daily_tool_usage = {};
        }
        
        user.daily_tool_usage[toolName] = {
            used: true,
            date: today
        };

        this.updateItem('users', userId, { daily_tool_usage: user.daily_tool_usage });
        return true;
    }

    // إضافة نقاط للمستخدم
    addPoints(userId, toolName, points) {
        const user = this.findItem('users', { id: userId });
        if (!user) return false;

        // إضافة النقاط لإجمالي نقاط المستخدم
        const newPoints = (user.points || 0) + points;
        this.updateItem('users', userId, { points: newPoints });

        // إضافة سجل في تاريخ النقاط
        this.addItem('points_history', {
            user_id: userId,
            tool_name: toolName,
            points_earned: points,
            date: new Date().toISOString().split('T')[0]
        });

        return true;
    }

    // الحصول على لوحة المتصدرين
    getLeaderboard(limit = 10) {
        const users = this.getData('users');
        return users
            .filter(user => user.points > 0)
            .sort((a, b) => b.points - a.points)
            .slice(0, limit)
            .map((user, index) => ({
                rank: index + 1,
                username: user.username,
                points: user.points
            }));
    }

    // تنظيف البيانات المنتهية الصلاحية
    cleanExpiredData() {
        const now = new Date();
        
        // تنظيف الصور المؤقتة المنتهية الصلاحية
        const tempImages = this.getData('temp_images');
        const validImages = tempImages.filter(img => new Date(img.expires_at) > now);
        this.setData('temp_images', validImages);

        // تنظيف استخدام الأدوات اليومي (إعادة تعيين للأمس)
        const users = this.getData('users');
        const today = new Date().toISOString().split('T')[0];
        
        users.forEach(user => {
            if (user.daily_tool_usage) {
                Object.keys(user.daily_tool_usage).forEach(toolName => {
                    if (user.daily_tool_usage[toolName].date !== today) {
                        user.daily_tool_usage[toolName].used = false;
                    }
                });
                this.updateItem('users', user.id, { daily_tool_usage: user.daily_tool_usage });
            }
        });
    }
}

// إنشاء مثيل واحد من قاعدة البيانات
const db = new LocalDatabase();

// تنظيف البيانات عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    db.cleanExpiredData();
});

