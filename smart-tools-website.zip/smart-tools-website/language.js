// نظام دعم اللغات المتعددة
class LanguageSystem {
    constructor() {
        this.currentLanguage = this.loadLanguage();
        this.translations = {
            ar: {
                // العناوين الرئيسية
                'site_title': 'موقع الأدوات الذكية',
                'welcome_title': 'مرحباً بكم في موقع الأدوات الذكية',
                'welcome_desc': 'اكتشف مجموعة رائعة من الأدوات الذكية واجمع النقاط لفتح المزيد من المزايا',
                
                // التنقل
                'login': 'تسجيل الدخول',
                'logout': 'تسجيل الخروج',
                'admin': 'الإدارة',
                'points': 'نقطة',
                
                // الأقسام
                'leaderboard_title': 'لوحة المتصدرين',
                'tools_title': 'الأدوات المتاحة',
                'posts_title': 'المنشورات اليومية',
                'game_title': 'لعبة الدودة',
                'comments_title': 'التعليقات',
                
                // الأدوات
                'smart_titles': 'إنشاء العناوين الذكية',
                'task_manager': 'مدير المهام',
                'smart_emoji': 'إنشاء الإيموجي الذكية',
                'advanced_titles': 'العناوين المتقدمة',
                'profile_image': 'عرض الصورة الشخصية',
                
                // الأزرار
                'generate': 'إنشاء',
                'copy': 'نسخ',
                'edit': 'تعديل',
                'delete': 'حذف',
                'save': 'حفظ',
                'cancel': 'إلغاء',
                'add': 'إضافة',
                'remove': 'إزالة',
                'upload': 'رفع',
                'download': 'تحميل',
                
                // الرسائل
                'success': 'تم بنجاح',
                'error': 'حدث خطأ',
                'warning': 'تحذير',
                'info': 'معلومات',
                'loading': 'جاري التحميل...',
                'no_data': 'لا توجد بيانات',
                'confirm_delete': 'هل أنت متأكد من الحذف؟',
                
                // النماذج
                'username': 'اسم المستخدم',
                'email': 'البريد الإلكتروني',
                'password': 'كلمة المرور',
                'topic': 'الموضوع',
                'category': 'الفئة',
                'count': 'العدد',
                'optional': 'اختياري',
                
                // الإحصائيات
                'total': 'الإجمالي',
                'completed': 'مكتمل',
                'pending': 'معلق',
                'today': 'اليوم',
                'this_week': 'هذا الأسبوع',
                'this_month': 'هذا الشهر',
                
                // الوقت
                'seconds': 'ثانية',
                'minutes': 'دقيقة',
                'hours': 'ساعة',
                'days': 'يوم',
                'weeks': 'أسبوع',
                'months': 'شهر',
                'years': 'سنة',
                
                // الفوتر
                'support_title': 'ادعمنا',
                'support_btn_text': 'ادعمني',
                'external_links_title': 'روابط خارجية',
                'copyright': '© 2024 موقع الأدوات الذكية. جميع الحقوق محفوظة.'
            },
            en: {
                // Main titles
                'site_title': 'Smart Tools Website',
                'welcome_title': 'Welcome to Smart Tools Website',
                'welcome_desc': 'Discover an amazing collection of smart tools and collect points to unlock more features',
                
                // Navigation
                'login': 'Login',
                'logout': 'Logout',
                'admin': 'Admin',
                'points': 'points',
                
                // Sections
                'leaderboard_title': 'Leaderboard',
                'tools_title': 'Available Tools',
                'posts_title': 'Daily Posts',
                'game_title': 'Snake Game',
                'comments_title': 'Comments',
                
                // Tools
                'smart_titles': 'Smart Title Generator',
                'task_manager': 'Task Manager',
                'smart_emoji': 'Smart Emoji Generator',
                'advanced_titles': 'Advanced Titles',
                'profile_image': 'Profile Image Display',
                
                // Buttons
                'generate': 'Generate',
                'copy': 'Copy',
                'edit': 'Edit',
                'delete': 'Delete',
                'save': 'Save',
                'cancel': 'Cancel',
                'add': 'Add',
                'remove': 'Remove',
                'upload': 'Upload',
                'download': 'Download',
                
                // Messages
                'success': 'Success',
                'error': 'Error',
                'warning': 'Warning',
                'info': 'Info',
                'loading': 'Loading...',
                'no_data': 'No data available',
                'confirm_delete': 'Are you sure you want to delete?',
                
                // Forms
                'username': 'Username',
                'email': 'Email',
                'password': 'Password',
                'topic': 'Topic',
                'category': 'Category',
                'count': 'Count',
                'optional': 'Optional',
                
                // Statistics
                'total': 'Total',
                'completed': 'Completed',
                'pending': 'Pending',
                'today': 'Today',
                'this_week': 'This Week',
                'this_month': 'This Month',
                
                // Time
                'seconds': 'seconds',
                'minutes': 'minutes',
                'hours': 'hours',
                'days': 'days',
                'weeks': 'weeks',
                'months': 'months',
                'years': 'years',
                
                // Footer
                'support_title': 'Support Us',
                'support_btn_text': 'Support Me',
                'external_links_title': 'External Links',
                'copyright': '© 2024 Smart Tools Website. All rights reserved.'
            }
        };
    }

    // تحميل اللغة المحفوظة
    loadLanguage() {
        const savedLang = localStorage.getItem('preferred_language');
        if (savedLang && (savedLang === 'ar' || savedLang === 'en')) {
            return savedLang;
        }
        
        // تحديد اللغة بناءً على لغة المتصفح
        const browserLang = navigator.language || navigator.userLanguage;
        return browserLang.startsWith('ar') ? 'ar' : 'en';
    }

    // حفظ اللغة
    saveLanguage(language) {
        localStorage.setItem('preferred_language', language);
        this.currentLanguage = language;
    }

    // الحصول على اللغة الحالية
    getCurrentLanguage() {
        return this.currentLanguage;
    }

    // تبديل اللغة
    toggleLanguage() {
        const newLanguage = this.currentLanguage === 'ar' ? 'en' : 'ar';
        this.setLanguage(newLanguage);
    }

    // تعيين اللغة
    setLanguage(language) {
        if (language !== 'ar' && language !== 'en') return;
        
        this.saveLanguage(language);
        this.updatePageLanguage();
        this.updateUserInterface();
        
        // تحديث لغة المستخدم في قاعدة البيانات
        const currentUser = auth.getCurrentUser();
        if (currentUser) {
            db.updateItem('users', currentUser.id, { language: language });
        }
    }

    // تحديث لغة الصفحة
    updatePageLanguage() {
        const html = document.documentElement;
        const langToggle = document.getElementById('lang-text');
        
        if (this.currentLanguage === 'ar') {
            html.setAttribute('lang', 'ar');
            html.setAttribute('dir', 'rtl');
            if (langToggle) langToggle.textContent = 'EN';
        } else {
            html.setAttribute('lang', 'en');
            html.setAttribute('dir', 'ltr');
            if (langToggle) langToggle.textContent = 'ع';
        }
        
        // تحديث النصوص
        this.updateTexts();
    }

    // تحديث النصوص في الصفحة
    updateTexts() {
        // تحديث العناوين الرئيسية
        const elements = {
            'site-title': 'site_title',
            'welcome-title': 'welcome_title',
            'welcome-desc': 'welcome_desc',
            'leaderboard-title': 'leaderboard_title',
            'tools-title': 'tools_title',
            'posts-title': 'posts_title',
            'game-title': 'game_title',
            'comments-title': 'comments_title',
            'support-title': 'support_title',
            'support-btn-text': 'support_btn_text',
            'external-links-title': 'external_links_title',
            'copyright': 'copyright',
            'login-title': 'login',
            'support-modal-title': 'support_title',
            'support-desc': this.currentLanguage === 'ar' ? 
                'ساعدنا في تطوير الموقع وإضافة المزيد من الأدوات' : 
                'Help us develop the site and add more tools',
            'start-game-btn': this.currentLanguage === 'ar' ? 'ابدأ اللعبة' : 'Start Game',
            'add-comment-btn': this.currentLanguage === 'ar' ? 'إضافة تعليق' : 'Add Comment'
        };

        Object.keys(elements).forEach(elementId => {
            const element = document.getElementById(elementId);
            if (element) {
                const translationKey = elements[elementId];
                if (typeof translationKey === 'string' && this.translations[this.currentLanguage][translationKey]) {
                    element.textContent = this.translations[this.currentLanguage][translationKey];
                } else if (typeof translationKey === 'string') {
                    element.textContent = translationKey;
                }
            }
        });

        // تحديث placeholders
        const placeholders = {
            'username': 'username',
            'email': 'email',
            'comment-text': this.currentLanguage === 'ar' ? 'اكتب تعليقك هنا...' : 'Write your comment here...'
        };

        Object.keys(placeholders).forEach(elementId => {
            const element = document.getElementById(elementId);
            if (element) {
                const translationKey = placeholders[elementId];
                if (this.translations[this.currentLanguage][translationKey]) {
                    element.placeholder = this.translations[this.currentLanguage][translationKey];
                } else {
                    element.placeholder = translationKey;
                }
            }
        });
    }

    // الحصول على ترجمة
    translate(key, defaultValue = '') {
        return this.translations[this.currentLanguage][key] || defaultValue || key;
    }

    // تحديث واجهة المستخدم
    updateUserInterface() {
        // تحديث عرض النقاط
        updateUserPointsDisplay();
        
        // تحديث لوحة المتصدرين
        updateLeaderboard();
        
        // تحديث عرض الأدوات
        updateToolsDisplay();
        
        // تحديث المنشورات
        if (typeof updatePostsDisplay === 'function') {
            updatePostsDisplay();
        }
        
        // تحديث التعليقات
        if (typeof updateCommentsDisplay === 'function') {
            updateCommentsDisplay();
        }
    }

    // تنسيق التاريخ حسب اللغة
    formatDate(date, options = {}) {
        const dateObj = typeof date === 'string' ? new Date(date) : date;
        const locale = this.currentLanguage === 'ar' ? 'ar-SA' : 'en-US';
        
        const defaultOptions = {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        };
        
        return dateObj.toLocaleDateString(locale, { ...defaultOptions, ...options });
    }

    // تنسيق الوقت حسب اللغة
    formatTime(date, options = {}) {
        const dateObj = typeof date === 'string' ? new Date(date) : date;
        const locale = this.currentLanguage === 'ar' ? 'ar-SA' : 'en-US';
        
        const defaultOptions = {
            hour: '2-digit',
            minute: '2-digit'
        };
        
        return dateObj.toLocaleTimeString(locale, { ...defaultOptions, ...options });
    }

    // تنسيق الأرقام حسب اللغة
    formatNumber(number) {
        const locale = this.currentLanguage === 'ar' ? 'ar-SA' : 'en-US';
        return number.toLocaleString(locale);
    }

    // الحصول على اتجاه النص
    getTextDirection() {
        return this.currentLanguage === 'ar' ? 'rtl' : 'ltr';
    }

    // الحصول على محاذاة النص
    getTextAlign() {
        return this.currentLanguage === 'ar' ? 'right' : 'left';
    }
}

// إنشاء مثيل من نظام اللغات
const languageSystem = new LanguageSystem();

// دالة الحصول على اللغة الحالية (للاستخدام في الملفات الأخرى)
function getCurrentLanguage() {
    return languageSystem.getCurrentLanguage();
}

// دالة تبديل اللغة
function toggleLanguage() {
    languageSystem.toggleLanguage();
}

// دالة الحصول على ترجمة
function translate(key, defaultValue = '') {
    return languageSystem.translate(key, defaultValue);
}

// دالة تنسيق التاريخ
function formatDate(date, options = {}) {
    return languageSystem.formatDate(date, options);
}

// دالة تنسيق الوقت
function formatTime(date, options = {}) {
    return languageSystem.formatTime(date, options);
}

// دالة تنسيق الأرقام
function formatNumber(number) {
    return languageSystem.formatNumber(number);
}

// إعداد اللغة عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    languageSystem.updatePageLanguage();
    
    // تحديث اللغة كل ثانية للتأكد من التحديث المستمر
    setInterval(() => {
        if (document.documentElement.getAttribute('lang') !== languageSystem.getCurrentLanguage()) {
            languageSystem.updatePageLanguage();
        }
    }, 1000);
});

