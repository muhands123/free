// لعبة الدودة المصغرة
class SnakeGame {
    constructor() {
        this.canvas = null;
        this.ctx = null;
        this.gridSize = 20;
        this.tileCount = 20;
        this.snake = [{ x: 10, y: 10 }];
        this.food = { x: 15, y: 15 };
        this.dx = 0;
        this.dy = 0;
        this.score = 0;
        this.gameRunning = false;
        this.gameLoop = null;
        this.highScore = this.loadHighScore();
        this.gameSpeed = 150;
        this.colors = {
            background: '#1a1a2e',
            snake: '#4caf50',
            snakeHead: '#66bb6a',
            food: '#f44336',
            text: '#ffffff',
            grid: '#16213e'
        };
    }

    // تهيئة اللعبة
    init() {
        this.canvas = document.getElementById('snake-canvas');
        if (!this.canvas) {
            console.error('Snake canvas not found');
            return;
        }
        
        this.ctx = this.canvas.getContext('2d');
        this.canvas.width = this.gridSize * this.tileCount;
        this.canvas.height = this.gridSize * this.tileCount;
        
        this.setupControls();
        this.draw();
        this.updateUI();
    }

    // إعداد التحكم
    setupControls() {
        // التحكم بلوحة المفاتيح
        document.addEventListener('keydown', (e) => {
            if (!this.gameRunning) return;
            
            switch (e.key) {
                case 'ArrowUp':
                case 'w':
                case 'W':
                    if (this.dy === 0) {
                        this.dx = 0;
                        this.dy = -1;
                    }
                    break;
                case 'ArrowDown':
                case 's':
                case 'S':
                    if (this.dy === 0) {
                        this.dx = 0;
                        this.dy = 1;
                    }
                    break;
                case 'ArrowLeft':
                case 'a':
                case 'A':
                    if (this.dx === 0) {
                        this.dx = -1;
                        this.dy = 0;
                    }
                    break;
                case 'ArrowRight':
                case 'd':
                case 'D':
                    if (this.dx === 0) {
                        this.dx = 1;
                        this.dy = 0;
                    }
                    break;
                case ' ':
                    e.preventDefault();
                    this.togglePause();
                    break;
                case 'Escape':
                    this.stopGame();
                    break;
            }
        });

        // التحكم باللمس للأجهزة المحمولة
        let touchStartX = 0;
        let touchStartY = 0;

        this.canvas.addEventListener('touchstart', (e) => {
            e.preventDefault();
            const touch = e.touches[0];
            touchStartX = touch.clientX;
            touchStartY = touch.clientY;
        });

        this.canvas.addEventListener('touchend', (e) => {
            e.preventDefault();
            if (!this.gameRunning) return;

            const touch = e.changedTouches[0];
            const touchEndX = touch.clientX;
            const touchEndY = touch.clientY;

            const deltaX = touchEndX - touchStartX;
            const deltaY = touchEndY - touchStartY;

            if (Math.abs(deltaX) > Math.abs(deltaY)) {
                // حركة أفقية
                if (deltaX > 30 && this.dx === 0) {
                    this.dx = 1;
                    this.dy = 0;
                } else if (deltaX < -30 && this.dx === 0) {
                    this.dx = -1;
                    this.dy = 0;
                }
            } else {
                // حركة عمودية
                if (deltaY > 30 && this.dy === 0) {
                    this.dx = 0;
                    this.dy = 1;
                } else if (deltaY < -30 && this.dy === 0) {
                    this.dx = 0;
                    this.dy = -1;
                }
            }
        });
    }

    // بدء اللعبة
    startGame() {
        this.resetGame();
        this.gameRunning = true;
        this.dx = 1;
        this.dy = 0;
        this.gameLoop = setInterval(() => this.update(), this.gameSpeed);
        this.updateUI();
    }

    // إيقاف اللعبة
    stopGame() {
        this.gameRunning = false;
        if (this.gameLoop) {
            clearInterval(this.gameLoop);
            this.gameLoop = null;
        }
        this.updateUI();
    }

    // تبديل الإيقاف المؤقت
    togglePause() {
        if (this.gameRunning) {
            this.stopGame();
        } else if (this.snake.length > 1 || this.score > 0) {
            this.gameRunning = true;
            this.gameLoop = setInterval(() => this.update(), this.gameSpeed);
            this.updateUI();
        }
    }

    // إعادة تعيين اللعبة
    resetGame() {
        this.snake = [{ x: 10, y: 10 }];
        this.food = this.generateFood();
        this.dx = 0;
        this.dy = 0;
        this.score = 0;
        this.gameSpeed = 150;
    }

    // تحديث اللعبة
    update() {
        this.moveSnake();
        
        if (this.checkCollision()) {
            this.gameOver();
            return;
        }
        
        if (this.checkFoodCollision()) {
            this.eatFood();
        }
        
        this.draw();
    }

    // تحريك الدودة
    moveSnake() {
        const head = { x: this.snake[0].x + this.dx, y: this.snake[0].y + this.dy };
        this.snake.unshift(head);
        
        // إزالة الذيل إذا لم تأكل الدودة طعاماً
        if (!this.checkFoodCollision()) {
            this.snake.pop();
        }
    }

    // فحص التصادم
    checkCollision() {
        const head = this.snake[0];
        
        // التصادم مع الجدران
        if (head.x < 0 || head.x >= this.tileCount || head.y < 0 || head.y >= this.tileCount) {
            return true;
        }
        
        // التصادم مع الجسم
        for (let i = 1; i < this.snake.length; i++) {
            if (head.x === this.snake[i].x && head.y === this.snake[i].y) {
                return true;
            }
        }
        
        return false;
    }

    // فحص تصادم الطعام
    checkFoodCollision() {
        const head = this.snake[0];
        return head.x === this.food.x && head.y === this.food.y;
    }

    // أكل الطعام
    eatFood() {
        this.score += 10;
        this.food = this.generateFood();
        
        // زيادة السرعة تدريجياً
        if (this.score % 50 === 0 && this.gameSpeed > 80) {
            this.gameSpeed -= 10;
            clearInterval(this.gameLoop);
            this.gameLoop = setInterval(() => this.update(), this.gameSpeed);
        }
        
        this.updateUI();
    }

    // إنشاء طعام جديد
    generateFood() {
        let newFood;
        do {
            newFood = {
                x: Math.floor(Math.random() * this.tileCount),
                y: Math.floor(Math.random() * this.tileCount)
            };
        } while (this.snake.some(segment => segment.x === newFood.x && segment.y === newFood.y));
        
        return newFood;
    }

    // انتهاء اللعبة
    gameOver() {
        this.stopGame();
        
        if (this.score > this.highScore) {
            this.highScore = this.score;
            this.saveHighScore();
            
            showNotification(
                getCurrentLanguage() === 'ar' ? 
                `رقم قياسي جديد! ${this.score} نقطة` : 
                `New High Score! ${this.score} points`,
                'success'
            );
        }
        
        this.updateUI();
        this.showGameOverModal();
    }

    // رسم اللعبة
    draw() {
        // مسح الشاشة
        this.ctx.fillStyle = this.colors.background;
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
        
        // رسم الشبكة
        this.drawGrid();
        
        // رسم الطعام
        this.drawFood();
        
        // رسم الدودة
        this.drawSnake();
    }

    // رسم الشبكة
    drawGrid() {
        this.ctx.strokeStyle = this.colors.grid;
        this.ctx.lineWidth = 1;
        
        for (let i = 0; i <= this.tileCount; i++) {
            // خطوط عمودية
            this.ctx.beginPath();
            this.ctx.moveTo(i * this.gridSize, 0);
            this.ctx.lineTo(i * this.gridSize, this.canvas.height);
            this.ctx.stroke();
            
            // خطوط أفقية
            this.ctx.beginPath();
            this.ctx.moveTo(0, i * this.gridSize);
            this.ctx.lineTo(this.canvas.width, i * this.gridSize);
            this.ctx.stroke();
        }
    }

    // رسم الدودة
    drawSnake() {
        this.snake.forEach((segment, index) => {
            this.ctx.fillStyle = index === 0 ? this.colors.snakeHead : this.colors.snake;
            this.ctx.fillRect(
                segment.x * this.gridSize + 1,
                segment.y * this.gridSize + 1,
                this.gridSize - 2,
                this.gridSize - 2
            );
            
            // إضافة عيون للرأس
            if (index === 0) {
                this.ctx.fillStyle = this.colors.background;
                const eyeSize = 3;
                const eyeOffset = 5;
                
                if (this.dx === 1) { // يمين
                    this.ctx.fillRect(segment.x * this.gridSize + this.gridSize - eyeOffset, segment.y * this.gridSize + eyeOffset, eyeSize, eyeSize);
                    this.ctx.fillRect(segment.x * this.gridSize + this.gridSize - eyeOffset, segment.y * this.gridSize + this.gridSize - eyeOffset - eyeSize, eyeSize, eyeSize);
                } else if (this.dx === -1) { // يسار
                    this.ctx.fillRect(segment.x * this.gridSize + 2, segment.y * this.gridSize + eyeOffset, eyeSize, eyeSize);
                    this.ctx.fillRect(segment.x * this.gridSize + 2, segment.y * this.gridSize + this.gridSize - eyeOffset - eyeSize, eyeSize, eyeSize);
                } else if (this.dy === 1) { // أسفل
                    this.ctx.fillRect(segment.x * this.gridSize + eyeOffset, segment.y * this.gridSize + this.gridSize - eyeOffset, eyeSize, eyeSize);
                    this.ctx.fillRect(segment.x * this.gridSize + this.gridSize - eyeOffset - eyeSize, segment.y * this.gridSize + this.gridSize - eyeOffset, eyeSize, eyeSize);
                } else if (this.dy === -1) { // أعلى
                    this.ctx.fillRect(segment.x * this.gridSize + eyeOffset, segment.y * this.gridSize + 2, eyeSize, eyeSize);
                    this.ctx.fillRect(segment.x * this.gridSize + this.gridSize - eyeOffset - eyeSize, segment.y * this.gridSize + 2, eyeSize, eyeSize);
                }
            }
        });
    }

    // رسم الطعام
    drawFood() {
        this.ctx.fillStyle = this.colors.food;
        this.ctx.beginPath();
        this.ctx.arc(
            this.food.x * this.gridSize + this.gridSize / 2,
            this.food.y * this.gridSize + this.gridSize / 2,
            this.gridSize / 2 - 2,
            0,
            2 * Math.PI
        );
        this.ctx.fill();
        
        // إضافة لمعة للطعام
        this.ctx.fillStyle = '#ffcdd2';
        this.ctx.beginPath();
        this.ctx.arc(
            this.food.x * this.gridSize + this.gridSize / 2 - 3,
            this.food.y * this.gridSize + this.gridSize / 2 - 3,
            3,
            0,
            2 * Math.PI
        );
        this.ctx.fill();
    }

    // تحديث واجهة المستخدم
    updateUI() {
        const scoreElement = document.getElementById('snake-score');
        const highScoreElement = document.getElementById('snake-high-score');
        const startBtn = document.getElementById('start-snake-btn');
        const pauseBtn = document.getElementById('pause-snake-btn');
        const resetBtn = document.getElementById('reset-snake-btn');
        
        if (scoreElement) scoreElement.textContent = this.score;
        if (highScoreElement) highScoreElement.textContent = this.highScore;
        
        const currentLang = getCurrentLanguage();
        
        if (startBtn) {
            startBtn.textContent = this.gameRunning ? 
                (currentLang === 'ar' ? 'جاري اللعب...' : 'Playing...') : 
                (currentLang === 'ar' ? 'ابدأ اللعبة' : 'Start Game');
            startBtn.disabled = this.gameRunning;
        }
        
        if (pauseBtn) {
            pauseBtn.textContent = this.gameRunning ? 
                (currentLang === 'ar' ? 'إيقاف مؤقت' : 'Pause') : 
                (currentLang === 'ar' ? 'استئناف' : 'Resume');
            pauseBtn.disabled = this.snake.length === 1 && this.score === 0;
        }
        
        if (resetBtn) {
            resetBtn.disabled = this.gameRunning;
        }
    }

    // عرض نافذة انتهاء اللعبة
    showGameOverModal() {
        const currentLang = getCurrentLanguage();
        const modal = document.createElement('div');
        modal.className = 'game-over-modal';
        modal.innerHTML = `
            <div class="game-over-content">
                <h3>${currentLang === 'ar' ? 'انتهت اللعبة!' : 'Game Over!'}</h3>
                <div class="final-score">
                    <span class="score-label">${currentLang === 'ar' ? 'النتيجة النهائية:' : 'Final Score:'}</span>
                    <span class="score-value">${this.score}</span>
                </div>
                ${this.score === this.highScore ? `
                    <div class="new-record">
                        <i class="fas fa-trophy"></i>
                        ${currentLang === 'ar' ? 'رقم قياسي جديد!' : 'New High Score!'}
                    </div>
                ` : ''}
                <div class="game-over-actions">
                    <button onclick="snakeGame.startGame(); this.parentElement.parentElement.parentElement.remove();" class="btn btn-primary">
                        <i class="fas fa-play"></i>
                        ${currentLang === 'ar' ? 'لعب مرة أخرى' : 'Play Again'}
                    </button>
                    <button onclick="this.parentElement.parentElement.parentElement.remove();" class="btn btn-secondary">
                        <i class="fas fa-times"></i>
                        ${currentLang === 'ar' ? 'إغلاق' : 'Close'}
                    </button>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        
        // إزالة النافذة تلقائياً بعد 10 ثوان
        setTimeout(() => {
            if (modal.parentElement) {
                modal.remove();
            }
        }, 10000);
    }

    // حفظ أعلى نتيجة
    saveHighScore() {
        localStorage.setItem('snake_high_score', this.highScore.toString());
    }

    // تحميل أعلى نتيجة
    loadHighScore() {
        const saved = localStorage.getItem('snake_high_score');
        return saved ? parseInt(saved) : 0;
    }

    // تغيير نظام الألوان
    setColorScheme(scheme) {
        const schemes = {
            classic: {
                background: '#1a1a2e',
                snake: '#4caf50',
                snakeHead: '#66bb6a',
                food: '#f44336',
                text: '#ffffff',
                grid: '#16213e'
            },
            neon: {
                background: '#0a0a0a',
                snake: '#00ff00',
                snakeHead: '#00ff88',
                food: '#ff0080',
                text: '#00ffff',
                grid: '#333333'
            },
            ocean: {
                background: '#001122',
                snake: '#0099cc',
                snakeHead: '#00bbff',
                food: '#ff6600',
                text: '#ffffff',
                grid: '#003366'
            },
            sunset: {
                background: '#2d1b69',
                snake: '#f093fb',
                snakeHead: '#f5576c',
                food: '#ffd700',
                text: '#ffffff',
                grid: '#4c2885'
            }
        };
        
        if (schemes[scheme]) {
            this.colors = schemes[scheme];
            this.draw();
        }
    }

    // الحصول على إحصائيات اللعبة
    getStats() {
        return {
            currentScore: this.score,
            highScore: this.highScore,
            snakeLength: this.snake.length,
            gameRunning: this.gameRunning,
            speed: this.gameSpeed
        };
    }
}

// إنشاء مثيل من لعبة الدودة
const snakeGame = new SnakeGame();

// دوال التحكم في اللعبة
function startSnakeGame() {
    snakeGame.startGame();
}

function pauseSnakeGame() {
    snakeGame.togglePause();
}

function resetSnakeGame() {
    snakeGame.resetGame();
    snakeGame.draw();
    snakeGame.updateUI();
}

function changeSnakeColorScheme(scheme) {
    snakeGame.setColorScheme(scheme);
}

// تهيئة اللعبة عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    // تأخير قصير للتأكد من تحميل جميع العناصر
    setTimeout(() => {
        snakeGame.init();
    }, 100);
});

// تصدير للاستخدام العام
window.snakeGame = snakeGame;
window.startSnakeGame = startSnakeGame;
window.pauseSnakeGame = pauseSnakeGame;
window.resetSnakeGame = resetSnakeGame;
window.changeSnakeColorScheme = changeSnakeColorScheme;

